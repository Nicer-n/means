const SUCCESS=200;
const FAIL=404;
module.exports={
  SUCCESS,
  FAIL
}