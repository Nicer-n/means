// pages/cate/cate.js
const app = getApp();
const HOSTNAME = app.globalData.hostname;
const IMGURL = app.globalData.imgurl;
let {
  SUCCESS,
  FAIL
} = require('../../utils/base.js')

Page({

  /**
   * 页面的初始数据
   */
  data: {
    currentIndex: 0,
    cate: [],
    banner: [],
    goods: [],
    page: 0,
    limit: 12,
    total: 0,
    flag: true,
    IMGURL: IMGURL,
    HOSTNAME: HOSTNAME
  },
  changeCate(e) {
    let itemCid = e.currentTarget.dataset.cid;
    this.setData({
      currentIndex: itemCid,
      page: 0,
      total: 0,
      goods: [],
      flag: true
    })
    this.goodsQuery();
  },
  cateQuery() {
    wx.showLoading({
      title: '正在加载',
      mask: true
    });
    wx.request({
      url: "http://localhost/vue-cli/shop/public/index.php/wx/cate",
      responseType: 'text',
      success: (res) => {
        if (res.data.code == 200) {
          let {
            cate,
            banner
          } = res.data.data;
          this.setData({
            cate,
            banner
          })
        }
      },

      fail: (error) => {
        wx.showToast({
          title: '',
        })
      },
      complete: () => {
        wx.hideLoading();
      }
    })
  },
  goodsQuery() {
    let {
      page,
      limit,
      currentIndex,
      total
    } =
    this.data;
    let pages = ++page;
    this.setData({
      page: pages
    })
    wx.request({
      url: "http://localhost/vue-cli/shop/public/index.php/wx/lists",
      data: {
        page,
        limit,
        cid: currentIndex,
        total
      },
      success: (res) => {
        console.log(res)
        if (res.data.code == 200) {
          let goods = res.data.data.map(ele => Object.assign({}, ele, {
            gthumb: "http://localhost/vue-cli/shop/public/" + ele.gthumb.replace('\\', '/')
          }));
          this.setData({
            goods: goods,
            total: res.data.total
          })
          console.log(goods)
          console.log(this.data.total)
        }
      },

      fail: () => {

      },
      complete: () => {
        this.setData({
          flag: true
        })
      },
    })
  },
  fn() {
    let flag = this.data.flag;
    if (!flag) {
      return;
    }
    this.setData({
      flag: false
    })
    this.goodsQuery();
  },
  pagechange: function(e) {
    if ("touch" === e.detail.source) {
      let currentPageIndex = this.data.currentIndex
      currentPageIndex = (currentPageIndex + 1) % 3
      this.setData({
        currentIndex: currentPageIndex
      })
    }
  },
  //点击tab调用
  titleClick: function(e) {
    let currentPageIndex =
      this.setData({
        //拿到当前索引并动态改变
        currentIndex: e.currentTarget.dataset.idx
      })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    this.cateQuery();
    this.goodsQuery();
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  }
})