// pages/login/login.js

let app = getApp();
const HOSTNAME = app.globalData.hostname;
const IMGURL = app.globalData.imgurl;
let {
  SUCCESS,
  FAIL
} = require('../../utils/base.js')

Page({

  /**
   * 页面的初始数据
   */
  data: {
    openid: '',
    caniuse: wx.canIUse("button.open-type.getUserInfo")
  },
  loginfn() {
    wx.login({
      success: (res) => {
        if (res.code == SUCCESS) {
          wx.request({
            url: HOSTNAME + '/wx/login',
            data: {
              code: res.data
            },
            success: (result) => {
              if (result.data.code == SUCCESS && result.data) {
                this.setData({
                  openid: result.data.openid
                })
              }
            }
          })
        }
      }
    })
  },
  getUserInfo(e) {
    let {
      nickName,
      avatorUrl,
      gender
    } = e.detail.userInfo;
    let openid = this.data.openid;
    let tell = Date.now().toString().substr(2);
    let data = {
      username: nickName,
      password: openid,
      avator: avatorUrl,
      sex: gender,
      tell: tell
    };
    wx.request({
      url: HOSTNAME + '/wx/login',
      method: 'POST',
      data: data,
      success: (res) => {
        if(res.data.code==SUCCESS){
          wx.setStorageSync('token',res.data.token);
          app.globalData.userInfo = data;
          wx.switchTab({
            url: '/pages/my/my',
          })
        }
      },
      fail: (error) => {
        wx.showToast({
          title: '注册失败',
          icon: false
        })
      }
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  }
})