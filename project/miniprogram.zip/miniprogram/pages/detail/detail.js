// pages/detail/detail.js
const app = getApp();
const HOSTNAME = app.globalData.hostname;
const IMGURL = app.globalData.imgurl;
let {
  SUCCESS,
  FAIL
} = require('../../utils/base.js');

Page({

  /**
   * 页面的初始数据
   */
  data: {
    gid: 0,
    goods: {},
    recommend: [],
    HOSTNAME: HOSTNAME,
    num:0,
    swiper: {
      indicatorDots: true,
      vertical: false,
      autoplay: true,
      interval: 2000,
      duration: 500
    }
  },
  goodsQuery(gid) {
    wx.request({
      url: HOSTNAME + '/wx/index/' + this.data.gid,
      header: {
        'content-type': 'application/json',
        'responseType': 'text',
      },
      success: (res => {
        if (res.data.code) {

        }
      })
    })
  },
  addcart() {
    let data = {
      gid: this.data.gid,
      gdiscount: this.data.goods.gdiscount
    };
    let token = wx.getStorageSync('token');
    wx.request({
      url: HOSTNAME + '/api/cart',
      data: data,
      header: {
        'token': token
      },
      method: 'POST',
      success: (res) => {
        wx.request({
          url: HOSTNAME + 'api/cart',
          header: {
            'token': token
          },
          success: (result) => {
            app.globalData.cart = result.data.code;
          }
        })
      }
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    let gid = options.gid || 15;
    this.setData({
      gid
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {
    let num = app.goodsNumber(this.data.gid);
    this.setData({
      num
    })
    this.goodsQuery(this.data.gid);
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  }
})