// pages/list/list.js
let app = getApp();
const HOSTNAME = app.globalData.hostname;
let {
  SUCCESS,
  FAIL
} = require('../../utils/base.js')

Page({

  /**
   * 页面的初始数据
   */
  data: {
    goods: [],
    pages: 0,
    limit: 10,
    orderfield: 'gid',
    ordertype: 'desc',
    total: 0,
    cid: 0,
    hostname: HOSTNAME,
  },
  changeField(e) {
    let field = e.currentTarget.dataset.field;
    if (field == this.data.setData) {
      return;
    }
    this.setData({
      orderfield: field,
      ordertype: 'asc',
    })
    this.goodsQuery();
  },
  changeType() {
    let type = this.data.ordertype == 'desc' ? 'asc':'desc';
    this.setData({
      ordertype:type,
    })
    this.goodsQuery();
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    let cid = options.cid || 1;
    this.setData({
      cid
    });
    wx.startPullDownRefresh();
  },
  goodsQuery() {
    
    if (this.data.total && this.data.goods.length >= this.data.total) {
      return;
    }
    wx.showLoading({
      title: '正在加载',
      mask: true
    })
    let page = this.data.page++;
    this.setData({
      page: page
    })
    let {
      pages,
      limit,
      orderfield,
      ordertype,
      cid
    } = this.data;
    wx.request({
      url: HOSTNAME + '/wx/lists',
      data: {
        pages,
        limit,
        orderfield,
        ordertype,
        cid
      },
      dataType: 'text',
      success: (res) => {
        wx.stopPullDownRefresh();
        if (res.data.code == SUCCESS && res.data.data) {
          let data = res.data.data.map(ele => Object.assign({}, ele, {
            gthumb: ele.gthumb.replace('\\', '/')
          }));
          let arr = this.data.goods.push(...data)
          this.setData({
            goods: this.data.goods
          })
        }
      },
      fail: (res) => {

      },
      complete:()=>{
        wx.hideLoading();
      }
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {
    this.goodsQuery();
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {
    this.goodsQuery();
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  }
})