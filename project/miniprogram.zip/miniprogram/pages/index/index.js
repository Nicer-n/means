//index.js
//获取应用实例
const app = getApp();
const HOSTNAME = app.globalData.hostname;
const IMGURL=app.globalData.imgurl;
let {
  SUCCESS,
  FAIL
} = require('../../utils/base.js')

Page({
  data: {
    background: [],
    chooselist: [],
    HOSTNAME: HOSTNAME,
    IMGURL:IMGURL,
    swiper: {
      indicatorDots: true,
      vertical: false,
      autoplay: true,
      circular: true,
      inficator: "#fff",
      activeColor: "#59c3fe",
      interval: 2000,
      duration: 500
    }
  },
  indexQuery() {
    wx.request({
      url: HOSTNAME + '/wx/index',
      header: {
        'content-type': 'application/json',
        'responseType': 'text',
      },

      success: (res => {
        console.log(res);
        if (res.data.code) {
          let {
            banner,
            active
          } = res.data;
          
          banner = banner.map(ele => Object.assign({}, ele, {
            gthumb: ele.gthumb.replace('\\', '/')
          }));
          this.setData({
            background: banner,
            chooselist: active
          })
        }
      })
    })
  },
  
  onLoad:function(options) {
    this.indexQuery();
  }
})