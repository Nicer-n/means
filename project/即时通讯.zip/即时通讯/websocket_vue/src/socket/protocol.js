export const protocol = {
  C2S_MESSAGE: 1,
  S2C_MESSAGE: 1,
}
