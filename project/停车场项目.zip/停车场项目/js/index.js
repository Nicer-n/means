let timer = document.querySelectorAll(".time")
let years = document.querySelectorAll(".year")
setInterval(() => {
    let date = new Date();
    let h = date.getHours();
    h = h < 10 ? '0' + h : h;
    let m = date.getMinutes();
    m = m < 10 ? '0' + m : m;
    let s = date.getSeconds();
    s = s < 10 ? '0' + s : s;
    let n = date.getFullYear();
    let y = date.getMonth() + 1;
    y = y < 10 ? '0' + y : y;
    let d = date.getDate();
    d = d < 10 ? '0' + d : d;
    timer[0].innerText = h;
    timer[1].innerText = m;
    timer[2].innerText = s;
    years[0].innerText = n;
    years[1].innerText = y;
    years[2].innerText = d;
}, 1000);

$(function () {
    //停车时长
    leftPark();
    function leftPark() {
        //初始化图表展示区域
        let main = document.querySelector(".length-main");
        let echart = echarts.init(main)
        //设置图标信息的配置项
        let option = {
            //进行图表展示类型、数据的设置
            tooltip: {
                formatter: '时长：{b}<br>总计：{c}<br>占比：{d}'
            },
            series: [{
                color: ['#fbff86', '#ff6f6f', '#ab6eff', '#1dd7ff', '#7dff89'],
                radius: ['55%', '80%'],
                name: '停车时长',
                type: 'pie',
                data: [
                    { name: '30分钟以内', value: 4533 },
                    { name: '30~60分钟', value: 6653 },
                    { name: '1~2小时', value: 5034 },
                    { name: '2~4小时', value: 9512 },
                    { name: '4小时以上', value: 7465 }
                ]
            }]
        }
        //降配置设置到echarts中
        echart.setOption(option);
    }
    //右边缴费类型
    rightType();
    function rightType() {
        let type = document.querySelector(".stop-pay-type");
        let echart = echarts.init(type);
        let option = {
            title: {//标题组件
                left: '50px',//标题的位置 默认是left，其余还有center、right属性
                textStyle: {
                    color: "#436EEE",
                    fontSize: 17,
                }
            },
            tooltip: { //提示框组件
                trigger: 'item', //触发类型(饼状图片就是用这个)
                formatter: "{a} <br/>{b} : {c} ({d}%)" //提示框浮层内容格式器
            },
            color:['#fffbbe','#ffbd3d'],  //手动设置每个图例的颜色
            legend: {  //图例组件
                //right:100,  //图例组件离右边的距离
                orient: 'horizontal',  //布局  纵向布局 图例标记居文字的左边 vertical则反之
                // width: 30,      //图行例组件的宽度,默认自适应
                x: 'center',   //图例显示在右边
                y: 'bottom',   //图例在垂直方向上面显示居中
                itemWidth: 5,  //图例标记的图形宽度
                itemHeight: 10, //图例标记的图形高度
                data: ['现金缴费', '电子缴费'],
                textStyle: {    //图例文字的样式
                    color: '#777',  //文字颜色
                    fontSize: 12    //文字大小
                }

            },
            series: [ //系列列表
                {
                    name: '缴费类型',  //系列名称
                    type: 'pie',   //类型 pie表示饼图
                    // center: ['40%', '50%'], //设置饼的原心坐标 不设置就会默认在中心的位置
                    radius: ['50%', '70%'],  //饼图的半径,第一项是内半径,第二项是外半径,内半径为0就是真的饼,不是环形
                    itemStyle: {  //图形样式
                        normal: { //normal 是图形在默认状态下的样式；emphasis 是图形在高亮状态下的样式，比如在鼠标悬浮或者图例联动高亮时。
                            label: {  //饼图图形上的文本标签
                                show: false,  //平常不显示
                                position: 'center'   //文本标签显示在饼图中间
                            },
                            labelLine: {     //标签的视觉引导线样式
                                show: false //平常不显示

                            }
                        },
                        emphasis: {   //normal 是图形在默认状态下的样式；emphasis 是图形在高亮状态下的样式，比如在鼠标悬浮或者图例联动高亮时。
                            label: {  //饼图图形上的文本标签
                                show: true,
                                position: 'left',
                                textStyle: {
                                    fontSize: '15',
                                    fontWeight: '500'
                                }
                            }
                        }
                    },
                    data: [
                        { value: 10, name: '现金缴费' },
                        { value: 90, name: '电子缴费' },
                    ]
                }
            ]
        };
        echart.setOption(option);
    }
    //右边缴费情况
    rightTime();
    function rightTime() {
        let time = document.querySelector(".stop-pay-time");
        let echart = echarts.init(time);
        let option = {
            title: {//标题组件
                left: '50px',//标题的位置 默认是left，其余还有center、right属性
                textStyle: {
                    color: "#436EEE",
                    fontSize: 17,
                }
            },
            tooltip: { //提示框组件
                trigger: 'item', //触发类型(饼状图片就是用这个)
                formatter: "{a} <br/>{b} : {c} ({d}%)" //提示框浮层内容格式器
            },
            color: ['#b8e3ff', '#009cff'],  //手动设置每个图例的颜色
            legend: {  //图例组件
                //right:100,  //图例组件离右边的距离
                orient: 'horizontal',  //布局  纵向布局 图例标记居文字的左边 vertical则反之
                // width: 30,      //图行例组件的宽度,默认自适应
                x: 'center',   //图例显示在右边
                y: 'bottom',   //图例在垂直方向上面显示居中
                itemWidth: 5,  //图例标记的图形宽度
                itemHeight: 10, //图例标记的图形高度
                data: ['提前缴费', '出口缴费'],
                textStyle: {    //图例文字的样式
                    color: '#777',  //文字颜色
                    fontSize: 12    //文字大小
                }

            },
            series: [ //系列列表
                {
                    name: '缴费情况',  //系列名称
                    type: 'pie',   //类型 pie表示饼图
                    // center: ['40%', '50%'], //设置饼的原心坐标 不设置就会默认在中心的位置
                    radius: ['50%', '70%'],  //饼图的半径,第一项是内半径,第二项是外半径,内半径为0就是真的饼,不是环形
                    itemStyle: {  //图形样式
                        normal: { //normal 是图形在默认状态下的样式；emphasis 是图形在高亮状态下的样式，比如在鼠标悬浮或者图例联动高亮时。
                            label: {  //饼图图形上的文本标签
                                show: false,  //平常不显示
                                position: 'center'   //文本标签显示在饼图中间
                            },
                            labelLine: {     //标签的视觉引导线样式
                                show: false //平常不显示

                            }
                        },
                        emphasis: {   //normal 是图形在默认状态下的样式；emphasis 是图形在高亮状态下的样式，比如在鼠标悬浮或者图例联动高亮时。
                            label: {  //饼图图形上的文本标签
                                show: true,
                                position: 'left',
                                textStyle: {
                                    fontSize: '15',
                                    fontWeight: '500'
                                }
                            }
                        }
                    },
                    data: [
                        { value: 20, name: '提前缴费' },
                        { value: 80, name: '出口缴费' },
                    ]
                }
            ]
        };
        echart.setOption(option);
    }
    //地图部分
    let city = {
        '哈尔滨': [126.63, 45.75],
        '北京': [116.46, 39.92],
        '上海': [121.48, 31.22],
        '太原': [112.53, 37.87],
        '杭州': [120.19, 30.26],
        '西安': [108.95, 34.27],
        '海门': [121.15, 31.89],
        '鄂尔多斯': [109.781327, 39.608266],
        '招远': [120.38, 37.35],
        '舟山': [122.207216, 29.985295],
        '齐齐哈尔': [123.97, 47.33],
        '盐城': [120.13, 33.38],
        '赤峰': [118.87, 42.28],
        '常熟': [120.74, 31.64],
        '东莞': [113.75, 23.04],
        '河源': [114.68, 23.73],
        '淮安': [119.15, 33.5],
        '泰州': [119.9, 32.49],
        '南宁': [108.33, 22.84],
        '营口': [122.18, 40.65],
        '惠州': [114.4, 23.09],
        '江阴': [120.26, 31.91],
        '蓬莱': [120.75, 37.8],
        '韶关': [113.62, 24.84],
        '嘉峪关': [98.289152, 39.77313],
        '广州': [113.23, 23.16],
        '延安': [109.47, 36.6],
        '清远': [113.01, 23.7],
        '中山': [113.38, 22.52],
        '昆明': [102.73, 25.04],
        '寿光': [118.73, 36.86],
        '盘锦': [122.070714, 41.119997],
        '长治': [113.08, 36.18],
        '深圳': [114.07, 22.62],
        '珠海': [113.52, 22.3],
        '宿迁': [118.3, 33.96],
        '咸阳': [108.72, 34.36],
        '铜川': [109.11, 35.09],
        '平度': [119.97, 36.77],
        '佛山': [113.11, 23.05],
        '海口': [110.35, 20.02],
        '江门': [113.06, 22.61],
    };
    let data = {
        '哈尔滨': 454,
        '北京': 955,
        '上海': 854,
        '太原': 757,
        '杭州': 855,
        '西安': 587,
        '海门': 52,
        '鄂尔多斯': 52,
        '招远': 84,
        '舟山': 21,
        '齐齐哈尔': 35,
        '盐城': 48,
        '赤峰': 62,
        '常熟': 56,
        '东莞': 65,
        '河源': 23,
        '淮安': 87,
        '泰州': 87,
        '南宁': 34,
        '营口': 34,
        '惠州': 12,
        '江阴': 75,
        '蓬莱': 63,
        '韶关': 65,
        '嘉峪关': 48,
        '广州': 78,
        '延安': 65,
        '清远': 123,
        '中山': 95,
        '昆明': 35,
        '寿光': 42,
        '盘锦': 45,
        '长治': 85,
        '深圳': 35,
        '珠海': 75,
        '宿迁': 52,
        '咸阳': 32,
        '铜川': 48,
        '平度': 85,
        '佛山': 35,
        '海口': 24,
        '江门': 36,
    }
    senterMap();
    function senterMap() {
        let map = document.querySelector(".map");
        let echart = echarts.init(map);
        let option = {
            geo: {
                map: 'china',
                zoom: 5.5,
                layoutCenter: ['50%', '50%'],
                layoutSize: 100,
                itemStyle: {
                    normal: {
                        areaColor: '#194e7c',
                        borderColor: '#111',
                    },
                    emphasis: {
                        areaColor: '#52a8eb',
                    }
                }
            },
            tooltip: {
                formatter: function (data) {
                    return `
                <div class="center-box">
                    <div class="modal">
                    <h2>${data.name}千玺广场</h2>
                        <div class="text">今日收入</div>
                        <div class="money">912659</div>
                        <div class="car">
                            <div class="left">
                                <span>总车位</span>
                                <span>322</span>
                            </div>
                            <div class="right">
                                <span>空余</span>
                                <span>322</span>
                            </div>
                        </div>
                        <div class="bottom">
                            <div>本日进场:11983</div>
                            <div>本日出场:11983</div>
                        </div>
                    </div>
                </div>
                `
                }
            },
            series: [{
                color: 'yellow',
                type: 'scatter',
                coordinateSystem: 'geo',
                symbolSize: 10,
                data: updateData(data),
            }, {
                type: 'effectScatter',
                symbolSize: 15,
                coordinateSystem: 'geo',
                color: 'rgb(74, 223, 255)',
                data: updateData(data).sort((a, b) => {
                    return b.value[2] - a.value[2];
                }, 516512).slice(0, 6),
                legendHoverLink: true,
            }]
        }
        echart.setOption(option);
    }
    //处理数据格式
    function updateData(data) {
        let arr = [];
        for (let i in data) {
            let obj = {
                name: i,
                value: city[i].concat(data[i])
            };
            arr.push(obj)
        }
        return arr;
    }
})