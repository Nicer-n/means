<template>
    <div class="main">

                <el-form :model="form" ref="form"  :rules="rules" >
                    <el-form-item>
                        <h2>系统登录</h2>
                    </el-form-item>

                    <el-form-item  prop="name">
                        <el-input v-model="form.name" auto-complete="off" placeholder="请输入用户名"></el-input>
                    </el-form-item>
                    <el-form-item  prop="password">
                        <el-input type="password" v-model="form.password" auto-complete="off"  placeholder="请输入密码"></el-input>
                    </el-form-item>
                    <el-form-item>
                        <el-checkbox v-model="form.checked">记住密码</el-checkbox>
                    </el-form-item>
                    <el-form-item>
                        <el-button type="primary" >登录</el-button>
                    </el-form-item>
                </el-form>
    </div>
</template>

<script>
    export default {
        name: "Login",
        data: () => ({
            form:{
                name:"",
                password:"",
                checked: true
            },
            rules: {
                name: [{
                    required: true,
                    message: "请输入用户名",
                    trigger: "blur"
                }],
                password: [{
                    // validator:passwordValid,
                    required: true,
                    message: "请输入密码",
                    trigger: "blur"
                }],
            },
        }),
        methods:{
        }
    }
</script>

<style lang="scss" scoped>
    h2{
        text-align: center;
        color: #636363;

    }
    .main {
        width: 450px;
        height: 350px;
        display: flex;
        align-items: center;
        box-shadow:0 0 15px  rgba(0, 0, 0, 0.46);
        position: absolute;
        left: 0;
        right: 0;
        top:0;
        bottom: 0;
        margin:  auto;
        border-radius: 20px;
    }
    .el-form{
        width: 100%;
        margin: 0 auto;
        padding:0 20px;
        box-sizing: border-box;
        text-align: center;
        .el-button{
            width: 100%;
        }
    }


</style>