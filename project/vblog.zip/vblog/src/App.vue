<template>
  <div id="app">
    <el-container class="container">
      <el-header>
        <el-row>
          <el-col :span="12">V部落博客管理平台</el-col>
          <el-col :span="2" :offset="10">
            <el-dropdown trigger="click">
      <span class="el-dropdown-link" style="color: #fff">
        江南一点雨<i class="el-icon-arrow-down el-icon--right"></i>
      </span>
              <el-dropdown-menu slot="dropdown">
                <el-dropdown-item>退出</el-dropdown-item>
              </el-dropdown-menu>
            </el-dropdown>
          </el-col>
        </el-row>
      </el-header>
      <el-container class="bottom">
        <el-aside width="200px">
          <el-menu
                  :default-active="active"
                  class="el-menu-vertical-demo"
                  :router="true"
                  :unique-opened="true"
          >
            <el-submenu index="article">
              <template slot="title">
                <i class="el-icon-document"></i>
                <span>文章管理</span>
              </template>
              <el-menu-item index="/ListShow">文章列表</el-menu-item>
              <el-menu-item index="/ArticlePublish">发表文章</el-menu-item>
            </el-submenu>
            <el-submenu index="user">
              <template slot="title">
                <i class="el-icon-user"></i>
                <span>用户管理</span>
              </template>
              <el-menu-item index="/UserShow">用户查看</el-menu-item>
              <el-menu-item index="/UserAdd">添加用户</el-menu-item>
            </el-submenu>
            <el-submenu index="column">
              <template slot="title">
                <i class="el-icon-s-fold"></i>
                <span slot="title">栏目管理</span>
              </template>
              <el-menu-item index="/ColumnShow">栏目查看</el-menu-item>
            </el-submenu>
            <el-menu-item index="/Count">
                <i class="el-icon-s-data"></i>
                <span slot="title">数据统计</span>
            </el-menu-item>
          </el-menu>
        </el-aside>
        <el-main>
          <router-view></router-view>
        </el-main>
      </el-container>
    </el-container>
  </div>
</template>

<script>
  export default {
    data: () => ({}),
    methods: {},
    computed: {
      active: function () {
        return this.$store.state.active;
      }
    },

  }
</script>

<style lang="scss">
* {
  margin: 0;
  padding: 0;
  list-style: none;
}

html, body, #app {
  width: 100%;
  height: 100%;
}

#app {
  font-family: 'Avenir', Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}
.el-dropdown{
  cursor: pointer;
}
.el-header {
  background: #409EFF;
  line-height: 60px;
  font-size: 24px;
  color: #fff;

  a {
    color: #fff;
    text-decoration: none;
  }

  .right {
    font-size: 16px;
  }
}

.container {
  height: 100%;

  .bottom {
    height: calc(100% - 60px);

    .el-aside {
      height: 100%;

      .el-menu {
        height: 100%;
      }
    }
  }
}

</style>
