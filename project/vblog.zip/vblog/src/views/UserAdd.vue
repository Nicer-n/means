<template>
    <div>
        <el-col :span="12">
            <el-form ref="form" :model="form" label-width="80px">
                <el-form-item label="用户名" prop="name">
                    <el-input v-model="form.name" placeholder="请输入用户名"></el-input>
                </el-form-item>
                <el-form-item label="性别" prop="sex">
                    <el-radio v-model="form.sex" label="0">男</el-radio>
                    <el-radio v-model="form.sex" label="1">女</el-radio>
                </el-form-item>
                <el-form-item label="电子邮箱" prop="name">
                    <el-input v-model="form.email" placeholder="请输入邮箱"></el-input>
                </el-form-item>
                <el-form-item label="头像" prop="avatar">
                    <el-input type="hidden" v-model="form.avatar"></el-input>
                    <el-upload
                            class="avatar-uploader"
                            :action="url"
                            :show-file-list="false"
                            :on-success="handleAvatarSuccess"
                            :before-upload="beforeAvatarUpload"
                    >
                        <img v-if="form.avatar" :src="form.avatar" class="avatar">
                        <i v-else class="el-icon-plus avatar-uploader-icon"></i>
                        <div slot="tip" class="el-upload__tip">只能上传jpg/png文件，且不超过500kb</div>
                    </el-upload>
                </el-form-item>

                <el-form-item>
                    <el-button type="primary" @click="">立即创建</el-button>
                </el-form-item>
            </el-form>
        </el-col>
    </div>
</template>

<script>
    export default {
        name: "UserAdd",
        data: () => ({
            form:{
                sex:"",
                name:"",
                email:"",
                state:"",
                role:""
            },
            url:""
        }),
        methods:{
            handleAvatarSuccess: function (r) {
                if (r !== "") {
                    this.$message({
                        message: "上传成功",
                        type: "success"
                    });
                    this.form.avatar = r;
                } else {
                    this.$message({
                        message: "上传失败",
                        type: "error"
                    });
                }
            },
            beforeAvatarUpload(file) {
                const isJPG = file.type === 'image/jpeg' || file.type === 'image/png';
                const isLt500KB = file.size / 1024 / 1024 < 0.5;

                if (!isJPG) {
                    this.$message.error('上传头像图片只能是 JPG 格式或者PNG格式!');
                }
                if (!isLt500KB) {
                    this.$message.error('上传头像图片大小不能超过 500KB!');
                }
                return isJPG && isLt500KB;
            },
        }
    }
</script>

<style lang="scss" scoped>
    .avatar-uploader .el-upload {
        border: 1px dashed #d9d9d9;
        border-radius: 6px;
        cursor: pointer;
        position: relative;
        overflow: hidden;
    }

    .avatar-uploader .el-upload:hover {
        border-color: #409EFF;
    }

    .avatar-uploader-icon {
        border: 1px dashed #d9d9d9;
        border-radius: 6px;
        font-size: 28px;
        color: #8c939d;
        width: 178px;
        height: 178px;
        line-height: 178px;
        text-align: center;
    }

    .avatar-uploader-icon:hover {
        border-color: #409EFF;
    }

    .avatar {
        width: 178px;
        height: 178px;
        display: block;
    }
</style>