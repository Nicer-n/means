<template>
    <div>
        <el-breadcrumb separator-class="el-icon-arrow-right" style="margin-bottom: 20px">
            <el-breadcrumb-item :to="{ path: '/' }">首页</el-breadcrumb-item>
            <el-breadcrumb-item>栏目管理</el-breadcrumb-item>
        </el-breadcrumb>
        <el-form class="demo-form-inline" :inline="true">
            <el-form-item>
                <el-input
                        placeholder="请输入栏目名称"
                        v-model="form.typeName"
                >
                </el-input>
            </el-form-item>
            <el-form-item>
                <el-button type="primary">新增栏目</el-button>
            </el-form-item>
        </el-form>
        <el-table
                ref="multipleTable"
                :data="tableData"
                tooltip-effect="dark"
                style="width: 100%"
                @selection-change=""
        >
            <el-table-column
                    type="selection"
                    width="55">
            </el-table-column>
            <el-table-column
                    label="编号"
                    width="120">
                <template slot-scope="scope">{{ scope.row.id }}</template>
            </el-table-column>
            <el-table-column
                    prop="typeName"
                    label="栏目名称"
                    width="120">
            </el-table-column>
            <el-table-column
                    prop="address"
                    label="启用时间"
            >
                <template slot-scope="scope">{{ scope.row.date }}</template>
            </el-table-column>
            <el-table-column label="操作" align="center">
                <template slot-scope="scope">
                    <el-button size="mini" @click="handlerEdit">编辑</el-button>
                    <el-button size="mini" type="danger" @click="handlerDelete">删除</el-button>
                </template>
            </el-table-column>
        </el-table>
        <div style="margin-top: 20px">
            <el-button @click="" type="danger">批量删除</el-button>
        </div>
    </div>
</template>

<script>
    export default {
        name: "ColumnShow",
        data: () => ({
            form: {
                typeName: "",
            },
            tableData: [
                {
                    id: 1,
                    date: '2016-05-03',
                    typeName: '人生感悟',
                }, {
                    id: 2,
                    date: '2016-05-03',
                    typeName: '人生感悟',
                }, {
                    id: 3,
                    date: '2016-05-03',
                    typeName: '人生感悟',
                },
            ],
        }),
        methods: {
            handlerEdit() {
                this.$prompt('请输入栏目名称', '提示', {
                    confirmButtonText: '确定',
                    cancelButtonText: '取消',
                    // inputPattern: /[\w!#$%&'*+/=?^_`{|}~-]+(?:\.[\w!#$%&'*+/=?^_`{|}~-]+)*@(?:[\w](?:[\w-]*[\w])?\.)+[\w](?:[\w-]*[\w])?/,
                    // inputErrorMessage: '邮箱格式不正确'
                }).then(({value}) => {
                    this.$message({
                        type: 'success',
                        message: '你的栏目是: ' + value
                    });
                }).catch(() => {
                    this.$message({
                        type: 'info',
                        message: '取消输入'
                    });
                });
            },
            handlerDelete: function () {
                this.$confirm('此操作将永久删除该文件, 是否继续?', '提示', {
                    confirmButtonText: '确定',
                    cancelButtonText: '取消',
                    type: 'warning'
                }).then(() => {
                    this.$message({
                        type: 'success',
                        message: '删除成功!'
                    });
                }).catch(() => {
                    this.$message({
                        type: 'info',
                        message: '已取消删除'
                    });
                });
            }
        },
        mounted: function () {
            this.$store.commit("changeActive", "/Column")
        }
    }
</script>

<style lang="scss" scoped>

</style>