<template>
    <div>
        <el-breadcrumb separator-class="el-icon-arrow-right" style="margin-bottom: 20px">
            <el-breadcrumb-item :to="{ path: '/' }">首页</el-breadcrumb-item>
            <el-breadcrumb-item>数据统计</el-breadcrumb-item>
        </el-breadcrumb>
        <!-- 为 ECharts 准备一个具备大小（宽高）的 DOM -->
        <div id="main" style="width: 600px;height:400px; margin: 0 auto"></div>
    </div>
</template>

<script>
    import echarts from 'echarts'
    export default {
        name: "Count",
        data: () => ({}),
        methods:{
            drawLine:function(){
                // 基于准备好的dom，初始化echarts实例
                var myChart = echarts.init(document.getElementById('main'));
                // 指定图表的配置项和数据
                var option = {
                    tooltip: {
                        trigger: 'axis'
                    },
                    legend: {
                        data:['pv']
                    },
                    grid: {
                        left: '3%',
                        right: '4%',
                        bottom: '3%',
                        containLabel: true
                    },
                    toolbox: {
                        feature: {
                            dataZoom: {
                                yAxisIndex: 'none',

                            },
                            mark: {show: true},
                            dataView: {},
                            magicType: {show: true, type: ['line', 'bar']},
                            restore: {},
                            saveAsImage: {},
                        }
                    },
                    xAxis: {
                        type: 'category',
                        data: ['2017-12-23','2017-12-24','2017-12-25','2017-12-26']
                    },
                    yAxis: {
                        type: 'value'
                    },
                    series: [{
                        name:'pv',
                        stack: '总量',
                        data: [75, 18, 22, 35],
                        type: 'line'
                    }]
                };

                // 使用刚指定的配置项和数据显示图表。
                myChart.setOption(option);
            }
        },
        mounted:function () {
            this.drawLine();
            this.$store.commit("changeActive","/Count")
        }
    }
</script>

<style lang="scss" scoped>

</style>