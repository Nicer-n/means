<template>
    <div>
        <el-breadcrumb separator-class="el-icon-arrow-right" style="margin-bottom: 20px">
            <el-breadcrumb-item :to="{ path: '/' }">首页</el-breadcrumb-item>
            <el-breadcrumb-item>发表文章</el-breadcrumb-item>
        </el-breadcrumb>
        <el-form class="demo-form-inline" :inline="true">
            <el-form-item>
                <el-select v-model="value" placeholder="请选择" :clearable="true">
                    <el-option
                            v-for="item in options"
                            :key="item.value"
                            :label="item.label"
                            :value="item.value">
                    </el-option>
                </el-select>
            </el-form-item>
            <el-form-item>
                <el-input
                        placeholder="请输入标题"
                        style="width: 400px"
                        v-model="form.title"
                >
                </el-input>
            </el-form-item>
            <el-form-item>
                <el-button type="primary">+Tag</el-button>
            </el-form-item>
        </el-form>
        <el-form>
            <el-form-item>
                <!--<quill-editor v-model="content"-->
                              <!--:options="editorOption"-->
                              <!--@blur=""-->
                              <!--@focus=""-->
                              <!--@change=""-->
                <!--&gt;-->
                <!--</quill-editor>-->
                <my-Editor></my-Editor>
            </el-form-item>
            <el-form-item align="right" >
                <el-button>保存到草稿箱</el-button>
                <el-button type="primary">发表文章</el-button>
            </el-form-item>
        </el-form>
    </div>
</template>

<script>
    // import { quillEditor } from 'vue-quill-editor'
    import Editor from "@/components/Editor";

    export default {
        name: "ArticlePublish",
        data: () => ({
            value:"",
            options:[
                {
                    value:"ddd"
                }
            ],
            form:{
                title:""
            }
        }),
        components:{
          "my-Editor":Editor
        },
        mounted:function () {
            this.$store.commit("changeActive","/ArticlePublish")
        }
    }
</script>

<style lang="scss" scoped>
    .quill-editor {
        height: 300px;
    }

</style>