<template>
    <div >
        <el-breadcrumb separator-class="el-icon-arrow-right" style="margin-bottom: 20px">
            <el-breadcrumb-item :to="{ path: '/' }">首页</el-breadcrumb-item>
            <el-breadcrumb-item>用户管理</el-breadcrumb-item>
        </el-breadcrumb>
        <el-form class="demo-form-inline" :inline="true" align="center">
            <el-form-item>
                <el-input
                        placeholder="默认展示部分用户，可以通过用户名搜索用户"
                        prefix-icon="el-icon-search"
                        style="width: 400px"
                        v-model="form.user"
                >
                </el-input>
            </el-form-item>
            <el-form-item>
                <el-button type="primary" icon="el-icon-search">搜索</el-button>
            </el-form-item>
        </el-form>
        <div style="padding-left: 20px">

            <el-card class="box-card" >
                <div slot="header" class="clearfix">
                    <span>令狐冲</span>
                    <el-button style="float: right; padding: 3px 0;color:#F56C6C " type="text">
                        <i class="el-icon-delete" ></i>
                        删除
                    </el-button>
                </div>
                <div class="demo-image" align="center">
                    <div class="block">
                        <el-image
                                style="width: 100px; height: 100px;"
                                :src="url"
                                >

                        </el-image>
                    </div>
                </div>
                <div style="margin-top: 30px" class="des">
                    <div>用户名:liming</div>
                    <div>电子邮箱:liming@qq.com</div>
                    <div>注册时间:2017-12-30 17:30</div>
                    <div>
                        用户状态:
                        <el-switch
                                v-model="value1"
                                active-text="启用"
                                inactive-text="禁用"
                                active-color="#13ce66"
                                :active-value="1"
                                :inactive-value="0"
                        >
                        </el-switch>
                    </div>
                    <div>
                        用户角色:
                        <el-tag type="success" size="small">普通用户</el-tag>
                    </div>
                </div>
            </el-card>
            <el-card class="box-card" >
                <div slot="header" class="clearfix">
                    <span>令狐冲</span>
                    <el-button style="float: right; padding: 3px 0;color:#F56C6C " type="text">
                        <i class="el-icon-delete" ></i>
                        删除
                    </el-button>
                </div>
                <div class="demo-image" align="center">
                    <div class="block">
                        <el-image
                                style="width: 100px; height: 100px;"
                                :src="url"
                                >

                        </el-image>
                    </div>
                </div>
                <div style="margin-top: 30px" class="des">
                    <div>用户名:liming</div>
                    <div>电子邮箱:liming@qq.com</div>
                    <div>注册时间:2017-12-30 17:30</div>
                    <div>
                        用户状态:
                        <el-switch
                                v-model="value1"
                                active-text="启用"
                                inactive-text="禁用"
                                active-color="#13ce66"
                                :active-value="1"
                                :inactive-value="0"
                        >
                        </el-switch>
                    </div>
                    <div>
                        用户角色:
                        <el-tag type="success" size="small">普通用户</el-tag>
                    </div>
                </div>
            </el-card>
            <el-card class="box-card" >
                <div slot="header" class="clearfix">
                    <span>令狐冲</span>
                    <el-button style="float: right; padding: 3px 0;color:#F56C6C " type="text">
                        <i class="el-icon-delete" ></i>
                        删除
                    </el-button>
                </div>
                <div class="demo-image" align="center">
                    <div class="block">
                        <el-image
                                style="width: 100px; height: 100px;"
                                :src="url"
                        >

                        </el-image>
                    </div>
                </div>
                <div style="margin-top: 30px" class="des">
                    <div>用户名:liming</div>
                    <div>电子邮箱:liming@qq.com</div>
                    <div>注册时间:2017-12-30 17:30</div>
                    <div>
                        用户状态:
                        <el-switch
                                v-model="value1"
                                active-text="开启"
                                inactive-text="禁用"
                                active-color="#13ce66"
                                :active-value="1"
                                :inactive-value="0"
                        >
                        </el-switch>
                    </div>
                    <div>
                        用户角色:
                        <el-tag type="success" size="small">普通用户</el-tag>
                    </div>
                </div>
            </el-card>
            <el-card class="box-card" >
                <div slot="header" class="clearfix">
                    <span>令狐冲</span>
                    <el-button style="float: right; padding: 3px 0;color:#F56C6C " type="text">
                        <i class="el-icon-delete" ></i>
                        删除
                    </el-button>
                </div>
                <div class="demo-image" align="center">
                    <div class="block">
                        <el-image
                                style="width: 100px; height: 100px;"
                                :src="url"
                        >

                        </el-image>
                    </div>
                </div>
                <div style="margin-top: 30px" class="des">
                    <div>用户名:liming</div>
                    <div>电子邮箱:liming@qq.com</div>
                    <div>注册时间:2017-12-30 17:30</div>
                    <div>
                        用户状态:
                        <el-switch
                                v-model="value1"
                                active-text="启用"
                                inactive-text="禁用"
                                active-color="#13ce66"
                                :active-value="1"
                                :inactive-value="0"
                        >
                        </el-switch>
                    </div>
                    <div>
                        用户角色:
                        <el-tag type="success" size="small">普通用户</el-tag>
                    </div>
                </div>
            </el-card>
            <el-card class="box-card" >
                <div slot="header" class="clearfix">
                    <span>令狐冲</span>
                    <el-button style="float: right; padding: 3px 0;color:#F56C6C " type="text">
                        <i class="el-icon-delete" ></i>
                        删除
                    </el-button>
                </div>
                <div class="demo-image" align="center">
                    <div class="block">
                        <el-image
                                style="width: 100px; height: 100px;"
                                :src="url"
                        >

                        </el-image>
                    </div>
                </div>
                <div style="margin-top: 30px" class="des">
                    <div>用户名:liming</div>
                    <div>电子邮箱:liming@qq.com</div>
                    <div>注册时间:2017-12-30 17:30</div>
                    <div>
                        用户状态:
                        <el-switch
                                v-model="value1"
                                active-text="启用"
                                inactive-text="禁用"
                                active-color="#13ce66"
                                :active-value="1"
                                :inactive-value="0"
                        >
                        </el-switch>
                    </div>
                    <div>
                        用户角色:
                        <el-tag type="success" size="small">普通用户</el-tag>
                    </div>
                </div>
            </el-card>
            <el-card class="box-card" >
                <div slot="header" class="clearfix">
                    <span>令狐冲</span>
                    <el-button style="float: right; padding: 3px 0;color:#F56C6C " type="text">
                        <i class="el-icon-delete" ></i>
                        删除
                    </el-button>
                </div>
                <div class="demo-image" align="center">
                    <div class="block">
                        <el-image
                                style="width: 100px; height: 100px;"
                                :src="url"
                        >

                        </el-image>
                    </div>
                </div>
                <div style="margin-top: 30px" class="des">
                    <div>用户名:liming</div>
                    <div>电子邮箱:liming@qq.com</div>
                    <div>注册时间:2017-12-30 17:30</div>
                    <div>
                        用户状态:
                        <el-switch
                                v-model="value1"
                                active-text="启用"
                                inactive-text="禁用"
                                active-color="#13ce66"
                                :active-value="1"
                                :inactive-value="0"
                        >
                        </el-switch>
                    </div>
                    <div>
                        用户角色:
                        <el-tag type="success" size="small">普通用户</el-tag>
                    </div>
                </div>
            </el-card>
        </div>
    </div>
</template>

<script>
    export default {
        name: "UserShow",
        data: () => ({
            form:{
                user:""
            },
            value:1,
            value1:1,
            value2:1,
            value3:1,
            value4:1,
            value5:1,
            value6:1,
            url:"../assets/avator.png"
        }),
        mounted:function () {
            this.$store.commit("changeActive","/UserShow")
        }
    }
</script>

<style lang="scss" scoped>
.el-card{
    width: 300px;
    float: left;
    margin-right: 30px;
    margin-bottom: 15px;
}
    .des{
        line-height: 2.3;
        color: #409EFF;
        font-size: 14px;
    }
</style>