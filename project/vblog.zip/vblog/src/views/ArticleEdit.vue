<template>
    <div>
        <el-breadcrumb separator-class="el-icon-arrow-right" style="margin-bottom: 20px">
            <el-breadcrumb-item :to="{ path: '/' }">首页</el-breadcrumb-item>
            <el-breadcrumb-item>编辑文章</el-breadcrumb-item>
        </el-breadcrumb>



        <el-form label-width="80px">
            <el-form-item label="所属分类">
                <el-select v-model="form.type" placeholder="请选择" :clearable="true">
                    <el-option
                            v-for="item in options"
                            :key="item.value"
                            :label="item.label"
                            :value="item.value">
                    </el-option>
                </el-select>
            </el-form-item>
            <el-form-item label="标题">
                <el-col :span="12">
                <el-input
                        placeholder="请输入标题"
                        v-model="form.title"
                >
                </el-input>
                </el-col>
            </el-form-item>
            <el-form-item label="内容">
                <my-Editor></my-Editor>
            </el-form-item>
            <el-form-item align="center" >
                <el-button type="primary">保存修改</el-button>
                <el-button>保存到草稿箱</el-button>
                <el-button @click="$router.back()">放弃修改</el-button>

            </el-form-item>
        </el-form>



    </div>

</template>

<script>
    import Editor from "@/components/Editor";
    export default {
        name: "ArticleEdit",
        data: () => ({
            form:{
              type:"",
              title:"",
            },
            options:{
                value:""
            },

        }),
        components:{
            "my-Editor":Editor
        },
        mounted:function () {
            this.$store.commit("changeActive","/ListShow")
        },
        methods:{
        }
    }
</script>

<style lang="scss" scoped>

</style>