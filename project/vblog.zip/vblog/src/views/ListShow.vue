<template>
    <div>
        <el-breadcrumb separator-class="el-icon-arrow-right">
            <el-breadcrumb-item :to="{ path: '/' }">首页</el-breadcrumb-item>
            <el-breadcrumb-item>文章列表</el-breadcrumb-item>
        </el-breadcrumb>
        <el-tabs v-model="activeName" type="card" @tab-click="handleClick" >
            <el-tab-pane label="全部文章" name="first">全部文章</el-tab-pane>
            <el-tab-pane label="已发表" name="second">
                <el-form class="demo-form-inline" :inline="true">
                    <el-form-item>
                        <el-input
                                placeholder="通过标题搜索该分类下的博客"
                                prefix-icon="el-icon-search"
                                style="width: 400px"
                                v-model="form.title"
                        >
                        </el-input>
                    </el-form-item>
                    <el-form-item>
                        <el-button type="primary" icon="el-icon-search">搜索</el-button>
                    </el-form-item>
                </el-form>
                <el-table
                        ref="multipleTable"
                        :data="tableData"
                        tooltip-effect="dark"
                        style="width: 100%"
                        @selection-change=""
                >
                    <el-table-column
                            type="selection"
                            width="55">
                    </el-table-column>
                    <el-table-column
                            label="标题"
                            width="120"
                            prop="title"
                    >
                        <template slot-scope="scope">{{ scope.row.title }}</template>
                    </el-table-column>
                    <el-table-column
                            prop="date"
                            label="最近编辑时间"
                            width="120">
                        <template slot-scope="scope">{{ scope.row.date }}</template>
                    </el-table-column>
                    <el-table-column
                            prop="author"
                            label="作者"
                            >
                        <template slot-scope="scope">{{ scope.row.author }}</template>
                    </el-table-column>
                    <el-table-column
                            prop="type"
                            label="所属分类"
                            >
                        <template slot-scope="scope">{{ scope.row.type }}</template>
                    </el-table-column>
                    <el-table-column label="操作" align="center">
                        <template slot-scope="scope">
                            <el-button size="mini" @click="handlerEdit">编辑</el-button>
                            <el-button size="mini" type="danger" @click="handlerDelete">删除</el-button>
                        </template>
                    </el-table-column>
                </el-table>
                <div style="margin-top: 20px">
                    <el-button @click=""  type="danger">批量删除</el-button>
                </div>
                <el-pagination
                        background
                        layout="prev, pager, next"
                        :total="total"
                        align="center"
                >
                </el-pagination>
            </el-tab-pane>
            <el-tab-pane label="草稿箱" name="third">草稿箱</el-tab-pane>
            <el-tab-pane label="回收站" name="fourth">回收站</el-tab-pane>
            <el-tab-pane label="博客管理" name="five">博客管理</el-tab-pane>
            <el-tab-pane label="博客配置" name="six">博客配置</el-tab-pane>
        </el-tabs>

    </div>
</template>

<script>
    export default {
        name: "ListShow",
        data: () => ({
            total:1,
            page:1,
            pageSize:5,
            form:{
                title:""
            },
            activeName: "second",
            tableData: [
                {
                    title:"感悟感悟",
                    date: '2016-05-03',
                    author: '王小虎',
                    type: '人生感悟'
                },{
                    title:"感悟感悟",
                    date: '2016-05-03',
                    author: '王小虎',
                    type: 'aaa'
                },{
                    title:"感悟感悟",
                    date: '2016-05-03',
                    author: '王小虎',
                    type: 'bbb'
                },
            ],
        }),
        methods: {
            handleClick(tab, event) {
                console.log(tab, event);
            },
            handlerEdit:function () {
                this.$router.push({name:"articleedit"})
            },
            handlerDelete: function () {
                this.$confirm('此操作将永久删除该文件, 是否继续?', '提示', {
                    confirmButtonText: '确定',
                    cancelButtonText: '取消',
                    type: 'warning'
                }).then(() => {
                    this.$message({
                        type: 'success',
                        message: '删除成功!'
                    });
                }).catch(() => {
                    this.$message({
                        type: 'info',
                        message: '已取消删除'
                    });
                });
            }
        },
        mounted: function () {
            this.$store.commit("changeActive", "/ListShow")
        }
    }
</script>

<style lang="scss" scoped>
    .el-tabs {
        margin-top: 20px;
    }
</style>