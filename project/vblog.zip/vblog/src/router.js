import Vue from 'vue'
import Router from 'vue-router'
import ListShow from "@/views/ListShow";
import ArticlePublish from "@/views/ArticlePublish";
import UserShow from "@/views/UserShow";
import ColumnShow from "@/views/ColumnShow";
import Count from "@/views/Count";
import Login from "@/Login";
import ArticleEdit from "@/views/ArticleEdit";
import UserAdd from "@/views/UserAdd";

Vue.use(Router);

export default new Router({
  routes: [
    {
      path:"/Login",
      name:"login",
      component:Login
    },
    {
      path:"/ListShow",
      name:"listshow",
      component:ListShow
    },
    {
      path:"/ArticlePublish",
      name:"articlepublish",
      component:ArticlePublish
    },
    {
      path:"/ArticleEdit",
      name:"articleedit",
      component:ArticleEdit
    },
    {
      path:"/UserShow",
      name:"usershow",
      component:UserShow
    },
    {
      path:"/UserAdd",
      name:"useradd",
      component:UserAdd
    },
    {
      path:"/ColumnShow",
      name:"columnshow",
      component:ColumnShow
    },
    {
      path:"/Count",
      name:"count",
      component:Count
    },
  ]
})
