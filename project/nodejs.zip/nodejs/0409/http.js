const http=require("http");
const server=http.createServer(function(req,res){
    // req  IncommingMessage
    // res  serverResponse
    let url=req.url;
    if(url==="/a"){
        res.write("a")
    }else if(url==="/b"){
        res.write("b")
    }else {
        res.write("hello");
    }
         //响应的内容
    res.end();          //结束响应
});
server.listen(8080);




