const fs=require("fs");
//1.读取文件  readFile     readFileSync
// fs.readFile("1.txt",'utf-8',(err,data)=>{
//     if(err){throw err}
//     console.log(data);
// });
// setTimeout(function(){
//     console.log(1);
// },0);
// let data=fs.readFileSync("1.txt","utf-8");
// console.log(data);
// console.log("其它同步代码");
//2. 写文件   writeFile   writeFileSync
// let str="你好";
// fs.writeFile("2.txt",str,function(err){
//     if(err){
//         throw err;
//     }
//     console.log("写人成功");
// });
// fs.writeFileSync('3.txt','同步写入');
//3. 追加写入  appendFile appendFileSync
//fs.appendFileSync('3.txt','同步写入');
//4. 删除文件 unlink  unlinkSync
// fs.unlink("3.txt",function(){
//
// });
//5. 拷贝文件 copyFile copyFileSync
// fs.copyFileSync("1.txt",'target.txt');
//1. mkdir  mkdirsync
// fs.mkdir("test",(err)=>{
//     if(err){
//         throw err;
//     }
// });
// 2. rmdir rmdirSync  只能用来删除空文件夹
// fs.rmdirSync("test");
// 3. readdir  readdirSync 读取文件夹
fs.readdir("./css",function(err,data){
    if(err){
        throw err;
    }
    let str="";
    data.forEach((name,index)=>{
        let r=fs.readFileSync("css/"+name,"utf-8");
        str+=r+"\n\r";
    });
    fs.writeFileSync("css/boundle.css",str);
});

// 异步编程
// 1 JS的运行机制   单线程异步机制
// 单线程---同时只能做一件事情
// 所有的操作都需要排队
// 对于所有要执行的操作 两类  同步任务 异步任务
// 同步任务  var for(){}  aa()
// 异步任务  setTimeout(function(){},1000) ajax xhr.send() xhr.onload=function(){}  div.onclick=function(){}
//3 事件循环
// js会先执行执行栈中的同步任务，把异步任务先放置到等待区域，等到执行栈当中的同步任务执行完成之后，再去到任务队列(回调函数队列  [function(){},function(){}])中进行查找，如果有可以被执行的任务，就将当前任务再放置到执行栈中执行，整个这个过程会不断循环进行，这种方式叫做事件循环。
// 异步任务可以被执行的时候会将它的回调函数放置到任务队列中等待被调用。











// 箭头函数
// function(a){return a*a}   a=>a*a
// function(a,b){return a+b} (a,b)=>a+b;
// function(){return Math.random()} ()=>Math.random()
// function(a){console.log(1)}  (a)=>{console.log(1)}
// function(a){return {name:'zhangsan'}} (a)=>({name:"zhangsan"})
