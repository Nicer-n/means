const express = require("express");
const path=require("path");
const app = express();
//路由
app.get("/", function (req, res) {
    res.sendFile(path.resolve("index.html"));
});
app.get("/login/:id", function(req,res,next){
    console.log("login被访问");
    next();
},function (req, res) {
    res.send("login");
});
const indexRouter=require("./routers/index");
const adminRouter=require("./routers/admin");
app.use("/index",indexRouter);
app.use("/admin",adminRouter);
app.set("view engine","ejs");
app.get("/news",function(req,res,next){
    let news=[1,2,3,4,5];
    res.render("index",{data:news})
});
app.listen(8080);
//webpack  基于nodejs的web项目打包工具