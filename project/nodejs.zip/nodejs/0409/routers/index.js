const express=require("express");
const router=express.Router();

router.get("/",function(req,res){
    res.send("index模块的首页")
});
module.exports=router;