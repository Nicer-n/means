let calc=require("calc");
console.log(calc(1,1,"+"));
console.log(calc(10,10,"*"));
// 1  npm -v 版本号
// 2  npm init 初始化一个nodejs包
// 3  npm init --yse 跳过配置 直接初始化一个nodejs包
// 4  npm install/i  包名 包名 .............
// 5. npm install 包名 --save
//   * dependencies 表示的是当前包依赖的包 当我们安装某个包的时候 它的dependencies中设置的其它包也会被自动安装
//   * 在安装某个包的时候添加上--save 这个包就会被添加到当前包的dependencies中
// 6. npm install 包名 --save-dev
//   * 在安装某个包的时候添加上--save-dev 这个包就会被添加到当前包的devDependencies中
// devDependencies 说明当前这个包只在开发阶段需要使用
// 7. npm install node-sass -g 全局安装
//  * 会把当前包安装到全局目录中 在全局目录当中的可执行程序都可以通过命令行直接被调用  nodemon
//  8. npm install -g cnpm --registry=https://registry.npm.taobao.org 切换下载源
//  9. npm install
//  * 根据当前package.json当中添加的依赖项进行下载安装
