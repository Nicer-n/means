//1 原生模块
// let fs=require("fs");
// let sum=require("./sum");
//2 绝对路径引入文件模块
// let sum=require("C:\\Users\\UEK-N\\Desktop\\nodejs\\sum.js");
//3 相对路径引入文件模块
// let data=require("./data.json");
//4 直接通过名字引入文件模块
// 如果当前模块并不是一个原生模块 nodejs会在当前文件夹下的node_modules中查找 如果在当前文件夹中的node_modules中没有 会继续到上一层文件夹中的node_modules中查找 直到找到根目录为止。
// let test=require("test");


// 模块
//在编写每个模块时，都有require、exports、module三个预先定义好的变量可供使用。
//module.exports 当当前模块被require引入的时候 require函数的返回值
//exports 对象 就是对于初始状态module.exports的一个引用
// let sum=require("C:\\Users\\UEK-N\\Desktop\\nodejs\\sum.js");
// console.log(sum(100,200));
// console.log(sum.fn(10,20));
// console.log(sum.a);
// console.log(sum.b);
// let a={};  //module.exports
// let b=a;   //exports
// b={}
// ;
// b.name="zhangsan";
// console.log(a);  //{}
// 原生js ECMAScript6 当中也有模块化的语法import和export
// nodejs 的模块化使用的require和module.exports 是属于Commonjs规范的。
// 包