let a=1;
let b=2;
function he(num1,num2){
    return num1+num2;
}

// module.exports.a=a;
// module.exports.b=b;
// module.exports.fn=he;
let obj={name:"zhangsan"};
module.exports=he;
