let sum=require("./src/sum");
let sub=require("./src/sub");
let mul=require("./src/mul");
let div=require("./src/div");
function calc(a,b,op){
   switch (op){
       case "+":return sum(a,b);break;
       case "-":return sub(a,b);break;
       case "*":return mul(a,b);break;
       case "/":return div(a,b);break;
   }
}
module.exports=calc;