function sub(a1,a2){
    return a1-a2;
}
module.exports=sub;