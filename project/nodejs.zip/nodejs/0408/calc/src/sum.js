function sum(a1,a2){
    return a1+a2;
}
module.exports=sum;