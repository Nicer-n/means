let mime=require("mime");
console.log(mime.getType('demo.docx'));
console.log(mime.getExtension('text/html'));
console.log(1);