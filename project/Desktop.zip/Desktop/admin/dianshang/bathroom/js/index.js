{
    let pagers = document.querySelectorAll(".headerSpots>li");
    let imgs = document.querySelectorAll(".headerImg>li");
    let header = document.querySelector(".header");
    let flag = false;
    let flag2 = true;
    let now = 0;
    let next = document.querySelector(".headerRight");
    let prev = document.querySelector(".headerLeft");
    pagers.forEach(function (ele, index) {
        ele.onclick = function () {
            flag = true;
            now = index;
            for (let i = 0; i < imgs.length; i++) {
                imgs[i].classList.remove("active");
                pagers[i].classList.remove("active");
            }
            imgs[index].classList.add("active");
            this.classList.add("active");
        }
    });

    function move() {
        now++;
        if (now === imgs.length) {
            now = 0;
        }
        if (now === -1) {
            now = imgs.length - 1;
        }
        for (let i = 0; i < imgs.length; i++) {
            imgs[i].classList.remove("active");
            pagers[i].classList.remove("active");
        }
        imgs[now].classList.add("active");
        pagers[now].classList.add("active");
    }

    let st = setInterval(move, 2000);
    header.onmouseenter = function () {
        clearInterval(st);
    };
    header.onmouseleave = function () {
        if (flag) {
            return;
        }
        st = setInterval(move, 2000);
    };
    next.onclick = function () {
        if (flag2) {
            flag2 = false;
            flag = true;
            move();
        }
    };
    prev.onclick = function () {
        if (flag2) {
            flag2 = false;
            now -= 2;
            flag = true;
            move();
        }
    };
    imgs.forEach(function (ele,index) {
        console.log(flag2);
        ele.addEventListener("transitionend",function () {
            console.log(flag2);
            flag2=true;
        })
    });
}
{
    let inner = document.querySelector(".newInner");
    let next = document.querySelector(".newButton>span:last-child");
    let pre = document.querySelector(".newButton>span:first-child");
    let wrapper = document.querySelector("#newWrapper");
    let num = 4;
    let flag = true;

    function goods() {
        inner.style.transition = "all 1s";
        num++;
        inner.style.marginLeft = -num * 300 + "px"
    }
    let st = setInterval(goods, 2000);
    inner.addEventListener("transitionend", function () {
        flag = true;
        if (num === 8) {
            num = 4;
            inner.style.transition = "none";
            inner.style.marginLeft = -300 * num + "px";
        }
        if (num === 0) {
            num = 4;
            inner.style.transition = "none";
            inner.style.marginLeft = -300 * num + "px";

        }
    });
    wrapper.onmouseenter = function () {
        clearInterval(st);
    };
    wrapper.onmouseleave = function () {
        clearInterval(st);
        st = setInterval(goods, 2000);
    };
    window.addEventListener("blur", function () {
        clearInterval(st);
        st = setInterval(goods, 2000);
    });
    window.addEventListener("focus", function () {
        clearInterval(st);
    });
    next.onclick = function () {
        next.classList.add("active");
        pre.classList.remove("active");
         if (flag) {
            flag = false;
            goods();
        }
    };
    pre.onclick = function () {
        pre.classList.add("active");
        next.classList.remove("active");
        if (flag) {
           flag = false;
            num -= 2;
            goods();
        }
    }
}
{
    let title = document.querySelectorAll(".commonHeader");
    let tu1 = document.querySelector(".top");
    let tu = document.querySelector(".new");
    window.onscroll = function () {
        let st = document.documentElement.scrollTop;
        //console.log(st);
        title.forEach(function (ele) {
            let target2 = ele.offsetTop-window.innerHeight;
            if (st > target2) {
                ele.classList.add("fadeInDown");
            }
        });
        let t = tu.offsetTop-window.innerHeight;
        if(st>t){
            tu1.style.display="block";
        }else{
            tu1.style.display="none";
        }
    }
}
{
    {
        let toTop = document.querySelector(".itemBar");

        let duration = 800;
        toTop.onclick = function () {
            let l = document.documentElement.scrollTop;
            let speed = 25 * l / duration;
            let dd = setInterval(function () {
                l -= speed;
                if (l < 0) {
                    l = 0;
                    clearInterval(dd);
                }
                document.documentElement.scrollTop = l;
            });
        }
    }
}
