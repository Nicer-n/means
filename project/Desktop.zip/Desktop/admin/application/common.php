<?php
// +----------------------------------------------------------------------
// | ThinkPHP [ WE CAN DO IT JUST THINK ]
// +----------------------------------------------------------------------
// | Copyright (c) 2006-2016 http://thinkphp.cn All rights reserved.
// +----------------------------------------------------------------------
// | Licensed ( http://www.apache.org/licenses/LICENSE-2.0 )
// +----------------------------------------------------------------------
// | Author: 流年 <liu21st@gmail.com>
// +----------------------------------------------------------------------
use think\JWT;
// 应用公共文件
function check(){
    if(isset($_SERVER['HTTP_X_ACCESS_TOKEN'])){
        $token=$_SERVER['HTTP_X_ACCESS_TOKEN'];
        $key=config("key");
        $payload=JWT::verify($token,$key);
        if(!$payload){
            return json(["msg"=>"token验证失败","code"=>404]);
        }else{
            return true;
        }
    }else{
        return json(["msg"=>"token验证失败","code"=>404]);
    }
}