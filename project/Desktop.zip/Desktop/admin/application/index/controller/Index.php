<?php
/**
 * Created by PhpStorm.
 * User: UEK-N
 * Date: 2019/5/9
 * Time: 10:41
 */

namespace app\index\controller;
use app\model\ExeGoodsModel;
use app\model\GoodsModel;
use app\model\OrderExeModel;
use app\model\OrderModel;
use app\model\TypeModel;
use app\model\UsersModel;
use think\Controller;
use think\Session;

class Index extends Controller
{
    function index(){
        $data=GoodsModel::order("id","desc")->limit(0,8)->select();
        return view("index",["newgoods"=>$data,"hot"=>"index"]);
    }
    function category($tid=''){
        $data=TypeModel::all();
        $where=[];
        $search=input("get.search");
        if($tid!==""){
            $where['tid']=$tid;
        }
        if(isset($search)){
            $where['name_ch']=["like","%$search%"];
        }
        $goodsData=GoodsModel::where($where)->paginate(16,false,[
            'fragment'=>"goods"
        ]);
        $total=GoodsModel::where($where)->count();
        return view("category",
            [
            "hot"=>"category",
            "total"=>$total,
            "category"=>$data,
            "goods"=>$goodsData
            ]
        );
    }
    function show($id){
        $goods=ExeGoodsModel::get($id);
        $pics=$goods->pics;
        $picarr=explode(";",$pics);
        $sizes=$goods->sizes;
        $sizearr=explode(",",$sizes);
        return view("show",[
            "hot"=>"category",
            "goods"=>$goods,
            "pics"=>$picarr,
            "sizes"=>$sizearr
        ]);
    }
    function shoppingcar(){
        $r=Session::get("login");
        if(!isset($r)){
           return redirect("/index/index/login",301);
        }
        $data=input("get.");
        if(isset($data['gid'])) {
            $data['uid'] = $r;
            $model = new OrderExeModel();
            $model->allowField(true)->save($data);
        }
        $order=OrderModel::paginate(5);
        return view("shoppingcar",[
            "hot"=>"category",
            "order"=>$order
        ]);
    }
    function login(){
        return view();
    }
    function checklogin(){
        $data=input("post.");
        $r=UsersModel::getByPhone($data['username']);
        if($r){
         if($r->password===md5($data['password'])){
           Session::set("login",$r->id);
           $this->success("登录成功","index");
         }else{
           $this->error("密码错误","login");
         }
        }else{
          $this->error("用户不存在","login");
        }
    }

}