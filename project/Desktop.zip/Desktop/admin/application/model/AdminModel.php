<?php
/**
 * Created by PhpStorm.
 * User: UEK-N
 * Date: 2019/4/24
 * Time: 9:56
 */

namespace app\model;


use think\Model;

class AdminModel extends Model
{
   public $table="admin";
}