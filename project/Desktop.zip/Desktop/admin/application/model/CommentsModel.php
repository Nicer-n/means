<?php
/**
 * Created by PhpStorm.
 * User: UEK-N
 * Date: 2019/4/22
 * Time: 15:14
 */

namespace app\model;


use think\Model;

class CommentsModel extends Model
{
   public $table="comments_users_goods";
}