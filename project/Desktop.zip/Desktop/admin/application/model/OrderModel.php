<?php
/**
 * Created by PhpStorm.
 * User: UEK-N
 * Date: 2019/5/6
 * Time: 15:23
 */
namespace app\model;
use think\Model;
class OrderModel extends Model
{
   public $table="orders_goods";
}