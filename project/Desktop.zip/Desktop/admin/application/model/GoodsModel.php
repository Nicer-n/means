<?php
/**
 * Created by PhpStorm.
 * User: UEK-N
 * Date: 2019/4/19
 * Time: 10:48
 */

namespace app\model;

use think\Model;

class GoodsModel extends Model
{
  public $table="goods_view";
}