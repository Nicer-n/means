<?php
/**
 * Created by PhpStorm.
 * User: UEK-N
 * Date: 2019/4/18
 * Time: 15:55
 */

namespace app\model;


use think\Model;

class TypeModel extends Model
{
   public $table="type";
}