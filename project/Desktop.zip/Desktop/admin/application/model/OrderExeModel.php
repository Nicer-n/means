<?php
/**
 * Created by PhpStorm.
 * User: UEK-N
 * Date: 2019/5/6
 * Time: 16:24
 */

namespace app\model;


use think\Model;

class OrderExeModel extends Model
{
    public $table="orders";
}