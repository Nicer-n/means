<?php
/**
 * Created by PhpStorm.
 * User: UEK-N
 * Date: 2019/5/8
 * Time: 16:09
 */

namespace app\model;

use think\Model;

class CollectModel extends Model
{
   public $table="collect";
}