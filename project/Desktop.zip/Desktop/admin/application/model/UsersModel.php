<?php
/**
 * Created by PhpStorm.
 * User: UEK-N
 * Date: 2019/4/16
 * Time: 16:13
 */

namespace app\model;

use think\Model;

class UsersModel extends Model
{
   public $table="users";
}