<?php
/**
 * Created by PhpStorm.
 * User: UEK-N
 * Date: 2019/4/19
 * Time: 16:23
 */

namespace app\model;

use think\Model;

class ExeGoodsModel extends Model
{
   public $table="goods";
}