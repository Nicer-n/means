<?php
/**
 * Created by PhpStorm.
 * User: UEK-N
 * Date: 2019/5/7
 * Time: 14:18
 */
namespace app\model;

use think\Model;

class AddressModel extends Model
{
   public $table="address";
}