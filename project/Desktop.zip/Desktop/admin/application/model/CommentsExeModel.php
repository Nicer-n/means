<?php
/**
 * Created by PhpStorm.
 * User: UEK-N
 * Date: 2019/4/22
 * Time: 15:31
 */

namespace app\model;


use think\Model;

class CommentsExeModel extends Model
{
   public $table="comments";
}