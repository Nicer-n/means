<?php
/**
 * Created by PhpStorm.
 * User: UEK-N
 * Date: 2019/4/16
 * Time: 15:54
 */

namespace app\api\controller;

use think\controller\Rest;
use app\model\UsersModel as Model;
use think\Exception;
use think\Session;
use think\JWT;

class Users extends Rest
{
    function users()
    {
        $r=check();
        if($r!==true){
            return $r;
        }
        switch ($this->method) {
            case "get":
                return $this->get();
            case "post":
                return $this->post();
            case "put":
                return $this->put();
            case "delete":
                return $this->delete();
        }
    }

    private function get()
    {
       $page=input("get.page")?input("get.page"):1;
       $pageSize=input("get.pageSize")?input("get.pageSize"):5;
       $search=input("get.search");
       $id=input("get.id");
       if(!isset($id)) {
           if ($search !== "") {
               $where = ["username" => ["like", "%$search%"]];
           } else {
               $where = [];
           }
           $start = ($page - 1) * $pageSize;
           $data = Model::where($where)->limit($start, $pageSize)->select();
           $total = Model::where($where)->count();
           return json(["data" => $data, "code" => 200, "msg" => "获取成功", "total" => $total]);
       }else{
           $r=Model::get($id);
           if($r){
               return json(["data"=>$r,"code"=>200,"msg"=>"获取成功"]);
           }else{
               return json(["code"=>404,"msg"=>"获取失败"]);
           }
       }
    }

    private function post()
    {
       try {
           $model = new Model();
           $data = input("post.");
           $r=$model->where('username',$data['username'])->find();
           if($r){
               return json(["code" => 404, "msg" => "用户名已存在"]);
           }
           $data['password'] = md5($data['password']);
           $r = $model->allowField(true)->save($data);
           if ($r) {
               return json(["code" => 200, "msg" => "添加成功"]);
           } else {
               return json(["code" => 404, "msg" => "添加失败"]);
           }
       }catch(Exception $e){
           return json(["code" => 500, "msg" => "添加失败"]);
       }
   }

    private function put()
    {
        $data=input("put.");
        $model=new Model();
        if(isset($data['password'])){
            $data['password']=md5($data['password']);
        }
        $r=$model->allowField(true)->isUpdate(true)->save($data);
        if($r){
            return json(["code"=>200,"msg"=>"修改成功"]);
        }else{
            return json(["code"=>404,"msg"=>"修改失败"]);
        }
    }

    private function delete()
    {
        $id=input("get.id");
        $r=Model::destroy($id);
        if($r){
          return json(["msg"=>"删除成功","code"=>200]);
        }else{
          return json(["msg"=>"删除失败","code"=>404]);
        }
    }

    public function sendMessage(){
        $phone=input("post.phone");
        $code='1234'; //一般是随机数
        Session::set("code",$code);
        /*
         *  调用对应的api接口完成短信的发送
         * */
        return json(["msg"=>"提交成功","code"=>200]);
    }
    public function checkCode(){
       $code=input("post.code");
       if($code===Session::get('code')){
           return json(["code"=>200,"msg"=>"验证通过"]);
       }else{
           return json(["code"=>404,"msg"=>"验证失败"]);
       }
    }
    public function sign(){
        $phone=input("post.phone");
        $password=input("post.password");
        $model=new Model();
        $model->phone=$phone;
        $user=$model->where("phone",$phone)->find();
        if($user){
            return json(["msg"=>"该手机号已被使用","code"=>400]);
        }
        $model->password=md5($password);
        $r=$model->save();
        if($r){
            return json(["msg"=>"注册成功","code"=>200]);
        }else{
            return json(["msg"=>"注册失败","code"=>404]);
        }
    }
    public function login(){
        $phone=input("post.phone");
        $password=input("post.password");
        $r=Model::getByPhone($phone);
        if($r){
           if($r->password===md5($password)){
               $payload=[
                   "phone"=>$phone,
                   "password"=>$password
               ];
               $key=config("key");
               $token=JWT::getToken($payload,$key);
               return json(['msg'=>"登录成功","code"=>200,"token"=>$token,"id"=>$r->id]);
           }else{
               return json(["msg"=>"密码错误","code"=>404]);
           }
        }else{
           return json(["msg"=>"该用户不存在","code"=>404]);
        }
    }
}