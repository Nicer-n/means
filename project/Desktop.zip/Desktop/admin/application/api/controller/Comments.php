<?php
/**
 * Created by PhpStorm.
 * User: UEK-N
 * Date: 2019/4/22
 * Time: 15:15
 */

namespace app\api\controller;


use think\controller\Rest;
use app\model\CommentsModel as Model;
use app\model\CommentsExeModel;

class Comments extends Rest
{
   public function comments(){
       $r=check();
       if($r!==true){
           return $r;
       }
       switch ($this->method){
           case "get":return $this->get();
           case "post":return $this->post();
           case "delete":return $this->delete();
           case "put":return $this->put();
       }
   }
   private function get(){
       $page=input("get.page");
       $pageSize=input("get.pageSize");
       $userName=input("get.userName");
       $goodsName=input("get.goodsName");
       $id=input("get.id");
       if(isset($page)&&isset($pageSize)) {
           $where=[];
           if($userName){
             $where["username"]=$userName;
           }
           if($goodsName){
             $where["name_ch"]=$goodsName;
           }
           $start = ($page - 1) * $pageSize;
           $data = Model::where($where)->order('time', "DESC")->limit($start, $pageSize)->select();
           $total = Model::where($where)->count();
           if ($data||$total==0) {
               return json(["data" => $data, "code" => 200, "msg" => "获取成功", "total" => $total]);
           } else {
               return json(["code" => 404, "msg" => "获取失败"]);
           }
       }else if(isset($id)){
           $data=Model::getById($id);
           if($data){
               return json(["msg"=>'获取成功','code'=>200,"data"=>$data]);
           }else{
               return json(["msg"=>'获取失败','code'=>404]);
           }
       }else{
           $data=Model::all();
           if($data){
               return json(["msg"=>"获取成功","code"=>200,"data"=>$data]);
           }else{
               return json(["msg"=>"获取失败","code"=>404]);
           }
       }
   }
   private function delete(){
       $id=input("get.id");
       $r=CommentsExeModel::destroy($id);
       if($r){
           return json(["msg"=>"删除成功","code"=>200]);
       }else{
           return json(["msg"=>"删除失败","code"=>404]);
       }
   }
   private function put(){
       $data=input("put.");
       $model=new CommentsExeModel;
       $r=$model->allowField(true)->isUpdate(true)->save($data);
       if($r){
           return json(["msg"=>"修改成功","code"=>200]);
       }else{
           return json(["msg"=>"修改失败","code"=>404]);
       }
   }
}