<?php
/**
 * Created by PhpStorm.
 * User: UEK-N
 * Date: 2019/4/17
 * Time: 15:22
 */

namespace app\api\controller;


use think\Request;

class Upload
{
  function upload(Request $request){
      $file = $request->file('file');
      if (empty($file)) {
         return "";
      }
      $info = $file->move(ROOT_PATH . 'public' . DS . 'uploads');
      if ($info) {
           $path=str_replace("\\","/",$info->getSaveName());
           return '/uploads/'.$path;
      } else {
          return "";
      }

  }
}