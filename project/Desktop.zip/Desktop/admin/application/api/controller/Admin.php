<?php
/**
 * Created by PhpStorm.
 * User: UEK-N
 * Date: 2019/4/22
 * Time: 17:52
 */

namespace app\api\controller;

use app\model\AdminModel as Model;
use think\controller\Rest;
use think\JWT;
class Admin extends Rest
{
   function captcha(){
       $captcha=new \think\captcha\Captcha();
       $captcha->length=4;
       $captcha->imageW=200;
       $captcha->imageH=50;
       return $captcha->entry();
   }
   function checkLogin(){
       $code=input("post.code");
       $name=input("post.name");
       $password=input("post.password");
       $captcha=new \think\captcha\Captcha();
       if($captcha->check($code)){
           $r=Model::getByName($name);
           if(isset($r)){
              if($r->state!==1){
                  return json(["code"=>404,"msg"=>"暂无登录权限"]);
              }
              if($r->password===md5($password)){
                  $payload=[
                     "name"=>$name,
                     "role"=>$r->role
                  ];
                  $key=config("key");
                  $token=JWT::getToken($payload,$key);
                  return json(["code"=>200,"msg"=>"登录成功","name"=>$name,"role"=>$r->role,"token"=>$token]);
              }else{
                  return json(["code"=>404,"msg"=>"密码错误"]);
              }
           }else{
              return json(["code"=>404,"msg"=>"用户名不存在"]);
           }
       }else{
           return json(["code"=>404,"msg"=>"验证码错误"]);
       }
   }
   function changePassword(){
      $data=input("put.");
      if(empty($data)){
          return json(["msg"=>"请提交验证数据","code"=>404]);
      }
      if(!isset($data['password'])){
          return json(["msg"=>"请提交密码","code"=>404]);
      }
      if(!isset($data['newpassword1'])){
           return json(["msg"=>"请提交新密码","code"=>404]);
      }
      $r=Model::where(["name"=>$data['name'],"password"=>md5($data['password'])])->find();
      if(isset($r)){
          $r->password=md5($data['newpassword1']);
          $res=$r->isUpdate(true)->save();
          if($res){
              return json(["msg"=>"修改成功","code"=>200]);
          }else{
              return json(["msg"=>"修改失败","code"=>404]);
          }
      }else{
         return json(["msg"=>"原始密码错误","code"=>404]);
      }
   }
   function admin(){
       $r=check();
       if($r!==true){
           return $r;
       }
       switch ($this->method){
           case "get":return $this->get();
           case "post":return $this->post();
           case "delete":return $this->delete();
           case "put":return $this->put();
       }
   }
   private function get(){
       $page=input("get.page");
       $pageSize=input("get.pageSize");
       $search=input("get.search");
       $start=($page-1)*$pageSize;
       $id=input("get.id");
       if(!isset($id)) {
           if ($search !== "") {
               $data = Model::where("name", ["<>", "admin"], ['like', "%$search%"], "and")->limit($start, $pageSize)->select();
               $total = Model::where("name", ["<>", "admin"], ['like', "%$search%"], "and")->count();
           } else {
               $data = Model::where("name", "<>", "admin")->limit($start, $pageSize)->select();
               $total = Model::where("name", "<>", "admin")->count();
           }
           if ($data || $total === 0) {
               return json(['msg' => "查询成功", "code" => 200, "data" => $data, "total" => $total]);
           } else {
               return json(["msg" => "查询失败", "code" => 404]);
           }
       }else{
           $r=Model::get($id);
           if($r){
               return json(["data"=>$r,"code"=>200,"msg"=>"获取成功"]);
           }else{
               return json(["code"=>404,"msg"=>"获取失败"]);
           }
       }
   }
   private function post(){
       try {
           $model = new Model();
           $data = input("post.");
           $r=$model->where('name',$data['name'])->find();
           if($r){
               return json(["code" => 404, "msg" => "管理员已存在"]);
           }
           $data['password'] = md5($data['password']);
           $r = $model->allowField(true)->save($data);
           if ($r) {
               return json(["code" => 200, "msg" => "添加成功"]);
           } else {
               return json(["code" => 404, "msg" => "添加失败"]);
           }
       }catch(Exception $e){
           return json(["code" => 500, "msg" => "添加失败"]);
       }
   }
   private function put(){
       $data=input("put.");
       $model=new Model();
       if(isset($data['password'])){
           $data['password']=md5($data['password']);
       }
       $r=$model->allowField(true)->isUpdate(true)->save($data);
       if($r){
           return json(["msg"=>"修改成功","code"=>200]);
       }else{
           return json(["msg"=>"修改失败","code"=>404]);
       }
   }
   private function delete(){
       $id=input("get.id");
       $r=Model::destroy($id);
       if($r){
           return json(["msg"=>"删除成功","code"=>200]);
       }else{
           return json(["msg"=>"删除失败","code"=>404]);
       }
   }
}