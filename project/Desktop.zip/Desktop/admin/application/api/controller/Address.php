<?php
/**
 * Created by PhpStorm.
 * User: UEK-N
 * Date: 2019/5/7
 * Time: 14:20
 */

namespace app\api\controller;

use app\model\AddressModel as Model;
use think\controller\Rest;

class Address extends Rest
{
   function address(){
       $r = check();
       if ($r !== true) {
           return $r;
       }
       switch ($this->method){
           case "get":return $this->get();
           case "post":return $this->post();
           case "delete":return $this->delete();
           case "put":return $this->put();
       }
   }
   private function get(){
       $uid=input("get.uid");
       $is_default=input("get.is_default");
       if(isset($uid)){
           if(isset($is_default)){
               $r=Model::where("uid",$uid)->where("is_default",$is_default)->find();
           }else{
               $r=Model::where("uid",$uid)->select();
           }
           if($r||empty($r)){
               return json(['msg'=>'获取成功',"code"=>200,"data"=>$r]);
           }else{
               return json(["msg"=>'获取失败',"code"=>404]);
           }
       }
   }
}