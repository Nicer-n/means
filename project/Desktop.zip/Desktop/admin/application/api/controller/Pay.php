<?php
/**
 * Created by PhpStorm.
 * User: UEK-N
 * Date: 2019/5/7
 * Time: 17:25
 */

namespace app\api\controller;


class Pay
{
   function pay(){
      // 接入支付接口 返回支付结果
      return json(["msg"=>"支付成功","code"=>200]);
   }
}