<?php if (!defined('THINK_PATH')) exit(); /*a:3:{s:81:"C:\Users\UEK-N\Desktop\admin\public/../application/index\view\index\category.html";i:1557451856;s:70:"C:\Users\UEK-N\Desktop\admin\application\index\view\common\header.html";i:1557475708;s:70:"C:\Users\UEK-N\Desktop\admin\application\index\view\common\footer.html";i:1557373286;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>产品分类</title>
    <link rel="stylesheet" href="/static/css/base.css">
    <link rel="stylesheet" href="/static/css/productCategory.css">
    <link rel="stylesheet" href="/static/css/goodsDetails.css">
    <link rel="stylesheet" href="/static/css/listShow.css">
    <link rel="stylesheet" href="/static/css/swiper.min.css">
</head>
<body>
<!--导航栏-->
<div class="nav active">
    <div class="container navHeader">
        <div class="navVicor">
            <img src="/static/images/indexLogo.png" alt="">
        </div>
        <div class="navTop">
            <div class="navSearch">
                <input type="text" placeholder="请输入您想要的商品">
                <a href="#"><i>&#xe603;</i></a>
            </div>
            <div class="navCar">
                <a href="#"><i>&#xe620;</i></a>
                <div class="navCarPoint"></div>
            </div>
            <?php if(\think\Session::get('login')): ?>
            <a href=""><div class="navLogin">个人中心</div></a>
            <?php else: ?>
            <a href=""><div class="navLogin">登录</div></a>
            <a href=""><div class="navRegister">注册</div></a>
            <?php endif; ?>
        </div>
        <div class="navBottom">
            <a href="<?php echo url('/'); ?>">
                <div class="navBottomText <?php if($hot==='index'): ?>active<?php endif; ?> marginLeft">
                    首页
                </div>
            </a>
            <a href="<?php echo url('/index/index/category'); ?>">
                <div class="navBottomText <?php if($hot==='category'): ?>active<?php endif; ?>">
                    产品分类
                </div>
            </a>
            <a href="caseShow.html">
                <div class="navBottomText">
                    案例展示
                </div>
            </a>
            <a href="brandStory.html">
                <div class="navBottomText">
                    品牌故事
                </div>
            </a>
            <a href="designTeam.html">
                <div class="navBottomText">
                    设计团队
                </div>
            </a>
        </div>
    </div>
</div>

<!--产品分类-->
<div class="commonHeader product animated">
    <div class="commonLine"></div>
    <div class="commonLongLine"></div>
    <div class="commonEnglish">PRODUCT CATEGORY</div>
    <div class="commonTitle"><span>产品</span><span>分类</span></div>
    <div class="commonBlackLine"></div>
</div>
<div class="commodity container">
    <div class="swiper-container">
        <div class="swiper-wrapper">
            <?php if(is_array($category) || $category instanceof \think\Collection || $category instanceof \think\Paginator): $i = 0; $__LIST__ = $category;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$v): $mod = ($i % 2 );++$i;?>
            <div class="swiper-slide">
                    <a href="<?php echo url('/index/index/category',['tid'=>$v['id']]); ?>#goods" class="commodityRealistic">
                        <img src="<?php echo $v['thumb']; ?>" alt="" class="commodityRealisticBottom">
                        <img src="<?php echo $v['thumb']; ?>" alt="" class="commodityRealisticTop">
                        <div class="commodityRealisticLine"></div>
                        <p class="commodityRealisticText"><?php echo $v['category']; ?></p>
                        <!--<p class="commodityRealisticText1">REAL VIEW</p>-->
                    </a>
            </div>
            <?php endforeach; endif; else: echo "" ;endif; ?>
        </div>
    </div>
</div>
<!--商品详情-->
<a name="goods"></a>
<div class="details">
    <div class="commonHeader animated">
        <div class="commonLine"></div>
        <div class="commonLongLine"></div>
        <div class="commonEnglish">COMMODITY DETAILS</div>
        <div class="commonTitle"><span>商品</span><span>详情</span></div>
        <div class="commonBlackLine"></div>
    </div>
    <div class="detailSearch">
        <form action="<?php echo url('index/index/category'); ?>#goods" method="get" name="myform">
          <input type="text" placeholder="桌椅/休闲风" class="detailInput" name="search" required>
          <i class="detailIcon" onclick="document.myform.submit()">&#xe603;</i>
        </form>
    </div>
    <!--<div class="detailList container">-->
    <!--<span class="detailKindOne">类型</span>-->
    <!--<span class="detailKind3">沙发</span>-->
    <!--<span class="detailKind4">床</span>-->
    <!--<span class="detailKind1">桌椅</span>-->
    <!--<span class="detailKind">茶几</span>-->
    <!--<span class="detailKind">床头柜</span>-->
</div>
<!--<div class="detailLine"></div>-->
<!--<div class="detailList1 container">-->
<!--<span class="detailKindOne">空间</span>-->
<!--<span class="detailKind3">卧室</span>-->
<!--<span class="detailKind4">客厅</span>-->
<!--<span class="detailKind2">餐厅</span>-->
<!--<span class="detailKind5">儿童房</span>-->
<!--<span class="detailKind">其他</span>-->
<!--</div>-->
<!--<div class="detailLine"></div>-->
<!--<div class="detailList1 container">-->
<!--<span class="detailKindOne">颜色</span>-->
<!--<img src="/static/images/listShowDot1.png" alt="" class="detailImg1">-->
<!--<img src="/static/images/listShowDot2.png" alt="" class="detailImg2">-->
<!--<img src="/static/images/listShowDot3.png" alt="" class="detailImg3">-->
<!--<img src="/static/images/listShowDot4.png" alt="" class="detailImg4">-->
<!--<img src="/static/images/listShowDot5.png" alt="" class="detailImg5">-->
<!--<img src="/static/images/listShowDot6.png" alt="" class="detailImg6">-->
<!--<img src="/static/images/listShowDot7.png" alt="" class="detailImg7">-->
<!--</div>-->
<!--<div class="detailLine"></div>-->
<!--<div class="detailList1 container">-->
<!--<span class="detailKindOne">风格</span>-->
<!--<span class="detailKinds">休闲风</span>-->
<!--<span class="detailKind">欧式风</span>-->
<!--<span class="detailKind4">现代风</span>-->
<!--<span class="detailKind">美式风</span>-->
<!--<span class="detailKind">复古风</span>-->
<!--</div>-->
<div class=" container">
    <div class="detail">共搜到<span class="detailSpecial"><?php echo $total; ?></span>条符合条件的商品</div>
</div>
<div class="newWrapper1 container">
    <?php if(is_array($goods) || $goods instanceof \think\Collection || $goods instanceof \think\Paginator): $i = 0; $__LIST__ = $goods;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$v): $mod = ($i % 2 );++$i;?>
    <div class="newGoodBox">
        <div><img src="<?php echo $v['thumb']; ?>" alt="" class="newImg"></div>
        <div class="newLine"></div>
        <div class="newWord">
            <p><?php echo $v['name_en']; ?> </p>
            <p><?php echo $v['name_ch']; ?></p>
        </div>
        <div class="newPrice"><?php echo $v['price']; ?><span>RMB</span></div>
        <a href="<?php echo url('index/index/show',['id'=>$v['id']]); ?>">
            <div class="newBuy"><i>&#xe60f;</i>点击购买</div>
        </a>
        <img src="/static/images/indexHot.png" alt="" class="newHot">
    </div>
    <?php endforeach; endif; else: echo "" ;endif; ?>
</div>
<!--<div class="page">-->
<!--<div class="leftArrow"><i>&#xe82a;</i></div>-->
<!--<div class="pageNumber">1</div>-->
<!--<div class="pageNumber">2</div>-->
<!--<div class="pageNumber active1">3</div>-->
<!--<div class="pageNumber">4</div>-->
<!--<div class="pageNumber">5</div>-->
<!--<div class="ellipsis">......</div>-->
<!--<div class="pageNumber">18</div>-->
<!--<div class="pageNumber">19</div>-->
<!--<div class="rightArrow"><i>&#xe61b;</i></div>-->
<!--<p class="pageWord">跳转到</p>-->
<!--<span class="kong"></span>-->
<!--<p class="pageWord">页</p>-->
<!--<span class="go">go</span>-->
<!--</div>-->
<style>
    .pagination {
        width: 100%;
        height: 30px;
        display: flex;
        align-items: center;
        justify-content: center;
    }

    .pagination li {
        width: 30px;
        height: 30px;
        line-height: 30px;
        margin: 0 20px;
        text-align: center;
    }
</style>
<div class="page">
    <?php echo $goods->render(); ?>
</div>
</div>
<!--为你推荐-->
<div class="recommend">
    <div class="commonHeader animated">
        <div class="commonLine"></div>
        <div class="commonLongLine"></div>
        <div class="commonEnglish">commend</div>
        <div class="commonTitle"><span>为你</span><span>推荐</span></div>
        <div class="commonBlackLine"></div>
    </div>
    <div id="newWrapper" class="container">
        <div class="newGoodBox active">
            <div><img src="/static/images/indexNew.png" alt="" class="newImg"></div>
            <div class="newLine"></div>
            <div class="newWord">
                <p>VERFO LAB </p>
                <p>现代简约时尚布艺沙发</p>
            </div>
            <div class="newPrice">800<span>RMB</span></div>
            <a href="">
                <div class="newBuy"><i>&#xe60f;</i>点击购买</div>
            </a>
        </div>
        <div class="newGoodBox ">
            <img src="/static/images/indexNew2.png" alt="" class="newImg">
            <div class="newLine"></div>
            <div class="newWord">
                <p>VERFO LAB </p>
                <p>现代简约时尚布艺沙发</p>
            </div>
            <div class="newPrice">800<span>RMB</span></div>
            <a href="">
                <div class="newBuy"><i>&#xe60f;</i>点击购买</div>
            </a>

        </div>
        <div class="newGoodBox ">
            <img src="/static/images/indexNew5.png" alt="" class="newImg">
            <div class="newLine"></div>
            <div class="newWord">
                <p>VERFO LAB </p>
                <p>现代简约时尚布艺沙发</p>
            </div>
            <div class="newPrice">800<span>RMB</span></div>
            <a href="">
                <div class="newBuy"><i>&#xe60f;</i>点击购买</div>
            </a>

        </div>
        <div class="newGoodBox ">
            <img src="/static/images/indexNew6.png" alt="" class="newImg">
            <div class="newLine"></div>
            <div class="newWord">
                <p>VERFO LAB </p>
                <p>现代简约时尚布艺沙发</p>
            </div>
            <div class="newPrice">800<span>RMB</span></div>
            <a href="">
                <div class="newBuy"><i>&#xe60f;</i>点击购买</div>
            </a>

        </div>
    </div>
</div>
<!--底部-->
<div class="footer active">
    <div class=" footerItem container ">
        <div class="footerCode">
            <div class="footerImg">
                <img src="/static/images/indexCode.png" alt="">
            </div>
            <p>扫码关注我们</p>
        </div>
        <div class="footerList">
            <h2>全部商品</h2>
            <div class="footerListItem">
                <a href=""> <p>沙发</p></a>
                <a href=""><p>床</p></a>
                <a href=""> <p>椅子</p></a>
            </div>
        </div>
        <div class="footerList">
            <h2>新品发布</h2>
            <div class="footerListItem">
                <a href=""><p>物流配送</p></a>
                <a href=""><p>免运费政策</p></a>
                <a href=""><p>物流配送服务</p></a>
                <a href=""><p>签收验货</p></a>
                <a href=""><p>物流查询</p></a>
            </div>
        </div>
        <div class="footerList">
            <h2>售后服务</h2>
            <div class="footerListItem">
                <a href=""><p>退换货政策</p></a>
                <a href=""> <p>贵就赔</p></a>
                <a href=""> <p>维修/安装</p></a>
                <a href=""> <p>订单修改</p></a>
                <a href="">  <p>退换货申请</p></a>
                <a href="">  <p>我的发票</p></a>
            </div>
        </div>
        <div class="footerList">
            <h2>关于我们</h2>
            <div class="footerListItem">
                <a href=""> <p>客服热线：400-320-0031</p></a>
                <a href=""> <p>客服邮箱：867321000@qq.com</p></a>
                <a href=""> <p>地址：山西省太原市小店区VICRO总部</p></a>
            </div>
        </div>
    </div>
    <div class="footerLine container">
        <div class="underline"></div>
        <div class="orange"></div>
    </div>
    <p>Copyright ©2018 www.guazi.com All Rights Reserved  |  京ICP备15053955号 ICP证151071号</p>
</div>
<script src="/static/js/swiper.min.js"></script>
<script>
    new Swiper(".swiper-container", {
        slidesPerView: 3,
        loop: true,
    });
</script>
</body>
</html>