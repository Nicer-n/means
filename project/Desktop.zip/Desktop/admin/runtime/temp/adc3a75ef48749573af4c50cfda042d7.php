<?php if (!defined('THINK_PATH')) exit(); /*a:3:{s:77:"C:\Users\UEK-N\Desktop\admin\public/../application/index\view\index\show.html";i:1557477874;s:70:"C:\Users\UEK-N\Desktop\admin\application\index\view\common\header.html";i:1557475708;s:70:"C:\Users\UEK-N\Desktop\admin\application\index\view\common\footer.html";i:1557373286;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>商品详情</title>
    <link rel="stylesheet" href="/static/css/base.css">
    <link rel="stylesheet" href="/static/css/goodsDetails.css">
</head>
<body>
<!--导航栏-->
<div class="nav active">
    <div class="container navHeader">
        <div class="navVicor">
            <img src="/static/images/indexLogo.png" alt="">
        </div>
        <div class="navTop">
            <div class="navSearch">
                <input type="text" placeholder="请输入您想要的商品">
                <a href="#"><i>&#xe603;</i></a>
            </div>
            <div class="navCar">
                <a href="#"><i>&#xe620;</i></a>
                <div class="navCarPoint"></div>
            </div>
            <?php if(\think\Session::get('login')): ?>
            <a href=""><div class="navLogin">个人中心</div></a>
            <?php else: ?>
            <a href=""><div class="navLogin">登录</div></a>
            <a href=""><div class="navRegister">注册</div></a>
            <?php endif; ?>
        </div>
        <div class="navBottom">
            <a href="<?php echo url('/'); ?>">
                <div class="navBottomText <?php if($hot==='index'): ?>active<?php endif; ?> marginLeft">
                    首页
                </div>
            </a>
            <a href="<?php echo url('/index/index/category'); ?>">
                <div class="navBottomText <?php if($hot==='category'): ?>active<?php endif; ?>">
                    产品分类
                </div>
            </a>
            <a href="caseShow.html">
                <div class="navBottomText">
                    案例展示
                </div>
            </a>
            <a href="brandStory.html">
                <div class="navBottomText">
                    品牌故事
                </div>
            </a>
            <a href="designTeam.html">
                <div class="navBottomText">
                    设计团队
                </div>
            </a>
        </div>
    </div>
</div>

<!--标题-->
<p class="goodsTitle container">
    <a href="index.html">首页></a><a href="productCategory.html">产品分类></a><span>商品详情</span>
</p>
<!--商品介绍-->
<div class="details container">
    <div class="detailsLeftImg">
        <div class="detailsImg">
            <img src="<?php echo $pics[0]; ?>" alt="">
            <div class="mask"></div>
        </div>
        <div class="box"></div>
        <div class="detailsLeftImgBottom">
            <?php if(is_array($pics) || $pics instanceof \think\Collection || $pics instanceof \think\Paginator): $i = 0; $__LIST__ = $pics;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$v): $mod = ($i % 2 );++$i;?>
            <div  class="detailsLeftImgItem">
                <img src="<?php echo $v; ?>" alt="" >
            </div>
            <?php endforeach; endif; else: echo "" ;endif; ?>
        </div>
        <div class="showImg">
            <img src="<?php echo $pics[0]; ?>" alt="">
        </div>
    </div>
    <script>
     var detailImg=document.querySelector(".detailsImg img");
     var detailsImgBox=document.querySelector(".box");
     var thumbs=document.querySelectorAll(".detailsLeftImgBottom img");
     var show=document.querySelector(".showImg img");
     var mask=document.querySelector(".mask");
     var showBox=document.querySelector(".showImg");
     thumbs.forEach(function(img){
         img.onclick=function(){
             detailImg.src=this.src;
             show.src=this.src;
         }
     });
     //mousemove
     detailsImgBox.onmouseenter=function(){
         mask.style.display="block";
         showBox.style.display="block";
     };
     detailsImgBox.onmouseleave=function(){
         mask.style.display="none";
         showBox.style.display="none";
     };
     detailsImgBox.onmousemove=function(e){
         var ox=e.offsetX;
         var oy=e.offsetY;
         var leftn=ox-200;
         var topn=oy-200;
         if(leftn<=0){
             leftn=0;
         }
         if(topn<=0){
             topn=0;
         }
         if(leftn>=368){
             leftn=368;
         }
         if(topn>=218){
             topn=218;
         }
         mask.style.left=leftn+"px";
         mask.style.top=topn+"px";
         show.style.marginLeft=-leftn*2+"px";
         show.style.marginTop=-topn*2+"px";
     };
    </script>
    <div class="detailsRight">
        <h2 class="detailsRightTitle"><?php echo $goods['name_en']; ?><br>
           <?php echo $goods['name_ch']; ?>
        </h2>
        <div class="detailsRightText">
            <div class="detailsRightLine"></div>
            <p class="detailsRightType">
                标签<span><?php echo $goods['tags']; ?></span>
            </p>
            <div class="detailsRightColorType">
                <span class="detailsRightColor">尺寸</span>
                <div class="detailsRightColorImg" data-checked="<?php echo $sizes[0]; ?>" ref="size">
                    <?php if(is_array($sizes) || $sizes instanceof \think\Collection || $sizes instanceof \think\Paginator): $k = 0; $__LIST__ = $sizes;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$v): $mod = ($k % 2 );++$k;?>
                    <label><?php echo $v; ?><input type="radio" name="size" value="<?php echo $v; ?>" v-model="size"></label>
                    <?php endforeach; endif; else: echo "" ;endif; ?>
                </div>
            </div>
            <p class="detailsRightType">
                描述<span><?php echo $goods['description']; ?></span>
            </p>
            <p class="detailsRightType">
                材料<span><?php echo $goods['material']; ?></span>
            </p>
            <p class="detailsRightType">
                场合<span><?php echo $goods['situation']; ?></span>
            </p>
            <div class="detailsRightLine1"></div>
        </div>
        <p class="detailsPrice"><?php echo $goods['price']; ?><span class="detailsPrice1">RMB</span></p>
        <div class="detailsOperation">
            <div class="detailsOperationAdd" @click="dec">-</div>
            <input type="text" v-model="n" class="detailsOperationInput">
            <div class="detailsOperationAdd" @click="add">+</div>
        </div>
        <div class="detailsBtn">
            <div class="detailsBtnBuy" @click="buy($event)" id="<?php echo $goods['id']; ?>" data-price="<?php echo $goods['price']; ?>">立即购买</div>
            <div class="detailsBtnCar">加入购物车</div>
        </div>

        <div class="detailsShare">
            <p class="detailsShareCollect"><i>&#xe644;</i>加入心愿单</p>
            <p class="detailsShareCollect"><i>&#xe7de;</i>分享</p>
            <p class="detailsShareCollect special"><i>&#xe61b;</i>收藏</p>
        </div>
    </div>
</div>
<script src="/static/js/vue.js"></script>
<script>
   new Vue({
       el:".detailsRight",
       data:{
           n:1,
           size:""
       },
       methods:{
           add:function(){
               this.n++;
           },
           dec:function(){
               if(this.n===1){
                   return;
               }
               this.n--;
           },
           buy:function(e){
               location.href="/index/index/shoppingcar?number="+this.n+"&size="+this.size+"&gid="+e.target.id+"&price="+e.target.getAttribute("data-price")*this.n;
           }
       },
       mounted:function(){
           this.size=this.$refs.size.getAttribute("data-checked");
       }
   })
</script>
<div class="commonHeader animated">
    <div class="commonLine"></div>
    <div class="commonLongLine"></div>
    <div class="commonEnglish">COMMODITY DETAILS</div>
    <div class="commonTitle"><span>商品</span><span>详情</span></div>
    <div class="commonBlackLine"></div>
</div>
<div class="container">
    <img src="<?php echo $goods['content_pc']; ?>" alt="">
</div>
<!--底部-->
<div class="footer active">
    <div class=" footerItem container ">
        <div class="footerCode">
            <div class="footerImg">
                <img src="/static/images/indexCode.png" alt="">
            </div>
            <p>扫码关注我们</p>
        </div>
        <div class="footerList">
            <h2>全部商品</h2>
            <div class="footerListItem">
                <a href=""> <p>沙发</p></a>
                <a href=""><p>床</p></a>
                <a href=""> <p>椅子</p></a>
            </div>
        </div>
        <div class="footerList">
            <h2>新品发布</h2>
            <div class="footerListItem">
                <a href=""><p>物流配送</p></a>
                <a href=""><p>免运费政策</p></a>
                <a href=""><p>物流配送服务</p></a>
                <a href=""><p>签收验货</p></a>
                <a href=""><p>物流查询</p></a>
            </div>
        </div>
        <div class="footerList">
            <h2>售后服务</h2>
            <div class="footerListItem">
                <a href=""><p>退换货政策</p></a>
                <a href=""> <p>贵就赔</p></a>
                <a href=""> <p>维修/安装</p></a>
                <a href=""> <p>订单修改</p></a>
                <a href="">  <p>退换货申请</p></a>
                <a href="">  <p>我的发票</p></a>
            </div>
        </div>
        <div class="footerList">
            <h2>关于我们</h2>
            <div class="footerListItem">
                <a href=""> <p>客服热线：400-320-0031</p></a>
                <a href=""> <p>客服邮箱：867321000@qq.com</p></a>
                <a href=""> <p>地址：山西省太原市小店区VICRO总部</p></a>
            </div>
        </div>
    </div>
    <div class="footerLine container">
        <div class="underline"></div>
        <div class="orange"></div>
    </div>
    <p>Copyright ©2018 www.guazi.com All Rights Reserved  |  京ICP备15053955号 ICP证151071号</p>
</div>
</body>
</html>
