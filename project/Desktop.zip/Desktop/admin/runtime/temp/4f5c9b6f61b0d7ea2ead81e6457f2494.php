<?php if (!defined('THINK_PATH')) exit(); /*a:3:{s:84:"C:\Users\UEK-N\Desktop\admin\public/../application/index\view\index\shoppingcar.html";i:1557478408;s:70:"C:\Users\UEK-N\Desktop\admin\application\index\view\common\header.html";i:1557475708;s:70:"C:\Users\UEK-N\Desktop\admin\application\index\view\common\footer.html";i:1557373286;}*/ ?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>购物车</title>
    <link rel="stylesheet" href="/static/css/base.css">
    <link rel="stylesheet" href="/static/css/shoppingCart.css">
</head>
<body>
<!--导航栏-->
<div class="nav active">
    <div class="container navHeader">
        <div class="navVicor">
            <img src="/static/images/indexLogo.png" alt="">
        </div>
        <div class="navTop">
            <div class="navSearch">
                <input type="text" placeholder="请输入您想要的商品">
                <a href="#"><i>&#xe603;</i></a>
            </div>
            <div class="navCar">
                <a href="#"><i>&#xe620;</i></a>
                <div class="navCarPoint"></div>
            </div>
            <?php if(\think\Session::get('login')): ?>
            <a href=""><div class="navLogin">个人中心</div></a>
            <?php else: ?>
            <a href=""><div class="navLogin">登录</div></a>
            <a href=""><div class="navRegister">注册</div></a>
            <?php endif; ?>
        </div>
        <div class="navBottom">
            <a href="<?php echo url('/'); ?>">
                <div class="navBottomText <?php if($hot==='index'): ?>active<?php endif; ?> marginLeft">
                    首页
                </div>
            </a>
            <a href="<?php echo url('/index/index/category'); ?>">
                <div class="navBottomText <?php if($hot==='category'): ?>active<?php endif; ?>">
                    产品分类
                </div>
            </a>
            <a href="caseShow.html">
                <div class="navBottomText">
                    案例展示
                </div>
            </a>
            <a href="brandStory.html">
                <div class="navBottomText">
                    品牌故事
                </div>
            </a>
            <a href="designTeam.html">
                <div class="navBottomText">
                    设计团队
                </div>
            </a>
        </div>
    </div>
</div>

<!--购物车导航-->
<div class="cartNav">
    <div class="navBox">全选</div>
    <div class="navBox2">商品描述</div>
    <div class="navBox3">单价</div>
    <div class="navBox4">数量</div>
    <div class="navBox5">总价</div>
    <div class="navBox6">操作</div>
</div>
<!--购物车内容-->
<div class="cartContent">
    <?php if(is_array($order) || $order instanceof \think\Collection || $order instanceof \think\Paginator): $i = 0; $__LIST__ = $order;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$v): $mod = ($i % 2 );++$i;?>
    <div class="list">
        <div class="leftList">
            <img src="<?php echo $v['thumb']; ?>" alt="" class="cartImg">
            <div class="cartDot"></div>
        </div>
        <div class="rightList">
            <div class="description">
                <p class="engName"><?php echo $v['name_en']; ?></p>
                <p class="name"><?php echo $v['name_ch']; ?></p>
                <p class="good"><?php echo $v['size']; ?></p>
            </div>
            <div class="price"><?php echo $v['goods_price']; ?><span class="rmb">RMB</span></div>
            <div class="number">
                <div class="minus"><i>&#xe61f;</i></div>
                <div class="plus"><i>&#xe601;</i></div>
            </div>
            <div class="price"><?php echo $v['price']; ?><span class="rmb">RMB</span></div>
            <div class="operator">
                <div class="delete"><i>&#xe634;</i></div>
                <div class="like"><i>&#xe618;</i></div>
            </div>
        </div>
    </div>
    <?php endforeach; endif; else: echo "" ;endif; ?>
    <div class="accounts">
        <div class="checked">
            <div class="cartDot1"></div>
            <p class="checkWord">全选</p>
            <div class="checkDel"><i>&#xe634;</i>
                <p class="delWord">批量删除</p>
            </div>
            <div class="checkDel"><i>&#xe634;</i>
                <p class="delWord">清空失效</p>
            </div>
        </div>
        <div class="total">共计<span class="num">2</span>件商品</div>
        <div class="goAccount">去结算</div>
        <div class="heJi">合计 1040 <!--<span class="">RMB</span>--> </div>
    </div>
</div>
<!--页码-->
<div class="page">
    <div class="leftArrow"><i>&#xe660;</i></div>
    <div class="pageNumber">1</div>
    <div class="pageNumber">2</div>
    <div class="pageNumber active1">3</div>
    <div class="pageNumber">4</div>
    <div class="pageNumber">5</div>
    <div class="ellipsis">......</div>
    <div class="pageNumber">18</div>
    <div class="pageNumber">19</div>
    <div class="rightArrow"><i>&#xe604;</i></div>
    <p class="pageWord">跳转到</p>
    <span class="kong"></span>
    <p class="pageWord">页</p>
    <span class="go">go</span>
</div>
<!--为你推荐-->
<div class="recommend">
    <div class="commonHeader animated">
        <div class="commonLine"></div>
        <div class="commonLongLine"></div>
        <div class="commonEnglish">commend</div>
        <div class="commonTitle"><span>为你</span><span>推荐</span></div>
        <div class="commonBlackLine"></div>
    </div>
    <div id="newWrapper" class="container">
        <div class="newGoodBox active">
            <div ><img src="/static/images/indexNew.png" alt="" class="newImg"></div>
            <div class="newLine"></div>
            <div class="newWord">
                <p>VERFO LAB </p>
                <p>现代简约时尚布艺沙发</p>
            </div>
            <div class="newPrice">800<span>RMB</span></div>
            <a href="">
                <div class="newBuy"><i>&#xe60f;</i>点击购买</div>
            </a>
        </div>
        <div class="newGoodBox ">
            <img src="/static/images/indexNew2.png" alt="" class="newImg">
            <div class="newLine"></div>
            <div class="newWord">
                <p>VERFO LAB </p>
                <p>现代简约时尚布艺沙发</p>
            </div>
            <div class="newPrice">800<span>RMB</span></div>
            <a href="">
                <div class="newBuy"><i>&#xe60f;</i>点击购买</div>
            </a>

        </div>
        <div class="newGoodBox ">
            <img src="/static/images/indexNew5.png" alt="" class="newImg">
            <div class="newLine"></div>
            <div class="newWord">
                <p>VERFO LAB </p>
                <p>现代简约时尚布艺沙发</p>
            </div>
            <div class="newPrice">800<span>RMB</span></div>
            <a href="">
                <div class="newBuy"><i>&#xe60f;</i>点击购买</div>
            </a>

        </div>
        <div class="newGoodBox ">
            <img src="/static/images/indexNew6.png" alt="" class="newImg">
            <div class="newLine"></div>
            <div class="newWord">
                <p>VERFO LAB </p>
                <p>现代简约时尚布艺沙发</p>
            </div>
            <div class="newPrice">800<span>RMB</span></div>
            <a href="">
                <div class="newBuy"><i>&#xe60f;</i>点击购买</div>
            </a>

        </div>
    </div>
</div>
<!--底部-->
<div class="footer active">
    <div class=" footerItem container ">
        <div class="footerCode">
            <div class="footerImg">
                <img src="/static/images/indexCode.png" alt="">
            </div>
            <p>扫码关注我们</p>
        </div>
        <div class="footerList">
            <h2>全部商品</h2>
            <div class="footerListItem">
                <a href=""> <p>沙发</p></a>
                <a href=""><p>床</p></a>
                <a href=""> <p>椅子</p></a>
            </div>
        </div>
        <div class="footerList">
            <h2>新品发布</h2>
            <div class="footerListItem">
                <a href=""><p>物流配送</p></a>
                <a href=""><p>免运费政策</p></a>
                <a href=""><p>物流配送服务</p></a>
                <a href=""><p>签收验货</p></a>
                <a href=""><p>物流查询</p></a>
            </div>
        </div>
        <div class="footerList">
            <h2>售后服务</h2>
            <div class="footerListItem">
                <a href=""><p>退换货政策</p></a>
                <a href=""> <p>贵就赔</p></a>
                <a href=""> <p>维修/安装</p></a>
                <a href=""> <p>订单修改</p></a>
                <a href="">  <p>退换货申请</p></a>
                <a href="">  <p>我的发票</p></a>
            </div>
        </div>
        <div class="footerList">
            <h2>关于我们</h2>
            <div class="footerListItem">
                <a href=""> <p>客服热线：400-320-0031</p></a>
                <a href=""> <p>客服邮箱：867321000@qq.com</p></a>
                <a href=""> <p>地址：山西省太原市小店区VICRO总部</p></a>
            </div>
        </div>
    </div>
    <div class="footerLine container">
        <div class="underline"></div>
        <div class="orange"></div>
    </div>
    <p>Copyright ©2018 www.guazi.com All Rights Reserved  |  京ICP备15053955号 ICP证151071号</p>
</div>
</body>
</html>