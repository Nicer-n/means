<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:78:"C:\Users\UEK-N\Desktop\admin\public/../application/index\view\index\login.html";i:1557474872;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
    <link rel="stylesheet" href="/static/css/index.css">
    <link rel="stylesheet" href="/static/css/animate.css">
    <link rel="stylesheet" href="/static/css/base.css">
    <link rel="stylesheet" href="/static/css/register.css">
</head>
<body>
<div id="mask">
    <div class="login">
        <div class="loginImg">
            <img src="/static/images/indexBanner00.png" alt="">
        </div>
        <div class="loginInput">
            <form action="<?php echo url('/index/index/checklogin'); ?>" id="myform" method="post">
                <ul>
                    <li>
                        <div class="loginName">
                            <i class="iconfont"></i>
                            <p class="userName">用户名/<span class="userName active">USER</span><span
                                    class="userName active1">NAME</span></p>
                            <input type="text" placeholder="请输入您的账号 " class="userInput" name="username">
                        </div>
                    </li>
                    <li>
                        <div class="loginName">
                            <i class="iconfont"></i>
                            <p class="userName">密码/<span class="userName active">PASS</span><span
                                    class="userName active1">WORD</span></p>
                            <input type="password" placeholder="密码数不能少于6位 " class="userInput" name="password">
                        </div>
                    </li>
                </ul>
                <input class="loginBtn" type="submit" value="登录"></input>
            </form>
        </div>
    </div>
</div>
<style>
    label.error {
       color:red;
    }
</style>
<script src="/static/js/jQuery.js"></script>
<script src="/static/js/jquery.validate.min.js"></script>
<script>
    $("#myform").validate({
        rules: {
            username: {
                required: true
            },
            password: {
                required: true
            }
        },
        messages: {
            username: {
                required: "请输入用户名"
            },
            password: {
                required: "请输入密码"
            }
        }
    })
</script>
</body>
</html>