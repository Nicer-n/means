<?php if (!defined('THINK_PATH')) exit(); /*a:3:{s:78:"C:\Users\UEK-N\Desktop\admin\public/../application/index\view\index\index.html";i:1557467704;s:70:"C:\Users\UEK-N\Desktop\admin\application\index\view\common\header.html";i:1557475708;s:70:"C:\Users\UEK-N\Desktop\admin\application\index\view\common\footer.html";i:1557373286;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
    <link rel="stylesheet" href="/static/css/index.css">
    <link rel="stylesheet" href="/static/css/animate.css">
    <link rel="stylesheet" href="/static/css/base.css">
</head>
<body>
<!--导航栏-->
<div class="nav active">
    <div class="container navHeader">
        <div class="navVicor">
            <img src="/static/images/indexLogo.png" alt="">
        </div>
        <div class="navTop">
            <div class="navSearch">
                <input type="text" placeholder="请输入您想要的商品">
                <a href="#"><i>&#xe603;</i></a>
            </div>
            <div class="navCar">
                <a href="#"><i>&#xe620;</i></a>
                <div class="navCarPoint"></div>
            </div>
            <?php if(\think\Session::get('login')): ?>
            <a href=""><div class="navLogin">个人中心</div></a>
            <?php else: ?>
            <a href=""><div class="navLogin">登录</div></a>
            <a href=""><div class="navRegister">注册</div></a>
            <?php endif; ?>
        </div>
        <div class="navBottom">
            <a href="<?php echo url('/'); ?>">
                <div class="navBottomText <?php if($hot==='index'): ?>active<?php endif; ?> marginLeft">
                    首页
                </div>
            </a>
            <a href="<?php echo url('/index/index/category'); ?>">
                <div class="navBottomText <?php if($hot==='category'): ?>active<?php endif; ?>">
                    产品分类
                </div>
            </a>
            <a href="caseShow.html">
                <div class="navBottomText">
                    案例展示
                </div>
            </a>
            <a href="brandStory.html">
                <div class="navBottomText">
                    品牌故事
                </div>
            </a>
            <a href="designTeam.html">
                <div class="navBottomText">
                    设计团队
                </div>
            </a>
        </div>
    </div>
</div>

<!--轮播图-->
<div class="header">
    <ul class="headerImg">
        <li class="active"><a href=""><img src="/static/images/indexBanner1.png" alt="" ></a></li>
        <li ><a href=""><img src="/static/images/indexBanner2.png" alt=""></a></li>
        <li><a href=""><img src="/static/images/indexBanner3.png" alt=""></a></li>
        <li><a href=""><img src="/static/images/indexBanner4.png" alt=""></a></li>
    </ul>
    <div class="headerShade">
    </div>
    <div class="headerWord">
        <p class="headerWordText">IN LIVINGROOM</p>
        <p class="headerWordText2">SALE OFF TO 50%</p>
        <div class="headerWordText3">
            LAMP LIGHTING FURNITURE
        </div>
        <a href="">
            <h2>查看更多</h2>
        </a>
    </div>
    <ul class="headerSpots">
        <li class="headerSpot active"></li>
        <li class="headerSpot"></li>
        <li class="headerSpot"></li>
        <li class="headerSpot"></li>
    </ul>
    <div class="headerLeft"><i>&#xe614;</i></div>
    <div class="headerRight"><i>&#xe6ab;</i></div>
</div>
<!--新品首发-->
<div class="new">
    <div class="commonHeader animated">
        <div class="commonLine"></div>
        <div class="commonLongLine"></div>
        <div class="commonEnglish">NEW product</div>
        <div class="commonTitle"><span>新品</span><span>首发</span></div>
        <div class="commonBlackLine"></div>
    </div>
    <div id="newWrapper" class="container">
        <div class="newItem">
            <div class="newInner">
                <?php if(is_array($newgoods) || $newgoods instanceof \think\Collection || $newgoods instanceof \think\Paginator): $i = 0; $__LIST__ = $newgoods;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$v): $mod = ($i % 2 );++$i;?>
                 <div class="newGoodBox">
                    <div class="newImg"><img src="<?php echo $v['thumb']; ?>" alt=""></div>
                    <div class="newLine"></div>
                    <div class="newWord">
                        <p><?php echo $v['name_en']; ?></p>
                        <p><?php echo $v['name_ch']; ?></p>
                    </div>
                    <div class="newPrice"><?php echo $v['price']; ?><span>RMB</span></div>
                    <a href="">
                        <div class="newBuy"><i>&#xe60f;</i>点击购买</div>
                    </a>
                    <div class="newHot"><img src="/static/images/indexHot.png" alt=""></div>
                </div>
                <?php endforeach; endif; else: echo "" ;endif; ?>
            </div>
        </div>
        <div class="newButton">
            <span><i>&#xe610;</i></span>
            <span class="active"><i>&#xe612;</i></span>
        </div>
    </div>
</div>
<!--热销产品-->
<div class="product">
    <div class="commonHeader animated">
        <div class="commonLine"></div>
        <div class="commonLongLine"></div>
        <div class="commonEnglish">HOT PRODUCT</div>
        <div class="commonTitle"><span>热销</span><span>产品</span></div>
        <div class="commonBlackLine"></div>
    </div>
    <div class="productImg">
        <img src="/static/images/indexHot1.png" alt="" >
        <div class="productShadow">
            <div id="productItem" class="container">
                <div class="productLeft">
                    <div class="productLeftImg">
                        <img src="/static/images/indexSoft.png" alt="">
                    </div>
                    <h2>舒适棉麻 布艺沙发</h2>
                    <p>告别繁琐多余的浮夸 保留实用主义的本质</p>
                    <div class="productLeftSpot">
                        <div></div>
                        <div class="active"></div>
                        <div></div>
                    </div>
                    <div class="productMoney">
                        <h2>4450</h2>
                        <span>RMB</span>
                    </div>
                    <div class="productBuy">BUY NOW</div>
                    <div class="productSign">
                        <img src="/static/images/indexSign.png" alt="">
                    </div>
                </div>
                <div class="productRight">
                    <div class="productRightImg active1">
                        <div class="productRightItem">
                            <p>FENDI CASA TUDOR </p>
                            <h2>现代简约客厅沙发</h2>
                        </div>
                        <div class="productSoft"><img src="/static/images/indexProduct1.png" alt=""></div>
                        <div class="productRightSpot">
                            <div></div>
                            <div class="active"></div>
                            <div></div>
                        </div>
                        <div class="moneyFive">
                            <h2>520</h2><span>RMB</span>
                        </div>
                    </div>
                    <div class="productRightImg active1 active">
                        <div class="productRightItem">
                            <p>FENDI CASA TUDOR </p>
                            <h2>现代简约客厅沙发</h2>
                        </div>
                        <div class="productSoft"><img src="/static/images/indexProduct2.png" alt=""></div>
                        <div class="productRightSpot">
                            <p></p>
                            <p class="active"></p>
                            <p></p>
                        </div>
                        <div class="moneyFive">
                            <h2>520</h2><span>RMB</span>
                        </div>
                    </div>
                    <div class="productRightImg active1">
                        <div class="productRightItem">
                            <p>FENDI CASA TUDOR </p>
                            <h2>现代简约客厅沙发</h2>
                        </div>
                        <div class="productSoft"><img src="/static/images/indexProduct3.png" alt=""></div>
                        <div class="productRightSpot">
                            <div class="spot"></div>
                            <div class=" spot active"></div>
                            <div class="spot"></div>
                        </div>
                        <div class="moneyFive">
                            <h2>520</h2><span>RMB</span>
                        </div>
                    </div>
                    <div class="productRightImg active1 active">
                        <div class="productRightItem">
                            <p>FENDI CASA TUDOR </p>
                            <h2>现代简约客厅沙发</h2>
                        </div>
                        <div class="productSoft"><img src="/static/images/indexProduct4.png" alt=""></div>
                        <div class="productRightSpot">
                            <div class="rightSpot"></div>
                            <div class=" rightSpot active"></div>
                            <div class="rightSpot"></div>
                        </div>
                        <div class="moneyFive">
                            <h2>520</h2><span>RMB</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!--案例展示-->
<div class="example">
    <div class="commonHeader animated">
        <div class="commonLine"></div>
        <div class="commonLongLine"></div>
        <div class="commonEnglish">BRAND STORY</div>
        <div class="commonTitle"><span>案例</span><span>展示</span></div>
        <div class="commonBlackLine"></div>
    </div>
    <div id="exampleShow" class="container">
        <a href="">
            <div class="exampleShowImg">
                <img src="/static/images/indexBanner3.png" alt="">
                <div class="exampleShowShade">
                    <img src="/static/images/indexShade.png" alt="">
                    <div class="examplePhoto"></div>
                    <div class="examplePhotoShade">
                        <i>&#xe651;</i>
                    </div>
                </div>
            </div>
        </a>
        <a href="">
            <div class="exampleShowImg active">
                <div class="exampleTitle">
                    <p>About the </p>
                    <p>chair designer. </p>
                </div>
                <div class="exampleContent active">
                    <p>透气性与柔和感并存，像三月的威风，也像五月的 </p>
                    <p>阳光，像恋人的热吻，也像傍晚归时的路灯。</p>
                    <p>棉麻的柔软触感，让不大的客厅更加具有安全感。陷阱沙发的温柔里，追剧 </p>
                    <p>的日子变得幸福异常。</p>
                </div>
                <div class="exampleMore">了解更多</div>
            </div>
        </a>
        <a href="">
            <div class="exampleShowImg title">
                <div class="exampleTitle">
                    <p>About the </p>
                    <p>chair designer. </p>
                </div>
                <div class="exampleContent ">
                    <p>透气性与柔和感并存，像三月的威风，也像五月的 </p>
                    <p>阳光，像恋人的热吻，也像傍晚归时的路灯。</p>
                    <p>棉麻的柔软触感，让不大的客厅更加具有安全感。陷阱沙发的温柔里，追剧 </p>
                    <p>的日子变得幸福异常。</p>
                </div>
                <div class="exampleMore">了解更多</div>
            </div>
        </a>
        <a href="">
            <div class="exampleShowImg active">
                <img src="/static/images/indexBanner2.png" alt="">
                <div class="exampleShowShade">
                    <img src="/static/images/indexShade.png" alt="">
                    <div class="examplePhoto"></div>
                    <div class="examplePhotoShade">
                        <i>&#xe651;</i>
                    </div>
                </div>

            </div>
        </a>
    </div>
</div>
<!--品牌故事-->
<div class="story">
    <div class="commonHeader animated">
        <div class="commonLine"></div>
        <div class="commonLongLine"></div>
        <div class="commonEnglish">COMMODITY DETAILS</div>
        <div class="commonTitle"><span>品牌</span><span>故事</span></div>
        <div class="commonBlackLine"></div>
    </div>
    <div class="storyBanner">
        <img src="/static/images/indexBanner4.png" alt="">
        <div class="storyShade">
            <div id="storyShadeItem" class="container">
                <div class="storyImg"><img src="/static/images/indexStory.png" alt=""></div>
                <div class="storyLine"></div>
                <div class="storyTitle"> 因为顾家，所以爱家</div>
                <div class="storyContent">
                    <p>34年沙发制造工艺，保证每一张沙发都拥有出色品质，真材实料， </p>
                    <p>现代设计，让你的家更迷人温馨。 </p>
                </div>
                <div class="storyDown">
                    <img src="/static/images/indexDown2.png" alt="">
                    <img src="/static/images/indexDown1.png" alt="">
                    <img src="/static/images/indexDown.png" alt="">
                </div>
            </div>
        </div>
    </div>

</div>
<!--底部-->
<div class="footer active">
    <div class=" footerItem container ">
        <div class="footerCode">
            <div class="footerImg">
                <img src="/static/images/indexCode.png" alt="">
            </div>
            <p>扫码关注我们</p>
        </div>
        <div class="footerList">
            <h2>全部商品</h2>
            <div class="footerListItem">
                <a href=""> <p>沙发</p></a>
                <a href=""><p>床</p></a>
                <a href=""> <p>椅子</p></a>
            </div>
        </div>
        <div class="footerList">
            <h2>新品发布</h2>
            <div class="footerListItem">
                <a href=""><p>物流配送</p></a>
                <a href=""><p>免运费政策</p></a>
                <a href=""><p>物流配送服务</p></a>
                <a href=""><p>签收验货</p></a>
                <a href=""><p>物流查询</p></a>
            </div>
        </div>
        <div class="footerList">
            <h2>售后服务</h2>
            <div class="footerListItem">
                <a href=""><p>退换货政策</p></a>
                <a href=""> <p>贵就赔</p></a>
                <a href=""> <p>维修/安装</p></a>
                <a href=""> <p>订单修改</p></a>
                <a href="">  <p>退换货申请</p></a>
                <a href="">  <p>我的发票</p></a>
            </div>
        </div>
        <div class="footerList">
            <h2>关于我们</h2>
            <div class="footerListItem">
                <a href=""> <p>客服热线：400-320-0031</p></a>
                <a href=""> <p>客服邮箱：867321000@qq.com</p></a>
                <a href=""> <p>地址：山西省太原市小店区VICRO总部</p></a>
            </div>
        </div>
    </div>
    <div class="footerLine container">
        <div class="underline"></div>
        <div class="orange"></div>
    </div>
    <p>Copyright ©2018 www.guazi.com All Rights Reserved  |  京ICP备15053955号 ICP证151071号</p>
</div>
<!--返回顶部-->
<div class="itemBar itemHover top">
    <i class="iconfont">&#xe609;</i>
</div>
<script src="/static/js/jQuery.js"></script>
<script src="/static/js/index.js"></script>
</body>
</html>