<template>
    <div>
        <my-header></my-header>
        <div id="nav">
            <div class="toLeft"><img src="../../assets/image/hly/15-left.png" alt=""></div>
            <div class="information">个人信息</div>
        </div>
        <div class="image">
            <img src="../../assets/image/yxx/14-1.png" alt="">
        </div>
        <div id="banner">
            <div class="headPor">
                <a href="#"><img src="../../assets/image/yxx/14-2.png" alt=""></a>
                <div class="headRight">
                    <a href="#">
                        <p>修改头像</p>
                        <i class="iconfont icon-arrow-right"></i>
                    </a>
                </div>
            </div>
            <div class="bannerName">
                <div class="bannerLeft">昵称</div>
                <a href="">
                    <div class="bannerText">我家有只小狗</div>
                </a>
                <a href=""><i class="iconfont icon-arrow-right"></i></a>
            </div>
            <div class="bannerName">
                <div class="bannerLeft">性别</div>
                <a href="">
                    <div class="bannerText">未设置</div>
                </a>
                <a href=""><i class="iconfont icon-arrow-right"></i></a>
            </div>
            <div class="bannerName">
                <div class="bannerLeft">我的手机号</div>
                <a href="">
                    <div class="bannerText">135****594</div>
                </a>
                <a href=""><i class="iconfont icon-arrow-right"></i></a>
            </div>
            <div class="bannerName">
                <div class="bannerLeft">出生年月</div>
                <a href="">
                    <div class="bannerText">未设置</div>
                </a>
                <a href=""><i class="iconfont icon-arrow-right"></i></a>
            </div>
        </div>
    </div>
</template>

<script>
    import Header from "@/components/Header";
    export default {
        name: "Profile",
        data: () => ({}),
        components: {
            "my-header": Header,
        }
    }
</script>

<style lang="scss" scoped>
    #nav{
        width: 100%;
        height: 0.78rem;
        background: white;
    }
    .arrowLeft{
        float: left;
        width: 0.3rem;
        height: 0.78rem;
        margin-left: 0.25rem;
    }
    .icon-arrow-left{
        width: 0.3rem;
        height: 0.78rem;
        font-size: 0.16rem;
        line-height: 0.78rem;
    }
    .information{
        float: left;
        width: 1.15rem;
        height: 0.78rem;
        font-size: 0.28rem;
        scroll-padding: 0.01rem;
        text-align: center;
        line-height: 0.78rem;
        margin-left: 2.61rem;
    }
    /*nav*/
    .image{
        width: 100%;
        height: 1.68rem;
    }
    .image img{
        display: block;
        width: 100%;
        height: 1.68rem;
    }
    /*image*/
    #banner{
        width: 7.02rem;
        height: 10.31rem;
        border-radius: 0.1rem 0.1rem 0.1rem 0.1rem;
        background: white;
        box-shadow: 0 0.01rem 0.21rem 0 rgba(118,118,118,0.17);
        position: absolute;
        top: 2.16rem;
        left: 50%;
        margin-left: -3.51rem;
        z-index: 66;
    }
    .headPor{
        width: 6.02rem;
        height: 1.64rem;
        border-bottom: 0.02rem solid rgb(242,242,242);
        margin:0 0.5rem;
        padding-top: 0.39rem;
    }
    .headPor a{
        width: 0.92rem;
        height: 0.92rem;
    }
    .headPor a img{
        width: 0.92rem;
        height: 0.92rem;
        display: block;
        float: left;
    }
    .headRight{
        width: 1.4rem;
        height: 100%;
        float: right;
    }
    .headRight a{
        width: 100%;
        height: 100%;
    }
    .headRight a p{
        /*width:1rem;*/
        height: 0.92rem;
        line-height: 0.92rem;
        font-size: 0.24rem;
        color: rgb(153,153,153);
        scroll-padding: 0.01rem;
        float: left;
        text-align: right;
    }
    .headRight a i{
        float: right;
        color: rgba(0,0,0,0.7);
    }
    .icon-arrow-right{
        line-height: 0.92rem;
        font-size: 0.14rem;
        color: rgba(0,0,0,0.7);
    }
    .bannerName{
        width: 6.02rem;
        height: 0.89rem;
        margin: 0 0.5rem;
        border-bottom: 0.02rem solid rgb(242,242,242);
    }
    .bannerLeft{
        width: 1.6rem;
        height: 100%;
        line-height: 0.89rem;
        font-size: 0.26rem;
        letter-spacing: 0.02rem;
        float: left;
    }
    .bannerText{
        width: 2rem;
        height: 0.89rem;
        line-height: 0.89rem;
        font-size: 0.24rem;
        letter-spacing: 0.01rem;
        color: rgb(153,153,153);
        float: left;
        margin-left: 2rem;
        text-align: right;
    }
    .bannerName .icon-arrow-right{
        width: 0.28rem;
        height: 0.89rem;
        line-height: 0.89rem;
        float: right;
        color: rgba(0,0,0,0.7);
    }
    .toLeft img{
        width: 0.2rem;
        height: 0.3rem;
        margin-left: 0.3rem;
        margin-top: 0.2rem;
        float: left;
    }


</style>