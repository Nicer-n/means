<template>
    <div>
        <my-header>
            <img src="../../assets/image/cys/10.1.png" alt="" class="back" @click="$router.back()">
        </my-header>
        <div class="full">
            <div class="return-key">
                <i class="iconfont icon-2fanhui"></i>
            </div>
            <img src="../../assets/image/ycj/bj.jpg" alt="">
        </div>
        <div class="white">
            <div class="login-text">
                <router-link to="/login"><p class="text-left">登录</p></router-link>
                <a href=""><p class="text-right active">注册</p></a>
            </div>
            <div class="username">手机</div>
            <form action="">
                <input type="text" name="t" placeholder="请输入手机号" class="tel" v-model="phone">
            </form>
            <div class="code">验证码</div>
            <form action="">
                <input type="text" name="t" placeholder="请输入验证码" class="identify" v-model="code" @blur="checkCode">
            </form>
            <div class="password-text">密码</div>
            <form action="">
                <input type="password" name="t" placeholder="密码由6位以上的数字或者字母组成" class="password-input" v-model="password">
            </form>
        </div>
        <div :class="['red-code',{active:isActive}]">
            <div class="point"></div>
            <a class="red-code-text" @click="sendPhone">{{msg}}</a>
            <div class="point right"></div>
        </div>
        <!--最下开始-->

       <div class="bottom" @click="submit">注册</div>
    </div>
</template>

<script>
    import Header from "@/components/Header";
    export default {
        name: "Sign",
        data: () => ({
            phone: "",
            code:"",
            password:"",
            isActive: false,
            msg: "获取验证码",
            checkState:false
        }),
        methods: {
            sendPhone: function () {
                if (this.isActive) {
                    return;
                }
                let reg = /^1[356789]\d{9}$/;
                if (reg.test(this.phone)) {
                    this.isActive = true;
                    this.msg = "60s";
                    let n = 60;
                    let t = setInterval(() => {
                        n--;
                        this.msg = n + "s";
                        if (n === 0) {
                            clearInterval(t);
                            this.msg = "重新发送";
                            this.isActive = false;
                        }
                    }, 1000);
                    this.$http.post("/api/users/sendMessage", {phone: this.phone}).then(res => {
                        if (res.data.code === 200) {
                            console.log("提交成功");
                        } else {
                            console.log("提交失败");
                        }
                    }).catch(() => {
                        console.log("提交失败")
                    })
                } else {
                    alert("请输入合法的手机号");
                }
            },
            checkCode:function(){
               if(this.code!==""){
                  this.$http.post("/api/users/checkCode",{code:this.code}).then(res=>{
                     if(res.data.code===200){
                          alert("验证成功");
                         this.checkState=true;
                     }else{
                         alert("验证失败");
                     }
                  }).catch(()=>{
                      console.log("验证码提交失败")
                  })
               }
            },
            submit:function(){
                let reg1 = /^1[356789]\d{9}$/;
                let reg2 = /^\d{4}$/;
                let reg3 = /^[0-9a-z]{6,}$/;
                if(!reg1.test(this.phone)){
                     alert("手机号码错误");
                     return;
                }
                if(!reg2.test(this.code)){
                     alert("请输入验证码");
                     return;
                }
                if(!this.checkState){
                    alert("请输入正确的验证码");
                    return;
                }
                if(!reg3.test(this.password)){
                    alert("密码必须由6位以上的字母或数字组成");
                    return;
                }
                this.$http.post("/api/users/sign",{phone:this.phone,password:this.password}).then(res=>{
                    if(res.data.code===200){
                        alert("注册成功");
                        this.$router.push({name:"login"})
                    }else if(res.data.code===400){
                        alert("该手机号已被注册");
                    }else{
                        console.log("注册失败");
                    }
                }).catch(()=>{
                    console.log("注册失败");
                })
            }
        },
        components: {
            "my-header": Header
        }
    }
</script>

<style lang="scss" scoped>
    @import "../../assets/iconfont1.css";

    * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
    }

    ul {
        list-style: none;
    }

    a {
        text-decoration: none;
    }

    html {
        font-size: 100px;
    }

    i {
        font-style: normal;
    }

    img {
        display: block;
    }

    @media (min-width: 320px) {
        html {
            font-size: 42.6667px;
        }
    }

    @media (min-width: 360px) {
        html {
            font-size: 48px;
        }
    }

    @media (min-width: 375px) {
        html {
            font-size: 50px;
        }
    }

    @media (min-width: 414px) {
        html {
            font-size: 55.2px;
        }
    }

    body {
        font-size: 12px;
    }

    .full {
        width: 100%;
        height: 100%;
        position: relative;
    }

    .full img {
        width: 100%;
        height: auto;
    }

    .return-key {
        width: 0.21rem;
        height: 0.35rem;
        /*background: #fea8a8;*/
        text-align: left;
        line-height: 0.35rem;
        position: absolute;
        top: 0.67rem;
        left: 0.52rem;
    }

    .return-key i {
        width: 100%;
        height: 100%;
        color: #101214;
        font-size: 0.28rem;
        text-align: center;
        line-height: 0.35rem;
    }

    .white {
        width: 6.68rem;
        height: 6.6rem;
        background: white;
        box-shadow: 0.05rem 0.05rem 0.2rem #c1c1c1;
        margin: 0 auto;
        position: absolute;
        top: 2.78rem;
        left: 50%;
        margin-left: -3.34rem;
        padding: 0.63rem 0.58rem;
    }

    .white .login-text {
        width: 100%;
        height: 0.32rem;
        margin-bottom: 0.51rem;
    }

    .white .login-text .text-left {
        width: 0.7rem;
        height: 100%;
        float: left;
        margin-left: 0.24rem;
        font-size: 0.34rem;
        text-align: left;
        line-height: 0.32rem;
        color: #343434;
        letter-spacing: 0.01rem;
    }

    .white .login-text .text-right {
        width: 0.7rem;
        height: 100%;
        float: right;
        margin-right: 0.24rem;
        font-size: 0.34rem;
        text-align: left;
        line-height: 0.32rem;
        color: #343434;
        letter-spacing: 0.01rem;
    }

    .white .login-text .active {
        color: #F7884B;
    }

    .username, .code, .password-text {
        width: 100%;
        height: 0.25rem;
        font-size: 0.26rem;
        text-align: left;
        line-height: 0.25rem;
        color: #737373;
        letter-spacing: 0.01rem;
        margin-bottom: 0.36rem;
    }

    form .tel, form .password-input {
        width: 100%;
        height: 0.6rem;
        border: none;
        border-bottom: 3px solid #cccccc;
        font-size: 0.26rem;
        color: #737373;
        margin-bottom: 0.48rem;
    }

    form .identify {
        width: 2.72rem;
        height: 0.6rem;
        border: none;
        border-bottom: 3px solid #cccccc;
        font-size: 0.26rem;
        color: #737373;
        margin-bottom: 0.36rem;
    }

    .red-code {
        width: 1.76rem;
        height: 0.37rem;
        background: #f93e3e;
        box-shadow: 0 0.05rem 0.2rem #ff6767;
        border: 1px solid #f93e3e;
        border-radius: 0.3rem;
        position: absolute;
        top: 6.65rem;
        left: 50%;
        margin-left: 1.1rem;
    }

    .red-code.active {
        background: #ccc;
        box-shadow: 0 0.05rem 0.2rem #333;
        border: 1px solid #ccc;
    }

    .red-code .point {
        width: 0.1rem;
        height: 0.1rem;
        background: white;
        border-radius: 0.5rem;
        margin-left: 0.1rem;
        margin-top: 0.12rem;
        float: left;
    }

    .red-code .red-code-text {
        width: 1.2rem;
        height: 100%;
        /*background: #d4fdfd;*/
        text-align: center;
        line-height: 0.35rem;
        color: white;
        float: left;
        margin-left: 0.09rem;
        display: block;
    }

    .red-code .right {
        margin-left: 0.03rem;
        float: right;
        margin-right: 0.05rem;
    }

    /*最下开始*/
    .bottom {
        width: 6.68rem;
        height: 0.79rem;
        background: #ffffff;
        position: absolute;
        top: 9.64rem;
        left: 50%;
        margin-left: -3.34rem;
        box-shadow: 0.05rem 0.05rem 0.2rem #c1c1c1;
        text-align: center;
        line-height: 0.79rem;
        letter-spacing: 0.02rem;
        color: #8e8e8e;
        font-size: 0.32rem;
    }
</style>