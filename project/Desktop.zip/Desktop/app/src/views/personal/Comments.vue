<template>
    <div>
        <div id="banners">
            <div class="detailed">商品详情</div>
            <div class="detailed" id="active">商品评论
                <div class="line"></div>
            </div>
        </div>
        <div id="content">
            <div class="conFirst">
                <div class="firstLeft">
                    <img src="../../assets/image/yxx/6-2-1.png" alt="">
                </div>
                <div class="firstRight">
                    <div class="rightTitle">
                        <p>我家有只猫</p>
                        <div class="star"> <img src="../../assets/image/yxx/6-2-4.png" alt=""></div>
                    </div>
                    <div class="word">发货速度很快，卖家服务态度相当不错！</div>
                    <div class="rightImg">
                        <img src="../../assets/image/yxx/6-2-6.png" alt="">
                        <img src="../../assets/image/yxx/6-2-7.png" alt="">
                    </div>
                    <div class="date">
                        <div class="circle"></div>
                        <div class="color">紫色</div>
                        <div class="dateCon">2019-03-20 15:09:02发布</div>
                    </div>
                </div>
                <div class="conLine"></div>
            </div>
            <div class="conSecond">
                <div class="firstLeft">
                    <img src="../../assets/image/yxx/6-2-3.png" alt="">
                </div>
                <div class="secondRight">
                    <div class="secondTitle">
                        <p>我家有只小猫</p>
                        <div class="star"> <img src="../../assets/image/yxx/6-2-5.png" alt=""></div>
                    </div>
                    <div class="secondWord">网购很久，但是家具网购还是第一次买，和实
                        体店一样，物美价廉，省心购物。</div>
                    <div class="add">
                        <h3>追加：</h3>
                        <p>坐的很舒服，推荐给闺蜜了。</p>
                    </div>
                    <div class="secondCon">
                        <div class="circleSec"></div>
                        <div class="colorSec">绿色</div>
                        <div class="dateSec">2019-01-20 13:25:02发布</div>
                    </div>
                </div>
                <div class="secLine"></div>
            </div>
            <div class="conThird">
                <div class="firstLeft">
                    <img src="../../assets/image/yxx/6-2-2.png" alt="">
                </div>
                <div class="secondRight">
                    <div class="secondTitle">
                        <p>我家有只小猫</p>
                        <div class="star"> <img src="../../assets/image/yxx/6-2-5.png" alt=""></div>
                    </div>
                    <div class="secondWord">网购很久，但是家具网购还是第一次买，和实
                        体店一样，物美价廉，省心购物。</div>
                    <div class="add">
                        <h3>追加：</h3>
                        <p>坐的很舒服，推荐给闺蜜了。</p>
                    </div>
                    <div class="secondCon">
                        <div class="circleSec"></div>
                        <div class="colorSec">绿色</div>
                        <div class="dateSec">2019-01-20 13:25:02发布</div>
                    </div>
                </div>
                <!--<div class="secLine"></div>-->
            </div>
        </div>
        <div class="null">
            <div class="nullLine"></div>
            <p>暂无更多数据</p>
            <div class="nullLine"></div>
        </div>
    </div>
</template>

<script>
    import Header from "@/components/Header";
    export default {
        name: "Comments",
        data: () => ({}),
        components: {
            "my-header": Header,

        }
    }
</script>

<style lang="scss" scoped>
    .false{
        width: 0.28rem;
        height: 0.3rem;
        text-align: center;
        line-height: 0.3rem;
        margin-top: 0.29rem;
        font-size: 18px;
        color: rgb(0,0,0);
    }
    .tu{
        width: 0.92rem;
        height: 0.3rem;
        margin-top: 0.29rem;
    }
    .tu>img{
        width: 100%;
        height: 100%;
    }
    .more{
        width: 0.36rem;
        height: 0.08rem;
        text-align: center;
        line-height: 0.08rem;
        margin-top: 0.4rem;
        font-size: 18px;
        color: rgb(0,0,0);
    }
    /*头部结束*/
    #banners{
        width: 100%;
        height: 0.97rem;
        border-bottom: 0.01rem solid rgb(255,203,63);
        display: flex;
        justify-content: space-around;
    }
    .detailed{
        width: auto;
        height: 0.97rem;
        line-height: 0.97rem;
        font-size: 0.24rem;
        letter-spacing: 0.01rem;
        /*color: rgb(0,0,0,0.7);*/
        position: relative;
    }
    #active{
        font-weight: bold;
        color:  rgb(255,203,63);
    }
    .line{
        position: absolute;
        top: 0.93rem;
        left:0;
        right: 0;
        margin: auto;
        width: 0.55rem;
        height: 0.03rem;
        background: rgb(255,203,63);
    }
    /*banner*/
    #content{
        width: 100%;
        height: auto;
        background: white;
    }
    #content .conFirst{
        width: 7.01rem;
        height: 3.48rem;
        border-bottom: 0.01rem solid rgb(215,215,215);
        margin: 0 auto ;
        padding-top: 0.3rem;
    }
    .conLine{
        width: 0.47rem;
        height: 0.02rem;
        background: rgb(255,203,63);
        /*margin-bottom: -0.01rem;*/
        margin-top: 3.17rem;
    }
    .firstLeft{
        width: 1.51rem;
        height: 100%;
        margin-right: 0.2rem;
        float: left;
    }
    .firstLeft img{
        display: block;
        width: 1.18rem;
        height: 1.18rem;
        margin: 0.21rem 0.08rem 0.13rem 0.26rem;
    }
    .firstRight{
        width: 5.3rem;
        height: 100%;
        float: right;
    }
    .rightTitle{
        width: 100%;
        height: 0.3rem;
        margin-top: 0.15rem;
        margin-bottom: 0.13rem;
    }
    .rightTitle p{
        width: auto;
        height: 0.28rem;
        line-height: 0.28rem;
        font-size: 0.28rem;
        letter-spacing: 0.03rem;
        color: rgb(51,51,51);
        float: left;
    }
    .star{
        width: 0.86rem;
        height: 0.18rem;
        margin-left: 0.15rem;
        margin-top: 0.06rem;
        float: left;
    }
    .star img{
        display: block;
        width: 0.86rem;
        height: 0.18rem;
    }
    .word{
        width: 100%;
        height: 0.55rem;
        line-height: 0.55rem;
        font-size: 0.24rem;
        letter-spacing: 0.02rem;
    }
    .rightImg{
        width: 4.6rem;
        height: 1.32rem;
    }
    .rightImg img{
        width: 2.02rem;
        height: 1.32rem;
        display: block;
        float: left;
        margin-right: 0.14rem;
    }
    .date{
        width:5.3rem;
        height: 0.6rem;
    }
    .circle{
        width: 0.07rem;
        height: 0.07rem;
        background: rgb(216,128,215);
        margin-top: 0.26rem;
        float: left;
        margin-right: 0.05rem;
    }
    .date .color{
        width: auto;
        height: 0.6rem;
        line-height: 0.6rem;
        font-size: 0.18rem;
        letter-spacing: 0.02rem;
        color: rgba(0,0,0,0.7);
        float: left;
    }
    .dateCon{
        width: auto;
        height: 0.6rem;
        line-height: 0.6rem;
        letter-spacing: 0.02rem;
        font-size: 0.18rem;
        color:  rgba(0,0,0,0.7);
        margin-left: 1.3rem;
    }
    .conSecond{
        width: 7.01rem;
        height: 2.77rem;
        background: white;
        border-bottom: 0.01rem solid rgb(215,215,215);
        margin: 0 auto;
    }
    .secondRight{
        width: 5.3rem;
        height: 100%;
        float: right;
    }
    .secondTitle{
        width: 100%;
        margin-top: 0.44rem;
        height: 0.28rem;
        margin-bottom: 0.24rem;
    }
    .secondTitle p{
        width: auto;
        height: 0.28rem;
        line-height: 0.28rem;
        letter-spacing: 0.03rem;
        color: rgb(51,51,51);
        float: left;
    }
    .secondWord{
        width: 5.3rem;
        height: 0.6rem;
        letter-spacing: 0.02rem;
        font-size: 0.24rem;
        margin-bottom: 0.22rem;
    }
    .add{
        width: 100%;
        height: 0.3rem;
    }
    .add h3{
        letter-spacing: 0.02rem;
        font-weight: 100;
        float: left;
    }
    .add p{
        letter-spacing: 0.02rem;
        font-size: 0.18rem;
        float: left;
    }
    .secondCon{
        width: 5.3rem;
        height: 0.6rem;
        float: left;
    }
    .circleSec{
        width: 0.07rem;
        height: 0.07rem;
        background: rgb(181,213,72);
        margin-top: 0.28rem;
        float: left;
    }
    .colorSec{
        width: auto;
        height: 0.6rem;
        line-height: 0.6rem;
        font-size: 0.18rem;
        letter-spacing: 0.02rem;
        color: rgba(0,0,0,0.7);
        float: left;
        margin-left: 0.05rem;
    }
    .dateSec{
        width: auto;
        height: 0.6rem;
        line-height: 0.6rem;
        font-size: 0.18rem;
        letter-spacing: 0.02rem;
        color: rgba(0,0,0,0.7);
        margin-left: 0.77rem;
        float: left;
    }
    .secLine{
        width: 0.55rem;
        background: rgb(255,203,63);
        height: 0.02rem;
        float: left;
        margin-top: -0.01rem;
    }
    .conThird{
        width: 7.01rem;
        height: 2.77rem;
        background: white;
        /*border-bottom: 0.01rem solid rgb(215,215,215);*/
        margin: 0 auto;

    }
    .null{
        width: 4rem;
        height: 0.3rem;
        margin: 0.64rem auto 0;
        display: flex;
        justify-content: space-between;
    }
    .nullLine{
        width: 1.05rem;
        background:rgb(217,217,217);
        height: 0.02rem;
        margin-top: 0.14rem;
        /*float: left;*/
    }
    .null p{
        width: auto;
        line-height: 0.3rem;
        height: 0.3rem;
        font-size: 0.18rem;
        color: rgba(0,0,0,0.7);
        letter-spacing: 0.02rem;
        /*float: left;*/
    }

</style>