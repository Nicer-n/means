<template>
    <div>
        <my-header>
            <img src="../../assets/image/cys/10.1.png" alt="" class="back" @click="$router.back()">
        </my-header>
        <div class="full">
            <img src="../../assets/image/ycj/bj.jpg" alt="">
        </div>
        <div class="white">
            <div class="login-text">
                <a href=""><p class="text-left active">登录</p></a>
                <router-link to="/sign"><p class="text-right">注册</p></router-link>
            </div>
            <p class="username">手机号</p>
            <form action="">
                <input type="text" placeholder="请输入手机号" v-model="phone">
            </form>
            <p class="password">密码</p>
            <form action="">
                <input type="password" placeholder="请输入密码" v-model="password">
            </form>
            <div class="forget">
                <div class="forget-left">
                    <img src="../../assets/image/ycj/1-login-forget.png" alt="">
                </div>
                <div class="forget-right">忘记密码?</div>
            </div>
        </div>
        <div class="login-bottom" @click="login">登录</div>
        <!--<div class="third">使用第三方登录方式</div>-->
        <!--<div class="qq">-->
            <!--<a  href="https://open.weixin.qq.com/connect/qrconnect?appid=wxf98b6468f5df696b&redirect_uri=http%3A%2F%2Fwx.qiaomiao.cn%2flogin.php&response_type=code&scope=snsapi_login&state=3d6be0a4035d839573b04816624a415e#wechat_redirect" class="chat-we">-->
                <!--<div class="chat-we-top">-->
                    <!--<i class="iconfont icon-weixin-copy"></i>-->
                <!--</div>-->
                <!--<div class="chat-we-bottom">微信登录</div>-->
            <!--</a>-->
            <!--<a  href="https://graph.qq.com/oauth2.0/show?which=Login&display=pc&response_type=code&redirect_uri=https://spcdp.cdposs.qq.com/auth/callback&client_id=101477813&state=http://spcdp.cdposs.qq.com/" class="chat-qq">-->
                <!--<div class="chat-we-top">-->
                    <!--<i class="iconfont icon-qq" style="font-size: 0.73rem;color: #6dcaf8"></i>-->
                <!--</div>-->
                <!--<div class="chat-we-bottom">QQ登录</div>-->
            <!--</a>-->
        <!--</div>-->
    </div>
</template>

<script>
    import Header from "@/components/Header";
    export default {
        name: "Login",
        data: () => ({
            phone:"",
            password:""
        }),
        methods:{
           login:function(){
               let reg1 = /^1[356789]\d{9}$/;
               let reg3 = /^[0-9a-z]{6,}$/;
               if(!reg1.test(this.phone)){
                   alert("手机号码错误");
                   return;
               }
               if(!reg3.test(this.password)){
                   alert("密码必须由6位以上的字母或数字组成");
                   return;
               }
               this.$http.post("/api/users/login",{phone:this.phone,password:this.password}).then(res=>{
                  if(res.data.code===200){
                      localStorage.token=res.data.token;
                      localStorage.login=res.data.id;
                      this.$router.push({name:localStorage.to});
                  }else{
                      alert(res.data.msg);
                  }
               }).catch(()=>{
                console.log("登录失败")
               });
           }
        },
        components:{
            "my-header":Header
        }
    }
</script>

<style lang="scss" scoped>
    @import "../../assets/font.css";
    *{
        margin: 0;
        padding: 0;
        box-sizing: border-box;


    }
    ul {
        list-style: none;
    }
    a{
        text-decoration: none;
    }
    html{
        font-size: 100px;
    }
    i{
        font-style: normal;
    }
    img{
        display: block;
    }
    @media (min-width: 320px){
        html{
            font-size: 42.6667px;
        }
    }
    @media (min-width: 360px){
        html{
            font-size:48px ;
        }
    }
    @media (min-width: 375px){
        html{
            font-size: 50px;
        }
    }
    @media (min-width: 414px){
        html{
            font-size: 55.2px;
        }
    }
    body{
        font-size: 12px;
    }
    .full{
        width: 100%;
        height: 100%;
        position: relative;
    }
    .full img{
        width: 100%;
        height: 100%;
    }
    .return-key{
        width: 0.21rem;
        height: 0.35rem;
        /*background: #fea8a8;*/
        text-align: left;
        line-height: 0.35rem;
        position: absolute;
        top: 0.67rem;
        left: 0.52rem;
    }
    .return-key i{
        width: 100%;
        height: 100%;
        color: #101214;
        font-size: 0.28rem;
        text-align: center;
        line-height: 0.35rem;
    }
    .white{
        width: 6.68rem;
        height: 5.56rem;
        background: white;
        box-shadow: 0.05rem 0.05rem 0.2rem #c1c1c1;
        margin: 0 auto;
        position: absolute;
        top:2.23rem;
        left: 50%;
        margin-left: -3.34rem;
        padding: 0.62rem;
    }
    .white .login-text{
        width: 100%;
        height: 0.32rem;
        margin-bottom: 0.51rem;
    }
    .white .login-text .text-left{
        width: 0.7rem;
        height: 100%;
        float: left;
        margin-left: 0.24rem;
        font-size: 0.34rem;
        text-align: left;
        line-height: 0.32rem;
        color: #343434;
        letter-spacing: 0.01rem;
    }
    .white .login-text .text-right{
        width: 0.7rem;
        height: 100%;
        /*background: #f9c5c7;*/
        float: right;
        margin-right: 0.24rem;
        font-size: 0.34rem;
        text-align: left;
        line-height: 0.32rem;
        color: #343434;
        letter-spacing: 0.01rem;
    }
    .white .login-text .active{
        color: #F7884B;
    }
    .username,.password{
        width: 100%;
        height: 0.25rem;
        /*background: #85c227;*/
        font-size: 0.26rem;
        text-align: left;
        line-height: 0.25rem;
        letter-spacing: 0.01rem;
        color: #7a7a7a;
        margin-bottom: 0.36rem;
    }
    .white form input{
        border: none;
        border-bottom: 3px solid #cccccc;
        /*box-shadow: 0 0.1rem 0.2rem red;*/
        width: 100%;
        height: 0.6rem;
        font-size: 0.26rem;
        letter-spacing: 0.01rem;
        text-align: left;
        color: #737373;
        margin-bottom: 0.48rem;
    }
    .forget{
        width: 100%;
        height: 0.23rem;
        /*background: #85c227;*/
    }
    .forget-left{
        width: 0.23rem;
        height: 100%;
        /*background: #e6cd69;*/
        float: left;
        margin-right: 0.36rem;
    }
    .forget-left img{
        width: 0.3rem;
        height: 0.3rem;
        text-align: center;
        line-height: 0.23rem;
    }
    .forget-right{
        width: 1.3rem;
        height: 100%;
        /*background: #e6cd69;*/
        float: left;
        text-align: left;
        line-height: 0.23rem;
        letter-spacing: 0.02rem;
        font-size: 0.24rem;
    }
    .login-bottom{
        width: 6.68rem;
        height: 0.79rem;
        background: white;
        box-shadow: 0.05rem 0.05rem 0.2rem #c1c1c1;
        position: absolute;
        top: 8.15rem;
        left: 50%;
        margin-left: -3.34rem;
        font-size: 0.32rem;
        color: #8d8d8d;
        text-align: center;
        line-height: 0.79rem;
        letter-spacing: 0.02rem;
    }
    .third{
        width: 100%;
        height: 0.27rem;
        background: rgba(0,0,0,0);
        position: absolute;
        top: 9.91rem;
        text-align: center;
        line-height: 0.27rem;
        letter-spacing: 0.02rem;
    }
    .qq{
        width: 3.57rem;
        height: 1.28rem;
        /*background: #f6d88c;*/
        position: absolute;
        top: 10.54rem;
        left: 50%;
        margin-left: -1.78rem;
    }
    .qq .chat-we{
        /*display: block;*/
        width: 1rem;
        height: 100%;
        /*background: #ef9196;*/
        float: left;
        display: flex;
        justify-content: space-around;
        align-content: space-between;
        flex-wrap: wrap;
    }
    .qq .chat-qq{
        width: 1rem;
        height: 100%;
        /*background: #ef9196;*/
        float: right;
        /*display: block;*/
        display: flex;
        justify-content: space-around;
        align-content: space-between;
        flex-wrap: wrap;
    }
    .qq .chat-we .chat-we-top,.qq .chat-qq .chat-we-top{
        width: 0.75rem;
        height: 0.75rem;
        /*background: #b3f9f7;*/
    }
    .qq .chat-we .chat-we-top i,.qq .chat-qq .chat-we-top i{
        width: 100%;
        height: 100%;
        color: #3cb035;
        font-size: 0.8rem;
        text-align: center;
        line-height: 0.75rem;
    }
    .qq .chat-we .chat-we-bottom,.qq .chat-qq .chat-we-bottom{
        width: 100%;
        height: 0.22rem;
        /*background: #c9e9aa;*/
        text-align: center;
        line-height: 0.22rem;
        font-size: 0.22rem;
        letter-spacing: 0.01rem;
    }
</style>