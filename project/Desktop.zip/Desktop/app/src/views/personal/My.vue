<template>
    <div>
        <my-header></my-header>
        <div class="a">
            <div class="background"><img src="../../assets/image/chy/background.png" alt=""></div>
            <div class="personal">
                <div class="personal-one">
                    <div class="personal-left">
                        <span style="font-size: 0.26rem;letter-spacing: 0.02rem;font-weight: bold">我家有只小狗</span>
                        <span style="font-size: 0.26rem;letter-spacing: 0.02rem;font-weight: bold;color: orange;font-family: iconfont">&#xe7f0;</span><a
                            href="">
                        <p style="font-size: 0.18rem;color: #000000;opacity: 0.7;letter-spacing: 0.01rem;margin-top: 0.09rem">
                            编辑个人资料</p>
                    </a>
                    </div>
                    <a href="">
                        <div class="personal-right"><img src="../../assets/image/chy/touxiang.png" alt=""></div>
                    </a>
                </div>
                <div class="personal-two">
                    <router-link to="/orderlist?state=0">
                        <div class="wait"><p style="font-size: 0.36rem;color: orange">&#xe643;</p>
                            <p style="font-size: 0.24rem;font-weight: bold">待付款</p>
                        </div>
                    </router-link>
                    <router-link to="/orderlist?state=1">
                        <div class="wait"><p style="font-size: 0.36rem;color: orange">&#xe627;</p>
                            <p style="font-size: 0.24rem;font-weight: bold">待发货</p>
                        </div>
                    </router-link>
                    <router-link to="/orderlist?state=2">
                        <div class="wait"><p style="font-size: 0.36rem;color: orange">&#xe635;</p>
                            <p style="font-size: 0.24rem;font-weight: bold">待收货</p>
                        </div>
                    </router-link>
                    <router-link to="/orderlist?state=3">
                        <div class="wait"><p style="font-size: 0.36rem;color: orange">&#xe61c;</p>
                            <p style="font-size: 0.24rem;font-weight: bold">待评价</p>
                        </div>
                    </router-link>
                    <router-link to="/orderlist?state=4">
                        <div class="wait"><p style="font-size: 0.36rem;color: orange">&#xe7ca;</p>
                            <p style="font-size: 0.24rem;font-weight: bold">待退款</p>
                        </div>
                    </router-link>
                </div>
            </div>
            <div class="set">
                <router-link to="/orderlist">
                    <div class="wait">
                        <p style="font-size: 0.36rem;color: orange">&#xe616;</p>
                        <p style="font-size: 0.24rem;font-weight: bold">我的订单</p>
                    </div>
                </router-link>
                <a href="">
                    <div class="wait">
                        <p style="font-size: 0.36rem;color: orange">&#xe609;</p>
                        <p style="font-size: 0.24rem;font-weight: bold">我的收藏</p>
                    </div>
                </a>
                <a href="">
                    <div class="wait">
                        <p style="font-size: 0.36rem;color: orange">&#xe659;</p>
                        <p style="font-size: 0.24rem;font-weight: bold">浏览记录</p>
                    </div>
                </a>
                <a href="">
                    <div class="wait">
                        <p style="font-size: 0.36rem;color: orange">&#xe658;</p>
                        <p style="font-size: 0.24rem;font-weight: bold">收货地址</p>
                    </div>
                </a>
                <a href="">
                    <div class="wait">
                        <p style="font-size: 0.36rem;color: orange">&#xe655;</p>
                        <p style="font-size: 0.24rem;font-weight: bold">设置</p>
                    </div>
                </a>
                <a href=""></a>
            </div>
        </div>
        <my-footer hot="my"></my-footer>
    </div>
</template>
<script>
    import Header from "@/components/Header";
    import Footer from "@/components/Footer";

    export default {
        name: "My",
        data: () => ({}),
        components: {
            "my-header": Header,
            "my-footer": Footer
        }
    }
</script>

<style lang="scss" scoped>

    #head {
        width: 100%;
        height: 0.88rem;
        background-color: #ffffff;
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 0 0.12rem;
    }

    .head-one {
        width: 0.28rem;
        height: 0.3rem;
        text-align: center;
        line-height: 0.3rem;
        font-family: iconfont;
    }

    .head-two {
        width: 0.92rem;
        height: 0.3rem;
    }

    .head-two img {
        width: 0.92rem;
        height: 0.3rem;
    }

    .head-three {
        width: 0.36rem;
        height: 0.08rem;
        display: flex;
        justify-content: space-around;
    }

    .head-three > div {
        width: 0.08rem;
        height: 0.08rem;
        border-radius: 50%;
    }

    .a {
        width: 100%;
        height: 12rem;
        background: #fff;
        position: relative;
    }

    .background {
        width: 100%;
        height: 2rem;
    }

    .background img {
        width: 100%;
        height: 2rem;
    }

    .personal {
        padding: 0.4rem;
        width: 7.02rem;
        height: 3.1rem;
        background-color: #ffffff;
        box-shadow: 0 0.01rem 0.21rem 0 rgba(118, 118, 118, 0.17);
        border-radius: 0.1rem;
        position: absolute;
        top: -7.5rem;
        bottom: 0;
        left: 0;
        right: 0;
        margin: auto;
    }

    .personal-one {
        width: 100%;
        height: 0.91rem;
    }

    .personal-left {
        width: 2rem;
        height: auto;
        float: left;
    }

    .personal-right {
        width: 0.91rem;
        height: 0.92rem;
        background-color: #000000;
        border-radius: 50%;
        float: right;
    }

    .personal-right img {
        width: 0.91rem;
        height: 0.92rem;
    }

    .personal-two {
        width: 100%;
        height: 0.69rem;
        margin-top: 0.89rem;
        display: flex;
        justify-content: space-between;
    }

    .wait {
        width: 1rem;
        height: 0.69rem;
        font-family: iconfont;
        text-align: center;
    }

    .set {
        width: 7.02rem;
        height: 4.24rem;
        background-color: #ffffff;
        box-shadow: 0 0.01rem 0.21rem 0 rgba(118, 118, 118, 0.17);
        border-radius: 0.1rem;
        margin: 2.5rem auto;
        display: flex;
        flex-wrap: wrap;
        justify-content: space-around;
        align-content: space-around;
    }

    .set a {
        width: 2rem;
        height: 2rem;
        display: flex;
        align-items: center;
        justify-content: center;
    }

    .about {
        width: 7.02rem;
        height: 2.42rem;
        background-color: #ffffff;
        box-shadow: 0 0.01rem 0.21rem 0 rgba(118, 118, 118, 0.17);
        border-radius: 0.1rem;
        position: absolute;
        top: 8rem;
        bottom: 0;
        left: 0;
        right: 0;
        margin: auto;
        padding: 0.5rem;
    }

    .about-one {
        width: 6.02rem;
        height: 0.45rem;
        font-family: iconfont;
        border-bottom: 0.01rem solid #ccc;
        margin-top: 0.2rem;
    }

    /*
    */
    #footer {
        width: 100%;
        height: 0.98rem;
        position: fixed;
        bottom: 0;
        left: 0;
    }

    .footer-box {
        width: 7.5rem;
        height: 0.98rem;
        background-color: #fafafa;
        border: solid 0.01rem #bfbfbf;
        margin: 0 auto;
        display: flex;
        justify-content: space-around;
    }

    .footer-box-row {
        float: left;
        height: 0.79rem;
        margin-top: 0.14rem;
        text-align: center;
    }

    .footer-img {
        margin: 0 auto;
    }

    .footer-img > .iconfont {
        font-size: 0.38rem;
    }

    .footer-img > .iconfont.active {
        color: #ffac13;
    }

    .footer-title {
        height: 0.2rem;
        font-size: 0.2rem;
        line-height: 0.2rem;
        letter-spacing: 0.01rem;
        margin-top: 0.09rem;
        color: #333;
    }

    .footer-title.active {
        color: #ffcb3f;
    }

</style>