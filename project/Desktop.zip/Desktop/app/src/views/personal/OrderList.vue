<template>
    <div style="height:100%;">
        <my-header>
            <img src="../../assets/image/cys/10.1.png" alt="" class="back" @click="$router.back()">
        </my-header>
        <div class="container" ref="wrapper">
            <div class="inner">
            <div id="evaluate">
                <div class="ping">我的订单</div>
            </div>
            <nav>
                <ul class="navBox">
                    <swiper :options="options" ref="myswiper">
                        <swiper-slide>
                            <li class="item" @click="state=10">
                                <div :class="['text', {active:state===10}]">全部</div>
                                <div :class="['line', {active:state===10}]"></div>
                            </li>
                        </swiper-slide>
                        <swiper-slide>
                            <li class="item" @click="state='0'">
                                <div :class="['text', {active:state==='0'}]">待付款</div>
                                <div :class="['line', {active:state==='0'}]"></div>
                            </li>
                        </swiper-slide>
                        <swiper-slide>
                            <li class="item" @click="state='1'">
                                <div :class="['text', {active:state==='1'}]">待发货</div>
                                <div :class="['line', {active:state==='1'}]"></div>
                            </li>
                        </swiper-slide>
                        <swiper-slide>
                            <li class="item" @click="state='2'">
                                <div :class="['text', {active:state==='2'}]">待收货</div>
                                <div :class="['line', {active:state==='2'}]"></div>
                            </li>
                        </swiper-slide>
                        <swiper-slide>
                            <li class="item" @click="state='3'">
                                <div :class="['text', {active:state==='3'}]">待评价</div>
                                <div :class="['line', {active:state==='3'}]"></div>
                            </li>
                        </swiper-slide>
                        <swiper-slide>
                            <li class="item" @click="state='4'">
                                <div :class="['text', {active:state==='4'}]">待退货</div>
                                <div :class="['line', {active:state==='4'}]"></div>
                            </li>
                        </swiper-slide>
                    </swiper>
                </ul>
            </nav>
            <ul class="all" v-if="state===10">
                <li class="item" v-for="item in orderList">
                    <div class="img">
                        <img :src="item.thumb" alt="">
                    </div>
                    <div class="textBox">
                        <p>
                            <span class="textEng">{{item.name_en}}</span>
                            <span class="textChi">{{item.name_ch}}</span>
                        </p>
                        <p>{{item.size}}</p>
                        <p>2019-03-20</p>
                    </div>
                    <div class="priceBox">
                        <p>￥{{item.goods_price}}*{{item.number}}</p>
                        <p><span> <b>{{item.price}}</b></span> <span>RMB</span></p>
                        <p><b>{{item.stateText}}</b></p>
                    </div>
                </li>
            </ul>

            <ul class="all" v-if="state==='0'">
                <li class="item" v-for="item in cartList">
                    <div class="img">
                        <img :src="item.thumb" alt="">
                    </div>
                    <div class="textBox">
                        <p>
                            <span class="textEng">{{item.name_en}}</span>
                            <span class="textChi">{{item.name_ch}}</span>
                        </p>
                        <p>{{item.size}}</p>
                        <p>2019-03-20</p>
                    </div>
                    <div class="priceBox">
                        <p>￥{{item.goods_price}}*{{item.number}}</p>
                        <p><span> <b>{{item.price}}</b></span> <span>RMB</span></p>
                        <p><b>未付款</b></p>
                    </div>
                </li>
            </ul>

            <ul class="all" v-if="state==='1'">
                <li class="item" v-for="item in sendList">
                    <div class="img">
                        <img :src="item.thumb" alt="">
                    </div>
                    <div class="textBox">
                        <p>
                            <span class="textEng">{{item.name_en}}</span>
                            <span class="textChi">{{item.name_ch}}</span>
                        </p>
                        <p>{{item.size}}</p>
                        <p>2019-03-20</p>
                    </div>
                    <div class="priceBox">
                        <p>￥{{item.goods_price}}*{{item.number}}</p>
                        <p><span> <b>{{item.price}}</b></span> <span>RMB</span></p>
                        <p><b>待发货</b></p>
                    </div>
                </li>
            </ul>

            <ul class="all" v-if="state==='2'">
                <li class="item" v-for="item in getList">
                    <div class="img">
                        <img :src="item.thumb" alt="">
                    </div>
                    <div class="textBox">
                        <p>
                            <span class="textEng">{{item.name_en}}</span>
                            <span class="textChi">{{item.name_ch}}</span>
                        </p>
                        <p>{{item.size}}</p>
                        <p>2019-03-20</p>
                    </div>
                    <div class="priceBox">
                        <p>￥{{item.goods_price}}*{{item.number}}</p>
                        <p><span> <b>{{item.price}}</b></span> <span>RMB</span></p>
                        <p><b>待收货</b></p>
                    </div>
                </li>
            </ul>

            <ul class="all" v-if="state==='3'">
                <li class="item" v-for="item in commentList">
                    <div class="img">
                        <img :src="item.thumb" alt="">
                    </div>
                    <div class="textBox">
                        <p>
                            <span class="textEng">{{item.name_en}}</span>
                            <span class="textChi">{{item.name_ch}}</span>
                        </p>
                        <p>{{item.size}}</p>
                        <p>2019-03-20</p>
                    </div>
                    <div class="priceBox">
                        <p>￥{{item.goods_price}}*{{item.number}}</p>
                        <p><span> <b>{{item.price}}</b></span> <span>RMB</span></p>
                        <p><b>待评价</b></p>
                    </div>
                </li>
            </ul>

            <ul class="all" v-if="state==='4'">
                <li class="item" v-for="item in backList">
                    <div class="img">
                        <img :src="item.thumb" alt="">
                    </div>
                    <div class="textBox">
                        <p>
                            <span class="textEng">{{item.name_en}}</span>
                            <span class="textChi">{{item.name_ch}}</span>
                        </p>
                        <p>{{item.size}}</p>
                        <p>2019-03-20</p>
                    </div>
                    <div class="priceBox">
                        <p>￥{{item.goods_price}}*{{item.number}}</p>
                        <p><span> <b>{{item.price}}</b></span> <span>RMB</span></p>
                        <p><b>待退货</b></p>
                    </div>
                </li>
            </ul>
        </div>
        <my-footer hot="my"></my-footer>
    </div>
    </div>
</template>
<script>
    import Header from "@/components/Header";
    import Footer from "@/components/Footer";
    import {swiper, swiperSlide} from 'vue-awesome-swiper';
    import {mapGetters, mapMutations} from "vuex";
    import BScroll from "better-scroll";
    export default {
        name: "OrderList",
        data: () => ({
            state: 10,
            options: {
                slidesPerView: 5,
                freeMode: true
            }
        }),
        computed: {
            ...mapGetters(['orderList', 'cartList', 'sendList', 'getList', 'commentList', 'backList']),
            swiper() {
                return this.$refs.myswiper.swiper
            }
        },
        components: {
            "my-header": Header,
            "my-footer": Footer,
            swiper,
            swiperSlide
        },
        methods: {
            ...mapMutations(['concat']),
            fetchOrderList: function () {
                this.$http.get("/api/orders/orders", {
                    params: {
                        uid: localStorage.login
                    }
                }).then(res => {
                    if (res.data.code === 200) {
                        let orderList = res.data.data;
                        orderList.forEach(v => {
                            v.checked = false;
                        });
                        this.concat(orderList);
                    } else {
                        console.log("获取失败");
                    }
                }).catch(() => {
                    console.log("获取失败");
                })
            }
        },
        mounted() {
            if (this.$route.query.state) {
                this.state = this.$route.query.state;
                if (this.state === "4") {
                    this.swiper.slideNext();
                }
            }
            this.fetchOrderList();
            this.orderList.forEach(v => {
                switch (v.state) {
                    case 0:
                        v.stateText = "未付款";
                        break;
                    case 1:
                        v.stateText = "待发货";
                        break;
                    case 2:
                        v.stateText = "待收货";
                        break;
                    case 3:
                        v.stateText = "待评价";
                        break;
                    case 4:
                        v.stateText = "待退货";
                        break;
                }
            });
            this.scroll=new BScroll(this.$refs.wrapper,{
                click:true
            });
        }
    }
</script>

<style lang="scss" scoped>
    .container{
        width:100%;
        height:calc(100% - 0.98rem);
        overflow:hidden;
        position:relative;
    }

    #evaluate {
        width: 100%;
        height: 0.78rem;
        /*padding-top: 0.26rem;*/
        border-bottom: 1px solid #e3e3e3;
        /*background: deepskyblue;*/
        position: relative;
        background: #fff;

    }

    .toLeft {
        width: 0.15rem;
        height: 0.24rem;
        margin-left: 0.24rem;
        line-height: 0.24rem;
        font-size: 13px;
        color: rgb(0, 0, 0);
        float: left;
        /*background:red;*/
        position: absolute;
        top: 0.27rem;
    }

    .toLeft > i {
        font-size: 0.34rem;
        text-align: center;
        line-height: 0.24rem;
        margin-left: -0.04rem;
    }

    .ping {
        /*float: left;*/
        width: 100%;
        height: 100%;
        line-height: 0.78rem;
        text-align: center;
        font-family: MicrosoftYaHei;
        font-size: 0.28rem;

        /*top: 1.14rem;*/
        /*left: 0;*/
        /*right: 0;*/
        /*bottom: 0;*/
        /*margin-left:auto;*/
        /*margin-right: auto;*/
        /*background:#fcd7a2;*/
        letter-spacing: 0.01rem;

    }

    nav {
        width: 100%;
        height: 0.78rem;
        background: #fff;
        padding: 0 0.44rem;
    }

    .navBox {
        width: 100%;
        height: 100%;
        /*background:#fff57f;*/
        border-bottom: 0.01rem solid #ffcb3f;
    }

    .navBox {
        .item {
            width: 1.324rem;
            .text {
                font-size: 0.24rem;
                text-align: center;
                line-height: 0.75rem;
                letter-spacing: 0.02rem;
                &.active {
                    font-weight: bold;
                    color: #ffcb3f;
                }
            }
            .line.active {
                width: 0.46rem;
                height: 0.03rem;
                background: #ffcb3f;
                border-radius: 0.13rem;
                margin: 0 auto;
            }
        }
    }

    .all {
        width: 7.02rem;
        height: auto;
        /*background:#a7d4ad;*/
        margin: 0.23rem auto 0.61rem auto;
    }

    .all > .item {
        width: 100%;
        height: 2.62rem;
        background: #fff;
        border-radius: 0.14rem;
        box-shadow: 0 0.01rem 0.15rem #cfcfcf;
        padding: 0.56rem 0.31rem 0 0.2rem;
        margin-bottom: 0.1rem;
    }

    .all > .item > .img {
        width: 1.86rem;
        height: 1.31rem;
        /*background:#b7cddb;*/
        float: left;
        margin-right: 0.13rem;
    }

    .all > .item > .img > img {
        width: 100%;
        height: 100%;
    }

    .all > .item > .textBox {
        /*width:1rem;*/
        height: 100%;
        /*background:#fff57f;*/
        float: left;
    }

    .all > .item > .textBox > p > .textEng {
        font-size: 0.18rem;
        font-family: Arial;
    }

    .all > .item > .textBox > p > .textChi {
        font-size: 0.22rem;
    }

    .all > .item > .textBox > p:nth-child(2) {
        font-size: 0.18rem;
        color: #7e7e7e;
        margin-top: 0.09rem;
    }

    .all > .item > .textBox > p:nth-child(3) {
        font-size: 0.18rem;
        color: #7e7e7e;
        margin-top: 0.37rem;
    }

    .priceBox {
        /*width:1rem;*/
        height: 100%;
        /*background:#fcd7a2;*/
        float: right;
    }

    .priceBox > p:nth-child(1) {
        letter-spacing: 0.02rem;
    }

    .priceBox > p:nth-child(2) {
        letter-spacing: 0.01rem;
        margin-top: 0.79rem;
    }

    .priceBox > p:nth-child(2) > span:nth-child(1) {
        font-size: 0.26rem;
    }

    .priceBox > p:nth-child(2) > span:nth-child(2) {
        font-size: 0.16rem;
    }

    .priceBox > p:nth-child(3) {
        font-size: 0.22rem;
        color: #ffcb3f;
        float: right;
    }

    .recommend {
        padding: 0 0.37rem;
        margin-bottom: 1rem;
    }

    .titleBox {
        width: 100%;
        height: 0.3rem;
        /*background:#a7d4ad;*/
    }

    .titleBox > .titleLine {
        width: 0.03rem;
        height: 0.21rem;
        background: #ffcb3f;
        float: left;
        margin: 0.04rem 0.1rem 0 0;
    }

    .titleBox > .titleText {
        font-size: 0.3rem;
        letter-spacing: 0.01rem;
        line-height: 0.3rem;
    }

    .recommend > .itemBox {
        width: 6.77rem;
        height: 10.4rem;
        /*background:#a79bcd;*/
        margin: 0.36rem auto 0.35rem auto;
        display: flex;
        flex-wrap: wrap;
        justify-content: space-between;
    }

    .recommend > .itemBox > .item {
        width: 3.24rem;
        height: 5.08rem;
        /*background:#5ec2d1;*/
        float: left;
        box-shadow: 0 0.01rem 0.15rem #cfcfcf;
    }

    .recommend > .itemBox > .item > a {
        display: block;
        width: 100%;
        height: 100%;
    }

    .recommend > .itemBox > .item > a > .imgBox {
        width: 100%;
        height: 3.05rem;
        /*background:#ee857f;*/
    }

    .recommend > .itemBox > .item > a > .imgBox > img {
        width: 100%;
        height: 100%;
    }

    .recommend > .itemBox > .item > a > .textBox {
        width: 100%;
        height: auto;
        /*background:#fff57f;*/
        margin-top: 0.2rem;
        padding-left: 0.22rem;
    }

    .recommend > .itemBox > .item > a > .textBox > .textLine {
        width: 0.32rem;
        height: 0.02rem;
        background: black;
    }

    .recommend > .itemBox > .item > a > .textBox > .textEng {
        font-size: 0.18rem;
        margin-top: 0.1rem;
    }

    .recommend > .itemBox > .item > a > .priceBox {
        width: 100%;
        height: 0.44rem;
        /*background:#accd02;*/
        margin-top: 0.54rem;
        padding: 0 0.2rem;
        float: left;
    }

    .recommend > .itemBox > .item > a > .priceBox > .priceText {
        /*background:#ee857f;*/
        float: left;
    }

    .recommend > .itemBox > .item > a > .priceBox > .priceText > span:nth-child(1) {
        font-size: 0.22rem;
        line-height: 0.44rem;
    }

    .recommend > .itemBox > .item > a > .priceBox > .priceText > span:nth-child(2) {
        font-size: 0.16rem;
        line-height: 0.44rem;
    }

    .recommend > .itemBox > .item > a > .priceBox > .click {
        width: 1.53rem;
        height: 0.44rem;
        background: #ffcb3f;
        border-radius: 0.1rem;
        float: right;
        padding: 0 0 0 0.23rem;
    }

    .recommend > .itemBox > .item > a > .priceBox > .click > .icon {
        width: 0.16rem;
        height: 0.16rem;
        /*background:#fff57f;*/
        margin-top: 0.12rem;
        line-height: 0.16rem;
        text-align: center;
        float: left;

    }

    .recommend > .itemBox > .item > a > .priceBox > .click > .icon > i {
        font-size: 0.2rem;
        color: white;

    }

    .recommend > .itemBox > .item > a > .priceBox > .click > .text {
        font-size: 0.2rem;
        color: white;
        float: left;
        line-height: 0.44rem;
        margin-left: 0.05rem;
    }

    .toLeft img {
        width: 0.2rem;
        height: 0.3rem;
        margin-left: 0.1rem;
    }

</style>