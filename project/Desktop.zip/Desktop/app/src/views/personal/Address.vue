<template>
    <div>
        <my-header></my-header>
        <div id="evaluate">
            <div class="toLeft"><img src="../../assets/image/hly/15-left.png" alt=""></div>
            <div class="ping">收货地址</div>
        </div>
        <!--第一块-->
        <div id="del">
            <div class="dOne">
                <div id="cLeft4">
                    <span class="lOne4">王立</span>
                    <span class="lTwo4">13735154627</span>
                    <span class="lThree4">公司</span>
                    <span class="lFour4">山西省太原市小店区万柏林街道幸福里小区4号楼1204</span>
                </div>
            </div>
            <div class="dTwo">
                <img src="../../assets/image/ljq/7-22.png" alt="">
            </div>
            <div class="dThree">设为默认
                <div class="dFour">删除</div>
            </div>
        </div>
        <!--第二块-->
        <div id="list">
            <div id="con">
                <div id="cLeft">
                    <span class="lOne">王立</span>
                    <span class="lTwo">13735154627</span>
                    <span class="lThree">住宅</span>
                    <span class="lFour">山西省太原市小店区万柏林街道幸福里小区4号楼1204</span>
                </div>
                <div id="cRight">
                    <img src="../../assets/image/ljq/7-22.png" alt="">
                </div>
            </div>
        </div>
        <!--第三块-->
        <div id="list1">
            <div id="con1">
                <div id="cLeft1">
                    <span class="lOne1">王清</span>
                    <span class="lTwo1">18735184627</span>
                    <span class="lThree1">学校</span>
                    <span class="lFour1">山西省太原市万柏林区万柏林街道幸福里小区4号楼1204</span>
                </div>
                <div id="cRight1">
                    <img src="../../assets/image/ljq/7-22.png" alt="">
                </div>
            </div>
        </div>
        <!--第四块-->
        <div id="list2">
            <div id="con2">
                <div id="cLeft2">
                    <span class="lOne2">王立</span>
                    <span class="lTwo2">13735154627</span>
                    <span class="lThree2">其他</span>
                    <span class="lFour2">山西省太原市小店小店区万柏林街道我幸福里超前小区4号楼
                1204号</span>
                </div>
                <div id="cRight2">
                    <img src="../../assets/image/ljq/7-22.png" alt="">
                </div>
            </div>
        </div>
        <!--第五块-->
        <div id="foot">
            <div id="fCont">新增收货地址</div>
        </div>
    </div>
</template>

<script>
    import Header from "@/components/Header";
    export default {
        name: "Address",
        data: () => ({}),
        components: {
            "my-header": Header,

        }
    }
</script>

<style lang="scss" scoped>
    #evaluate{
        width: 100%;
        height: 0.78rem;
        padding-top: 0.26rem;
        border-bottom: 1px solid #e3e3e3;
        background: rgb(255,255,255);
    }
    .toLeft{
        width: 0.15rem;
        height: 0.24rem;
        margin-left: 0.24rem;
        line-height: 0.24rem;
        font-size: 13px;
        color: rgb(0,0,0);
        float: left;
    }
    .ping{
        float: left;
        height: 0.27rem;
        width: 1.45rem;
        line-height: 0.30rem;
        text-align: center;
        font-family: MicrosoftYaHei;
        font-size: 0.28rem;
        position: absolute;
        top: 1.14rem;
        left: 0;
        right: 0;
        bottom: 0;
        margin-left:auto;
        margin-right: auto;
    }

    /*第一块*/
    #del{
        width: 100%;
        height: 1.37rem;
        border-bottom: 1px solid #e3e3e3;
    }
    .dOne{
        width: 3.99rem;
        height: 1.37rem;
        float: left;
        overflow: hidden;
    }
    #cLeft4{
        width: 5.9rem;
        height: 1.1rem;
        float: left;
        margin-top: 0.25rem;
        margin-left: -1.6rem;
        position: relative;
    }
    #cLeft4>.lOne4{
        width: 0.62rem;
        height: 0.28rem;
        line-height: 0.28rem;
        position: absolute;
        top: 0.04rem;
        font-family: MicrosoftYaHei;
        font-size: 0.3rem;
        color: rgb(0,0,0);
    }
    #cLeft4>.lTwo4{
        width: 2.05rem;
        height: 0.23rem;
        position: absolute;
        top: 0.08rem;
        left: 1.12rem;
        line-height: 0.23rem;
        letter-spacing: 0.03rem;
        font-family: MicrosoftYaHei;
        font-size: 0.28rem;
        color: rgb(0,0,0);
    }
    #cLeft4>.lThree4{
        width: 0.66rem;
        height: 0.4rem;
        background: rgb(255,203,63);
        border-radius: 0.04rem;
        position: absolute;
        top: 0;
        left: 3.39rem;
        text-align: center;
        line-height: 0.4rem;
        font-family: MicrosoftYaHei;
        font-size: 0.22rem;
        color: rgb(51,51,51);
    }
    #cLeft4>.lFour4{
        width: 5.8rem;
        height: 0.22rem;
        position: absolute;
        top: 0.58rem;
        left: 0.01rem;
        line-height: 0.22rem;
        font-family: MicrosoftYaHei;
        font-size: 0.22rem;
        color: rgb(102,102,102);
    }
    .dTwo{
        width: 0.27rem;
        height: 0.28rem;
        float: left;
        margin-left: 0.69rem;
        margin-top: 0.81rem;
        font-size: 0.3rem;
    }
    .dThree{
        width: 2.29rem;
        height: 100%;
        background: rgb(244,244,244);
        float: right;
        margin-left: 0.26rem;
        text-align: center;
        line-height: 1.37rem;
        font-family: MicrosoftYaHei;
        font-size: 0.22rem;
        color: rgb(51,51,51);
    }
    .dFour{
        width: 1.15rem;
        height: 100%;
        background: rgb(255,203,63);
        float: right;
        text-align: center;
        line-height: 1.37rem;
        font-family: MicrosoftYaHei;
        font-size: 0.22rem;
        color: rgb(51,51,51);
    }

    /*第二块*/
    #list{
        width: 100%;
        height: 1.1rem;
        margin-top: 0.27rem;
        padding-left: 0.25rem;
        padding-right: 0.25rem;
    }
    #con{
        width: 100%;
        height: 100%;
        border-bottom: 1px solid #e3e3e3;
    }
    #cLeft{
        width: 5.9rem;
        height: 1.1rem;
        float: left;
        position: relative;
    }
    #cLeft>.lOne{
        width: 0.62rem;
        height: 0.28rem;
        line-height: 0.28rem;
        position: absolute;
        top: 0.04rem;
        font-family: MicrosoftYaHei;
        font-size: 0.3rem;
        color: rgb(0,0,0);
    }
    #cLeft>.lTwo{
        width: 2.05rem;
        height: 0.23rem;
        position: absolute;
        top: 0.08rem;
        left: 1.12rem;
        line-height: 0.23rem;
        letter-spacing: 0.03rem;
        font-family: MicrosoftYaHei;
        font-size: 0.28rem;
        color: rgb(0,0,0);
    }
    #cLeft>.lThree{
        width: 0.66rem;
        height: 0.4rem;
        background: rgb(255,203,63);
        border-radius: 0.04rem;
        position: absolute;
        top: 0;
        left: 3.39rem;
        text-align: center;
        line-height: 0.4rem;
        font-family: MicrosoftYaHei;
        font-size: 0.22rem;
        color: rgb(51,51,51);
    }
    #cLeft>.lFour{
        width: 5.8rem;
        height: 0.22rem;
        position: absolute;
        top: 0.58rem;
        left: 0.01rem;
        line-height: 0.22rem;
        font-family: MicrosoftYaHei;
        font-size: 0.22rem;
        color: rgb(102,102,102);
    }
    #cRight{
        float: right;
        width: 0.27rem;
        height: 1.1rem;
        margin-top: 0.52rem;
        font-size: 0.3rem;
    }

    /*第三块*/
    #list1{
        width: 100%;
        height: 1.1rem;
        margin-top: 0.27rem;
        padding-left: 0.25rem;
        padding-right: 0.25rem;
    }
    #con1{
        width: 100%;
        height: 100%;
        border-bottom: 1px solid #e3e3e3;
    }
    #cLeft1{
        width: 5.9rem;
        height: 1.1rem;
        float: left;
        position: relative;
    }
    #cLeft1>.lOne1{
        width: 0.62rem;
        height: 0.28rem;
        line-height: 0.28rem;
        position: absolute;
        top: 0.04rem;
        font-family: MicrosoftYaHei;
        font-size: 0.3rem;
        color: rgb(0,0,0);
    }
    #cLeft1>.lTwo1{
        width: 2.05rem;
        height: 0.23rem;
        position: absolute;
        top: 0.08rem;
        left: 1.12rem;
        line-height: 0.23rem;
        letter-spacing: 0.03rem;
        font-family: MicrosoftYaHei;
        font-size: 0.28rem;
        color: rgb(0,0,0);
    }
    #cLeft1>.lThree1{
        width: 0.66rem;
        height: 0.4rem;
        background: rgb(255,203,63);
        border-radius: 0.04rem;
        position: absolute;
        top: 0;
        left: 3.39rem;
        text-align: center;
        line-height: 0.4rem;
        font-family: MicrosoftYaHei;
        font-size: 0.22rem;
        color: rgb(51,51,51);
    }
    #cLeft1>.lFour1{
        width: 5.8rem;
        height: 0.22rem;
        position: absolute;
        top: 0.58rem;
        left: 0.01rem;
        line-height: 0.22rem;
        font-family: MicrosoftYaHei;
        font-size: 0.22rem;
        color: rgb(102,102,102);
    }
    #cRight1{
        float: right;
        width: 0.27rem;
        height: 1.1rem;
        margin-top: 0.2rem;
        margin-left: 0.69rem;
        font-size: 0.3rem;
    }

    /*第四块*/
    #list2{
        width: 100%;
        height: 1.3rem;
        margin-top: 0.27rem;
        padding-left: 0.25rem;
        padding-right: 0.25rem;
    }
    #con2{
        width: 100%;
        height: 100%;
        border-bottom: 1px solid #e3e3e3;
    }
    #cLeft2{
        width: 5.9rem;
        height: 1.3rem;
        float: left;
        position: relative;
    }
    #cLeft2>.lOne2{
        width: 0.62rem;
        height: 0.28rem;
        line-height: 0.28rem;
        position: absolute;
        top: 0.04rem;
        font-family: MicrosoftYaHei;
        font-size: 0.3rem;
        color: rgb(0,0,0);
    }
    #cLeft2>.lTwo2{
        width: 2.05rem;
        height: 0.23rem;
        position: absolute;
        top: 0.08rem;
        left: 1.12rem;
        line-height: 0.23rem;
        letter-spacing: 0.03rem;
        font-family: MicrosoftYaHei;
        font-size: 0.28rem;
        color: rgb(0,0,0);
    }
    #cLeft2>.lThree2{
        width: 0.66rem;
        height: 0.4rem;
        background: rgb(255,203,63);
        border-radius: 0.04rem;
        position: absolute;
        top: 0;
        left: 3.39rem;
        text-align: center;
        line-height: 0.4rem;
        font-family: MicrosoftYaHei;
        font-size: 0.22rem;
        color: rgb(51,51,51);
    }
    #cLeft2>.lFour2{
        width: 6rem;
        height: 0.62rem;
        position: absolute;
        top: 0.58rem;
        left: 0.01rem;
        line-height: 0.32rem;
        font-family: MicrosoftYaHei;
        font-size: 0.22rem;
        color: rgb(102,102,102);
    }
    #cRight2{
        float: right;
        width: 0.27rem;
        height: 1.1rem;
        margin-top: 0.55rem;
        font-size: 0.3rem;
    }
    #foot{
        width: 100%;
        height: 0.77rem;
        margin-top: 4.37rem;
        padding-left: 0.56rem;
        padding-right: 0.56rem;
    }
    #fCont{
        width: 100%;
        height: 100%;
        background: rgb(255,203,63);
        border-radius: 0.1rem;
        text-align: center;
        line-height: 0.77rem;
        font-family: MicrosoftYaHei-Bold;
        font-weight: bold;
        font-size: 0.28rem;
        color: rgb(255,255,255);
    }
    .toLeft img{
        width: 0.2rem;
        height: 0.3rem;
        margin-left: 0.1rem;
    }
    #cRight2 img{
        width: 0.1rem;
        height: 0.2rem;
    }
    .dTwo img{
        width: 0.1rem;
        height: 0.2rem;
    }
    #cRight img{
        width: 0.1rem;
        height: 0.2rem;
    }
    #cRight1 img{
        width: 0.1rem;
        height: 0.2rem;
    }

</style>