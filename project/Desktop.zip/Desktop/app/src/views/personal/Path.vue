<template>
    <div>
        <my-header></my-header>
        <div id="mine">
            <a href=""><img src="../../assets/image/hly/15-left.png" alt=""></a>
            <p>浏览记录</p>
        </div>
        <div id="contents">
            <div class="recommend">
                <div class="line"></div>
                <p>今日</p>
            </div>
            <div class="box">
                <a href=""><img src="../../assets/image/hly/15-sofa1.png" alt=""></a>
                <p class="bosc">BOSC XISTERA</p>
                <p class="introduce">现代客厅沙发</p>
                <p class="num">￥520*2</p>
                <p class="color">绿色/单人座</p>
                <p class="date">2019-03-20</p>
                <p class="money">1040</p>
                <p class="rmb">RMB</p>
                <a href="" class="look">找相似</a>
                <a href="" class="sure">加入购物车</a>
            </div>
            <div class="box">
                <a href=""><img src="../../assets/image/hly/15-sofa2.png" alt=""></a>
                <p class="bosc">BOSC XISTERA</p>
                <p class="introduce">现代客厅沙发</p>
                <p class="num">￥520*1</p>
                <p class="color">绿色/单人座</p>
                <p class="date">2019-03-20</p>
                <p class="money" style="left: 5.72rem;top: 1.69rem">520</p>
                <p class="rmb">RMB</p>
                <a href="" class="look">找相似</a>
                <a href="" class="sure">加入购物车</a>
            </div>
            <div class="box" style="margin-bottom: 0.51rem">
                <a href=""><img src="../../assets/image/hly/15-sofa3.png" alt=""></a>
                <p class="bosc">BOSC XISTERA</p>
                <p class="introduce">现代客厅沙发</p>
                <p class="num">￥520*1</p>
                <p class="color">绿色/单人座</p>
                <p class="date">2019-03-20</p>
                <p class="money" style="left: 5.72rem;top: 1.69rem">520</p>
                <p class="rmb">RMB</p>
                <a href="" class="look">找相似</a>
                <a href="" class="sure">加入购物车</a>
            </div>
            <div class="recommend">
                <div class="line"></div>
                <p>3月11日</p>
            </div>
            <div class="box">
                <a href=""><img src="../../assets/image/hly/15-sofa1.png" alt=""></a>
                <p class="bosc">BOSC XISTERA</p>
                <p class="introduce">现代客厅沙发</p>
                <p class="num">￥520*2</p>
                <p class="color">绿色/单人座</p>
                <p class="date">2019-03-20</p>
                <p class="money">1040</p>
                <p class="rmb">RMB</p>
                <a href="" class="look">找相似</a>
                <a href="" class="sure">加入购物车</a>
            </div>
            <div class="box" style="margin-bottom: 0;">
                <a href=""><img src="../../assets/image/hly/15-sofa2.png" alt=""></a>
                <p class="bosc">BOSC XISTERA</p>
                <p class="introduce">现代客厅沙发</p>
                <p class="num">￥520*1</p>
                <p class="color">绿色/单人座</p>
                <p class="date">2019-03-20</p>
                <p class="money" style="left: 5.72rem;top: 1.69rem">520</p>
                <p class="rmb">RMB</p>
                <a href="" class="look">找相似</a>
                <a href="" class="sure">加入购物车</a>
            </div>
        </div>
        <div id="bottom">
            <ul class="bottomCenter">
                <li>
                    <a href="">
                        <img src="../../assets/image/hly/15-icon1.png" alt="">首页
                    </a>
                </li>
                <li>
                    <a href="">
                        <img src="../../assets/image/hly/15-icon2.png" alt="">分类
                    </a>
                </li>
                <li style="width: 0.62rem;">
                    <a href="">
                        <img src="../../assets/image/hly/15-icon3.png" alt="" style="margin-left: 0.13rem">购物车
                    </a>
                </li>
                <li style="color: rgb(255,203,63);font-weight: bold;">
                    <a href="" style="color: rgb(255,203,63);font-weight: bold;">
                        <img src="../../assets/image/hly/15-icon4.png" alt="">我的
                    </a>
                </li>
            </ul>
        </div>
        <my-footer></my-footer>
    </div>
</template>

<script>
    import Header from "@/components/Header";
    import Footer from "@/components/Footer";

    export default {
        name: "Path",
        data: () => ({}),
        components: {
            "my-header": Header,
            "my-footer":Footer,
        }
    }
</script>

<style lang="scss" scoped>
    #mine {
        width: 100%;
        height: 0.78rem;
        border-top: 0.01rem solid rgb(238, 238, 238);
        position: relative;
    }

    #mine a img {
        width: 0.15rem;
        height: 0.24rem;
        position: absolute;
        left: 0.24rem;
        top: 0.27rem;
    }

    #mine p {
        width: 1.16rem;
        height: 0.28rem;
        margin: 0.25rem auto;
        text-align: center;
        line-height: 0.28rem;
        font-size: 0.28rem;
        letter-spacing: 0.01rem;
        font-family: MicrosoftYaHei;
    }

    #contents {
        width: 100%;
        height: auto;
        background: #f2f2f2;
        padding-top: 0.23rem;
        padding-bottom: 0.28rem;
    }

    .box {
        width: 7.02rem;
        height: 2.76rem;
        border-radius: 0.1rem;
        background: rgb(255, 255, 255);
        box-shadow: 0 0.01rem 0.21rem 0 rgba(0, 0, 0, 0.09);
        margin: 0.3rem auto 0.3rem;
        display: flex;
        position: relative;
    }

    .box a img {
        width: 1.86rem;
        height: 1.31rem;
        margin-top: 0.52rem;
        margin-left: 0.2rem;
    }

    .bosc {
        font-family: MicrosoftYaHeiLight;
        font-size: 0.18rem;
        color: rgb(0, 0, 0);
        letter-spacing: 0.01rem;
        position: absolute;
        left: 2.2rem;
        top: 0.73rem;
    }

    .introduce {
        font-size: 0.24rem;
        font-family: MicrosoftYaHei;
        color: rgb(0, 0, 0);
        letter-spacing: 0.01rem;
        position: absolute;
        top: 0.66rem;
        left: 3.67rem;
        font-weight: bold;
    }

    .num {
        color: rgb(0, 0, 0);
        font-size: 0.24rem;
        font-family: MicrosoftYaHei;
        letter-spacing: 0.02rem;
        position: absolute;
        left: 5.74rem;
        top: 0.69rem;
    }

    .color {
        font-family: MicrosoftYaHeiLight;
        font-size: 0.18rem;
        letter-spacing: 0.02rem;
        color: rgba(0, 0, 0, 0.7);
        position: absolute;
        left: 2.21rem;
        top: 0.99rem;
    }

    .date {
        color: rgba(0, 0, 0, 0.7);
        font-family: MicrosoftYaHei;
        letter-spacing: 0.02rem;
        font-size: 0.18rem;
        position: absolute;
        left: 2.19rem;
        top: 1.54rem;
    }

    .money {
        font-size: 0.26rem;
        font-family: MicrosoftYaHei-Bold;
        font-weight: bold;
        letter-spacing: 0.03rem;
        color: rgb(0, 0, 0);
        position: absolute;
        left: 5.53rem;
        top: 1.67rem;
    }

    .rmb {
        font-family: MicrosoftYaHei;
        color: rgb(0, 0, 0);
        font-size: 0.18rem;
        letter-spacing: 0.02rem;
        position: absolute;
        left: 6.3rem;
        top: 1.74rem;
    }

    .look {
        font-size: 0.24rem;
        color: rgb(153, 153, 153);
        font-family: MicrosoftYaHei;
        letter-spacing: 0.02rem;
        position: absolute;
        left: 3.99rem;
        top: 2.19rem;
    }

    .sure {
        width: 1.59rem;
        height: 0.44rem;
        border-radius: 0.04rem;
        border: 0.01rem solid rgb(255, 203, 63);
        position: absolute;
        left: 5.11rem;
        top: 2.09rem;
        text-align: center;
        line-height: 0.44rem;
        color: rgb(255, 203, 63);
        font-size: 0.24rem;
        letter-spacing: 0.02rem;
        font-family: MicrosoftYaHei;
    }

    .recommend {
        width: 1.4rem;
        height: 0.3rem;
        margin-left: 0.32rem;
        padding-top: 0.05rem;
        display: flex;
    }

    .line {
        width: 0.03rem;
        height: 0.21rem;
        background: rgb(255, 203, 63);
    }

    .recommend p {
        font-size: 0.3rem;
        color: rgb(0, 0, 0);
        font-family: MicrosoftYaHei;
        letter-spacing: 0.02rem;
        line-height: 0.2rem;
        margin-left: 0.09rem;
    }

    #bottom {
        width: 100%;
        height: 0.98rem;
        border-top: 0.01rem solid rgb(191, 191, 191);
    }

    .bottomCenter {
        width: 6.03rem;
        height: 0.98rem;
        margin: 0 auto;
        display: flex;
        justify-content: space-between;
    }

    .bottomCenter li {
        width: 0.41rem;
        height: 0.69rem;
        margin-top: 0.15rem;
        color: rgb(0, 0, 0);
        font-family: MicrosoftYaHei;
        font-size: 0.2rem;
    }

    .bottomCenter li a {
        color: rgb(0, 0, 0);
    }

    .bottomCenter li a img {
        width: 0.36rem;
        height: 0.4rem;
        margin-left: 0.02rem;
    }

</style>