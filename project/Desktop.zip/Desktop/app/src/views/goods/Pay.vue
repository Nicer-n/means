<template>
    <div>
        <div class="container">
            <my-header>
                <img src="../../assets/image/cys/10.1.png" alt="" class="back" @click="$router.back()">
            </my-header>
            <div class="orderTop">
                <div class="orderTopLittle">
                    <div class="left">
                        <div class="text">确认订单</div>
                        <div class="line"></div>
                    </div>
                </div>
            </div>
            <div class="order">
                <div class="one" v-for="item in payList">
                    <div class="imgBox">
                        <img :src="item.thumb" alt="">
                    </div>
                    <div class="text1">
                        <p>{{item.name_en}}</p>
                        <p><b>{{item.name_ch}}</b></p>
                        <p>{{item.size}}</p>
                    </div>
                    <div class="price">
                        <span><b>{{item.goods_price}}</b></span><span>RMB</span>
                    </div>
                    <div class="number">x{{item.number}}</div>
                </div>
                <div class="two">
                    <div class="total">商品总价</div>
                    <div class="totalNumber"><span><b>{{totalPrice}}</b></span><span>RMB</span></div>
                </div>
            </div>
            <!--<div class="pay">-->
                <!--<div class="weChat">-->
                    <!--<div class="img">-->
                        <!--<img src="image/lzx/weChat.png" alt="">-->
                    <!--</div>-->
                    <!--<div class="text">微信支付</div>-->
                <!--</div>-->
                <!--<div class="weChat">-->
                    <!--<div class="img">-->
                        <!--<img src="image/lzx/aliPay.png" alt="">-->
                    <!--</div>-->
                    <!--<div class="text">微信支付</div>-->
                <!--</div>-->
            <!--</div>-->
            <div class="goPay">
                <div class="price">
                    <p>
                        <span>付款</span>
                        <span><b>{{totalPrice}}</b></span>
                        <span>RMB</span>
                    </p>
                </div>
                <div class="click">
                        <div class="text">
                            <div class="textOne"><b @click="pay">去支付</b></div>
                            <div class="textTwo">
                                <div class="icon">
                                    <i class="iconfont icon-miaobiao"></i>
                                </div>
                                <div class="time">29:59</div>
                            </div>
                        </div>
                </div>
            </div>
            <!--<div class="black">
                <div class="confirmPay">
                    <div class="one"><b>支付</b>
                        <div class="icon">
                            <i class="iconfont icon-wrong-1"></i>
                        </div>
                    </div>
                    <div class="two">
                        <p>VICOR家居公司</p>
                        <p><b>￥1040</b></p>
                    </div>
                    <div class="three">
                        <div class="left">
                            <div class="icon">
                                <i class="iconfont icon-lingqian"></i>
                            </div>
                            <div class="change">零钱</div>
                        </div>
                        <div class="right">
                            <i class="iconfont icon-arrow-right"></i>
                        </div>
                    </div>
                    <a href="8.html" class="four"><b>确认支付</b></a>
                </div>
            </div>-->
        </div>
    </div>
</template>

<script>
    import Header from "@/components/Header";
    import {mapGetters} from "vuex";
    export default {
        name: "Pay",
        data: () => ({

        }),
        computed:{
            ...mapGetters(["payList"]),
            totalPrice() {
                let total = 0;
                this.payList.forEach(v => {
                    total += v.price;
                });
                return total;
            }
        },
        methods:{
            pay(){
               this.$http.post("/api/pay/pay",{
                   money:this.totalPrice
               }).then(res=>{
                   if(res.data.code===200){
                     this.payList.forEach(v=>{
                           v.state=1;
                     });
                     this.$http.post("/api/orders/pay",{
                         data:this.payList
                     }).then(res=>{
                        if(res.data.code===200){
                           this.$router.push("/payresult")
                        }else{
                           console.log("提交失败");
                        }
                     }).catch(()=>{
                         console.log("提交失败");
                     })
                   }else{

                   }
               }).catch(()=>{
                   console.log("支付异常")
               })
            }
        },
        components: {
            "my-header": Header,
        }
    }
</script>

<style lang="scss" scoped>
    .container{
        background:#fcfcfc;
    }
    .orderTop{
        width:100%;
        height:0.78rem;
        /*background:#dab765;*/
    }
    .orderTopLittle{
        width:7.5rem;
        height:100%;
        /*background:#56a796;*/
        margin:0 auto;
        padding-left:0.24rem;
    }
    .orderTopLittle>.left{
        height:100%;
    }
    .orderTopLittle>.left>.text{
        font-size:0.28rem;
        line-height:0.76rem;
        /*float:left;*/
        /*background: skyblue;*/
    }
    .orderTopLittle>.left>.line{
        width:0.47rem;
        height:0.02rem;
        background:#ffcb3f;
        /*float:left;*/
    }
    /*评价*/
    #evaluate{
        width: 100%;
        height: 0.78rem;
        padding-top: 0.26rem;
        border-bottom: 1px solid #e3e3e3;
        background: rgb(255,255,255);
    }
    .toLeft{
        width: 0.15rem;
        height: 0.24rem;
        margin-left: 0.24rem;
        line-height: 0.24rem;
        font-size: 13px;
        color: rgb(0,0,0);
        float: left;
    }
    .ping{
        float: left;
        width: 0.56rem;
        height: 0.27rem;
        line-height: 0.30rem;
        text-align: center;
        font-family: MicrosoftYaHei;
        font-size: 0.28rem;
        position: absolute;
        top: 1.14rem;
        left: 0;
        right: 0;
        bottom: 0;
        margin-left:auto;
        margin-right: auto;
    }
    .order{
        width:6.83rem;
        height:4.08rem;
        /*background:#fcd7a2;*/
        /*padding:0 0.23rem;*/
        margin:0 auto;
        border-top:0.01rem solid white;
    }
    .order>.one{
        width:100%;
        height:0.85rem;
        /*background:#a0d8f9;*/
        margin-top:0.48rem;
        border: 0.01rem solid white;
    }
    .order>.one>.imgBox{
        width:1.02rem;
        height:0.85rem;
        /*background:#d4cbe6;*/
        float:left;

    }
    .order>.one>.imgBox>img{
        width:100%;
        height:100%;
    }
    .order>.one>.text{
        /*width:3rem;*/
        /*height:0.66rem;*/
        /*background:#accd02;*/
        /*margin-left:0.1rem;*/
        margin:0.1rem 0 0 0.1rem;
        float:left;
    }
    .order>.one>.text>p:nth-child(1){
        font-size: 0.16rem;
        /*background:#ee857f;*/
        letter-spacing:0.01rem;
    }
    .order>.one>.text>p:nth-child(2){
        font-size: 0.22rem;
        /*background:#ee857f;*/
        /*letter-spacing:0.01rem;*/
    }
    .order>.one>.text>p:nth-child(3){
        font-size: 0.16rem;
        /*background:#ee857f;*/
    }
    .order>.one>.price{
        /*background:#708dc9;*/
        float:left;
        /*margin-top:0.31rem;*/
        margin:0.31rem 0 0 0.83rem;

    }
    .order>.one>.price>span:nth-child(1){
        font-size:0.26rem;
    }
    .order>.one>.price>span:nth-child(2){
        font-size:0.18rem;
    }
    .order>.one>.number{
        /*background:red;*/
        font-size:0.24rem;
        margin:0.32rem 0 0 0.77rem;
        float:left;
    }
    .order>.one>.have{
        font-size:0.24rem;
        letter-spacing: 0.01rem;
        float:right;
        margin-top:0.3rem;
    }
    .order>.two{
        width:100%;
        height:0.34rem;
        /*background:#5ec2d1;*/
        margin-top:0.42rem;
        border-bottom:0.01rem solid #dddddd;
    }
    .order>.two>.total{
        font-size:0.24rem;
        letter-spacing: 0.01rem;
        float:left;
    }
    .order>.two>.totalNumber{
        float:right;
    }
    .order>.two>.totalNumber>span:nth-child(1){
        font-size:0.22rem;
        letter-spacing:0.01rem;
        /*background:#ee857f;*/
        line-height:0.34rem;
    }
    .order>.two>.totalNumber>span:nth-child(2){
        font-size:0.16rem;
    }
    .order>.three{
        width:100%;
        height:0.67rem;
        /*background:#b7cdda;*/
        padding-top:0.34rem;
        border-bottom:0.01rem solid #dddddd;
    }
    .order>.three>.total{
        float:left;
    }
    .order>.three>.icon{
        width:0.27rem;
        height:0.3rem;
        /*background:#ee857f;*/
        float:left;
        margin-left:0.45rem;
    }
    .order>.three>.icon>i{
        font-size:0.26rem;
        color:#666;
    }
    .order>.three>p{
        font-size:0.24rem;
        float:right;
        letter-spacing:0.01rem;
    }
    .four{
        width:100%;
        height:0.44rem;
        /*background:#a79bcb;*/
        margin-top:0.57rem;
    }
    .four>.left{
        font-size:0.18rem;
        letter-spacing:0.01rem;
        line-height:0.44rem;
        float:left;
    }
    .four>.right{
        width:5.6rem;
        height:100%;
        text-align: center;
        line-height:0.44rem;
        color:#8d8d8d;
        border:0.01rem solid #8d8d8d;
        float:right;
        font-size:0.18rem;
        letter-spacing:0.01rem;
    }
    .receipt{
        width:7.5rem;
        height:1.96rem;
        /*background:#a6d4ad;*/
        /*margin-top:0.34rem;*/
        padding-left:0.26rem;
        margin:0.34rem auto 0 auto;
    }
    .receipt>.one{
        width:6.37rem;
        height:0.87rem;
        /*background:#dddddd;*/
        border-bottom:0.01rem solid #dddddd;
    }
    .receipt>.one>.text{
        font-size:0.28rem;
        line-height:0.85rem;
        /*background:#ef8680;*/
        /*float:left;*/
        letter-spacing:0.01rem;
    }
    .receipt>.one>.line{
        width:0.47rem;
        height:0.02rem;
        /*background:#ffcb3f;*/
        float:left;
    }
    .receipt>div.noReceipt{
        border:none;
        font-size:0.24rem;
        /*background:#dab765;*/
        height:1.08rem;
    }
    .receipt>div.noReceipt>.text{
        font-size:0.24rem;
        line-height:1.08rem;
    }
    .pay{
        width:7.5rem;
        height:3rem;
        /*background:#fcd7a2;*/
        /*margin-top:0.34rem;*/
        margin:0.34rem auto 0 auto;
        padding:0.65rem 1.24rem 0 1.24rem;
    }
    .weChat{
        width:1.07rem;
        height:2rem;
        /*background:#a0d9f7;*/
        float:left;
    }
    .weChat>.img{
        width:100%;
        height:1.03rem;
        /*background:#5ec2d1;*/
    }
    .weChat>.img>img{
        width:100%;
        height:100%;
    }
    .weChat>.text{
        font-size:0.24rem;
        letter-spacing:0.01rem;
        margin-top:0.22rem;
        text-align: center;
    }
    .weChat:nth-child(2){
        float:right;
    }
    .goPay{
        width:7.5rem;
        height:0.9rem;
        /*background:#d2cce6;*/
        /*margin-top:0.63rem;*/
        padding-left:0.25rem;
        margin:0.63rem auto 0 auto;
        position: absolute;
        left:0;
        bottom:0;
    }
    .goPay>.price{
        margin-top:0.33rem;
        float:left;
    }
    .goPay>.price>p>span:nth-child(1){
        font-size:0.26rem;
        letter-spacing:0.01rem;
    }
    .goPay>.price>p>span:nth-child(2){
        font-size:0.28rem;
        letter-spacing:0.01rem;
        color:#ffcd4a;
    }
    .goPay>.price>p>span:nth-child(3){
        letter-spacing:0.01rem;
        font-size:0.22rem;
    }
    .goPay>.click{
        width:2.1rem;
        height:0.91rem;
        background:#ffcb3f;
        border-radius:0.1rem;
        float:right;
    }
    .textOne{
        text-align: center;
        color:white;
        font-size:0.28rem;
        letter-spacing:0.02rem;
        line-height: .9rem;
        /*background:#b7cdda;*/

    }
    .text>.textTwo{
        width:100%;
        text-align: center;
        /*background:red;*/
        /*margin-top:0.03rem;*/
        margin:0.03rem auto 0 auto;
        /*float:left;*/

    }
    .icon{
        width:0.2rem;
        height:0.2rem;
        /*background:#a79bcb;*/
        line-height:0.2rem;
        float:left;
        margin-left:0.6rem;
    }
    .icon>i{
        font-size:0.2rem;
        text-align: center;
        color:white;
    }
     .time{
        font-size:0.18rem;
        color:white;
        margin-left:0.14rem;
        float:left;
    }
    .confirmPay{
        padding:0 0.3rem;
        width:5.64rem;
        height:4.95rem;
        background:white;
        margin:3.80rem auto;
    }
    .confirmPay>.one{
        width:100%;
        height:0.87rem;
        /*background:#fff57f;*/
        border-bottom:0.01rem solid#dddddd;
        font-size:0.3rem;
        text-align: center;
        line-height:0.8rem;
        position:relative;
    }
    .confirmPay>.one>.icon{
        width:0.27rem;
        height:0.3rem;
        /*background:#009a44;*/
        position:absolute;
        top:0.28rem;
        text-align: center;
        line-height:0.3rem;
    }
    .confirmPay>.one>.icon>i{
        font-size:0.32rem;
        color:#333;
    }
    .confirmPay>.two{
        width:100%;
        height:1.64rem;
        /*background:#a79bcb;*/
        border-bottom:0.01rem solid #dddddd;
        display: flex;
        align-content: space-around;
        flex-wrap:wrap;
        justify-content: space-between;
    }
    .confirmPay>.two>p:nth-child(1){
        width:100%;
        font-size:0.28rem;
        text-align: center;
    }
    .confirmPay>.two>p:nth-child(2){
        width:100%;
        font-size:0.4rem;
        text-align: center;
    }
    .confirmPay>.three{
        width:100%;
        height:0.83rem;
        /*background:#e85369;*/
        border-bottom:0.01rem solid#dddddd;
    }
    .confirmPay>.three>.left{
        /*width:2rem;*/
        height:100%;
        /*background:#accd02;*/
        float:left;
    }
    .confirmPay>.three>.left>.icon{
        width:0.5rem;
        height:0.5rem;
        /*background:#fff57f;*/
        float:left;
        margin-top:0.19rem;
    }
    .confirmPay>.three>.left>.icon>i{
        font-size:0.5rem;
        line-height:0.5rem;
        text-align: center;
        color:#fcdf67;
    }
    .confirmPay>.three>.left>.change{
        font-size:0.24rem;
        margin-left:0.13rem;
        line-height:0.83rem;
        float:left;
        /*text-align: center;*/
    }
    .confirmPay>.three>.right{
        width:0.18rem;
        height:0.29rem;
        /*background: #009a44;*/
        float:right;
        margin-top:0.3rem;
    }
    .confirmPay>.three>.right>i{
        font-size:0.4rem;
        line-height:0.24rem;
        text-align: center;
        color:#a2a2a2;
        margin-left:-0.13rem;
    }
    .confirmPay>.four{
        width:4.99rem;
        height:0.82rem;
        background:#ffcb3f;
        font-size:0.28rem;
        text-align: center;
        line-height:0.82rem;
        border-radius:0.1rem;
        margin-top:0.36rem;
        color:white;
        display: block;
    }
    .black {
        width: 7.5rem;
        height: 13.34rem;
        background: rgba(0, 0, 0, 0.5);
        position: absolute;
        top: 0;
        left: 50%;
        margin-left: -3.75rem;
    }

</style>