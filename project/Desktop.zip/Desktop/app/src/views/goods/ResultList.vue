<template>
    <div style="height:100%;">
        <my-header>
            <img src="../../assets/image/cys/10.1.png" alt="" class="back" @click="$router.back()">
        </my-header>
        <div class="wrapper" ref="wrapper">
            <div class="inner">
                <div id="search">
                    <div class="search-left">
                        <input type="text" placeholder="布艺沙发" :value="search" ref="input">
                        <i class="iconfont icon-search"></i>
                    </div>
                    <div class="search-text">
                        <span @click="handleSearch">搜索</span>
                    </div>
                </div>
                <my-recommend :goods="goods" :showTitle="false"></my-recommend>
            </div>
        </div>
    </div>
</template>
<script>
    import Header from "@/components/Header";
    import Recommend from "@/components/Recommend";
    import BScroll from "better-scroll";
    export default {
        name: "ResultList",
        data: () => ({
            search: "",
            goods: [],
            page: 1,
            total: 0,
            history:[]
        }),
        methods: {
            fetchGoodsData: function () {
                this.$http.get("/api/goods/goods", {
                    params: {
                        page: this.page,
                        pageSize: 8,
                        name: this.search
                    }
                }).then(res => {
                    if (res.data.code === 200) {
                        this.goods = [...this.goods, ...res.data.data];
                        this.total = res.data.total;
                        if(!this.scroll){
                          this.$nextTick(()=>{
                            this.scroll=new BScroll(this.$refs.wrapper,{
                              pullUpLoad:{
                                  threshold:0
                              },
                              click:true
                            });
                            this.scroll.on("pullingUp",()=>{
                             if(this.page*8>this.total){
                                 this.scroll.finishPullUp();
                                 return;
                             }
                             this.page++;
                             this.fetchGoodsData();
                             this.scroll.finishPullUp();
                            })
                          })
                        }else{
                          this.scroll.refresh();
                        }
                    } else {
                        console.log("获取失败");
                    }
                }).catch(() => {
                    console.log("获取失败");
                })
            },
            handleSearch:function(){
                this.search=this.$refs.input.value;
                if (this.search === "") {
                    this.$router.back();
                    return;
                }
                let index = this.history.indexOf(this.search);
                if (index !== -1) {
                    this.history.splice(index, 1);
                }
                this.history.unshift(this.search);
                if (this.history.length > 10) {
                    this.history = this.history.slice(0, 10);
                    this.history.push("...");
                }
                localStorage.setItem("history", JSON.stringify(this.history));
                this.page=1;
                this.goods=[];
                this.fetchGoodsData();
            }
        },
        components: {
            "my-header": Header,
            "my-recommend": Recommend
        },
        mounted: function () {
            this.search = this.$route.query.search;
            this.fetchGoodsData();
            this.history=JSON.parse(localStorage.history);
        }
    }
</script>

<style lang="scss" scoped>
    .wrapper{
        width:100%;
        height:100%;
        overflow: hidden;
        position: relative;
    }
    .inner{
        width:100%;
        height:auto;
    }
    #search {
        width: 100%;
        height: 0.78rem;
        background-color: #ffffff;
        padding: 0 0.33rem;
        display: flex;
        align-items: center;
        justify-content: space-around;
    }

    .search-left {
        width: 6rem;
        height: 0.6rem;
        border-radius: 0.3rem;
        border: solid 0.01rem #d9d9d9;
        opacity: 0.6;
        float: left;
        text-align: right;
        line-height: 0.6rem;
        padding-right: 0.2rem;
        position: relative;
    }

    .search-left > input {
        width: 6.04rem;
        height: 0.6rem;
        line-height: 0.6rem;
        border-radius: 0.3rem;
        border: 0.01rem solid #ccc;
        outline: none;
        padding-left: 0.56rem;
    }

    .search-left > .iconfont {
        position: absolute;
        left: 0.19rem;
        top: 0;
        font-size: 0.24rem;
    }

    .search-top {
        font-family: iconfont;
        width: 0.24rem;
        height: 0.25rem;
        text-align: center;
        line-height: 0.25rem;
        font-size: 26px;
        float: left;
        margin-top: 0.175rem;
        margin-left: 0.1rem;
    }

    .search-text {
        width: auto;
        height: 0.78rem;
        line-height: 0.78rem;
    }

    .search-text a {
        font-size: 0.24rem;
        font-weight: normal;
        font-stretch: normal;
        letter-spacing: 0.01rem;
        color: #000000;
    }

</style>