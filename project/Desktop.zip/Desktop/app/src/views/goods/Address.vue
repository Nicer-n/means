<template>
    <div>

        <my-header>
            <img src="../../assets/image/cys/10.1.png" alt="" class="back" @click="$router.back()">
        </my-header>
        <div id="evaluate">
            <div class="ping">选择收货地址</div>
        </div>

        <div
                :class="['list',{active:index===item.id}]"
                v-for="item in addressList"
                @click="index=item.id"
        >
            <div id="con">
                <div id="cLeft">
                    <span class="lOne">{{item.name}}</span>
                    <span class="lTwo">13735154627</span>
                    <span class="lThree">{{item.type}}</span>
                    <span class="lFour">{{item.province}}{{item.city}}{{item.area}}{{item.address}}</span>
                </div>
            </div>
        </div>

        <!--第五块-->
        <div id="foot">
            <div id="fCont" @click="choose">选择收货地址</div>
        </div>
    </div>
</template>

<script>
    import Header from "@/components/Header";
    export default {
        name: "Address",
        data: () => ({
            addressList:[],
            index:0
        }),
        components: {
            "my-header": Header,
        },
        methods:{
           fetchUserAddress(){
              this.$http.get("/api/address/address",{
                 params:{
                     uid:localStorage.login
                 }
              }).then(res=>{
                  if(res.data.code===200){
                      this.addressList=res.data.data;
                      this.addressList.forEach(v=>{
                          switch (v.type) {
                              case 1:
                                  v.type = "住宅";
                                  break;
                              case 2:
                                  v.type = "公司";
                                  break;
                              case 3:
                                  v.type = "学校";
                                  break;
                              default: v.type="其它";
                          }
                      })
                  }else{
                      console.log("数据查询失败");
                  }
              }).catch(()=>{
                  console.log("数据获取失败");
              })
           },
           choose(){
               if(this.index===0){
                   alert("请选择收货地址");
                   return;
               }
               let address=this.addressList.find(v=>v.id===this.index);
               localStorage.address=JSON.stringify(address);
               this.$router.back();
           }
        },
        mounted(){
           this.fetchUserAddress();
        }
    }
</script>

<style lang="scss" scoped>
    #evaluate{
        width: 100%;
        height: 0.78rem;
        padding-top: 0.26rem;
        border-bottom: 1px solid #e3e3e3;
        background: rgb(255,255,255);
    }
    .toLeft{
        width: 0.15rem;
        height: 0.24rem;
        margin-left: 0.24rem;
        line-height: 0.24rem;
        font-size: 13px;
        color: rgb(0,0,0);
        float: left;
    }
    .ping{
        float: left;
        height: 0.27rem;
        width: 1.9rem;
        line-height: 0.30rem;
        text-align: center;
        font-family: MicrosoftYaHei;
        font-size: 0.28rem;
        position: absolute;
        top: 1.14rem;
        left: 0;
        right: 0;
        bottom: 0;
        margin-left:auto;
        margin-right: auto;
    }

    /*第一块*/

    /*第二块*/
    .list{
        width: 100%;
        height: 1.1rem;
        margin-top: 0.27rem;
        padding-left: 0.25rem;
        padding-right: 0.25rem;
    }
    .list.active{
        background:#ffcb3f;
    }
    #con{
        width: 100%;
        height: 100%;
        border-bottom: 1px solid #e3e3e3;
    }
    #cLeft{
        width: 5.9rem;
        height: 1.1rem;
        float: left;
        position: relative;
    }
    #cLeft>.lOne{
        width: 0.62rem;
        height: 0.28rem;
        line-height: 0.28rem;
        position: absolute;
        top: 0.04rem;
        font-family: MicrosoftYaHei;
        font-size: 0.3rem;
        color: rgb(0,0,0);
    }
    #cLeft>.lTwo{
        width: 2.05rem;
        height: 0.23rem;
        position: absolute;
        top: 0.08rem;
        left: 1.12rem;
        line-height: 0.23rem;
        letter-spacing: 0.03rem;
        font-family: MicrosoftYaHei;
        font-size: 0.28rem;
        color: rgb(0,0,0);
    }
    #cLeft>.lThree{
        width: 0.66rem;
        height: 0.4rem;
        background: rgb(255,203,63);
        border-radius: 0.04rem;
        position: absolute;
        top: 0;
        left: 3.39rem;
        text-align: center;
        line-height: 0.4rem;
        font-family: MicrosoftYaHei;
        font-size: 0.22rem;
        color: rgb(51,51,51);
    }
    #cLeft>.lFour{
        width: 5.8rem;
        height: 0.22rem;
        position: absolute;
        top: 0.58rem;
        left: 0.01rem;
        line-height: 0.22rem;
        font-family: MicrosoftYaHei;
        font-size: 0.22rem;
        color: rgb(102,102,102);
    }
    #cRight{
        float: right;
        width: 0.27rem;
        height: 1.1rem;
        margin-top: 0.52rem;
        font-size: 0.3rem;
    }

    /*第三块*/
    #list1{
        width: 100%;
        height: 1.1rem;
        margin-top: 0.27rem;
        padding-left: 0.25rem;
        padding-right: 0.25rem;
    }
    #con1{
        width: 100%;
        height: 100%;
        border-bottom: 1px solid #e3e3e3;
    }
    #cLeft1{
        width: 5.9rem;
        height: 1.1rem;
        float: left;
        position: relative;
    }
    #cLeft1>.lOne1{
        width: 0.62rem;
        height: 0.28rem;
        line-height: 0.28rem;
        position: absolute;
        top: 0.04rem;
        font-family: MicrosoftYaHei;
        font-size: 0.3rem;
        color: rgb(0,0,0);
    }
    #cLeft1>.lTwo1{
        width: 2.05rem;
        height: 0.23rem;
        position: absolute;
        top: 0.08rem;
        left: 1.12rem;
        line-height: 0.23rem;
        letter-spacing: 0.03rem;
        font-family: MicrosoftYaHei;
        font-size: 0.28rem;
        color: rgb(0,0,0);
    }
    #cLeft1>.lThree1{
        width: 0.66rem;
        height: 0.4rem;
        background: rgb(255,203,63);
        border-radius: 0.04rem;
        position: absolute;
        top: 0;
        left: 3.39rem;
        text-align: center;
        line-height: 0.4rem;
        font-family: MicrosoftYaHei;
        font-size: 0.22rem;
        color: rgb(51,51,51);
    }
    #cLeft1>.lFour1{
        width: 5.8rem;
        height: 0.22rem;
        position: absolute;
        top: 0.58rem;
        left: 0.01rem;
        line-height: 0.22rem;
        font-family: MicrosoftYaHei;
        font-size: 0.22rem;
        color: rgb(102,102,102);
    }
    #cRight1{
        float: right;
        width: 0.27rem;
        height: 1.1rem;
        margin-top: 0.2rem;
        margin-left: 0.69rem;
        font-size: 0.3rem;
    }

    /*第四块*/
    #list2{
        width: 100%;
        height: 1.3rem;
        margin-top: 0.27rem;
        padding-left: 0.25rem;
        padding-right: 0.25rem;
    }
    #con2{
        width: 100%;
        height: 100%;
        border-bottom: 1px solid #e3e3e3;
    }
    #cLeft2{
        width: 5.9rem;
        height: 1.3rem;
        float: left;
        position: relative;
    }
    #cLeft2>.lOne2{
        width: 0.62rem;
        height: 0.28rem;
        line-height: 0.28rem;
        position: absolute;
        top: 0.04rem;
        font-family: MicrosoftYaHei;
        font-size: 0.3rem;
        color: rgb(0,0,0);
    }
    #cLeft2>.lTwo2{
        width: 2.05rem;
        height: 0.23rem;
        position: absolute;
        top: 0.08rem;
        left: 1.12rem;
        line-height: 0.23rem;
        letter-spacing: 0.03rem;
        font-family: MicrosoftYaHei;
        font-size: 0.28rem;
        color: rgb(0,0,0);
    }
    #cLeft2>.lThree2{
        width: 0.66rem;
        height: 0.4rem;
        background: rgb(255,203,63);
        border-radius: 0.04rem;
        position: absolute;
        top: 0;
        left: 3.39rem;
        text-align: center;
        line-height: 0.4rem;
        font-family: MicrosoftYaHei;
        font-size: 0.22rem;
        color: rgb(51,51,51);
    }
    #cLeft2>.lFour2{
        width: 6rem;
        height: 0.62rem;
        position: absolute;
        top: 0.58rem;
        left: 0.01rem;
        line-height: 0.32rem;
        font-family: MicrosoftYaHei;
        font-size: 0.22rem;
        color: rgb(102,102,102);
    }
    #cRight2{
        float: right;
        width: 0.27rem;
        height: 1.1rem;
        margin-top: 0.55rem;
        font-size: 0.3rem;
    }
    #foot{
        width: 100%;
        height: 0.77rem;
        position: fixed;
        left:0;
        bottom: 0;
    }
    #fCont{
        width: 100%;
        height: 100%;
        background: rgb(255,203,63);
        border-radius: 0.1rem;
        text-align: center;
        line-height: 0.77rem;
        font-family: MicrosoftYaHei-Bold;
        font-weight: bold;
        font-size: 0.28rem;
        color: rgb(255,255,255);
    }
    .toLeft img{
        width: 0.2rem;
        height: 0.3rem;
        margin-left: 0.1rem;
    }
    #cRight2 img{
        width: 0.1rem;
        height: 0.2rem;
    }
    .dTwo img{
        width: 0.1rem;
        height: 0.2rem;
    }
    #cRight img{
        width: 0.1rem;
        height: 0.2rem;
    }
    #cRight1 img{
        width: 0.1rem;
        height: 0.2rem;
    }

</style>