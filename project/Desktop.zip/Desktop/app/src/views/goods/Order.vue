<template>
    <div>
        <my-header>
            <img src="../../assets/image/cys/10.1.png" alt="" class="back" @click="$router.back()">
        </my-header>
        <div class="max">
            <div class="nav">
                <div class="nav-content">
                    <div class="nav-left"></div>
                    <div class="nav-center">订单确认</div>
                    <div class="nav-right"></div>
                </div>
            </div>
            <div class="shouhuo">
                <div class="s-content" v-if="address">
                    <img src="../../assets/image/ljq/7-2.png" alt="">
                    <div class="address">
                        <p class="s-text">收货地址</p>
                        <div class="cheng"></div>
                    </div>

                    <div class="zhu">
                        <div class="z-left" v-if="address.type">{{address.type}}</div>
                        <div class="z-text">{{address.province}}{{address.city}}{{address.area}}</div>
                    </div>
                    <div class="y">
                        <div class="y-text">{{address.address}}</div>
                        <div class="y-right">
                            <router-link to="/address">
                            <i class="iconfont icon-arrow-right"></i>
                            </router-link>
                        </div>
                    </div>
                    <div class="w">
                        <div class="w-text">{{address.name}} {{address.phone}}</div>
                    </div>
                </div>
                <div v-else class="add">
                    <router-link to="/peraddress">添加收货地址<i class="iconfont icon-arrow-right"></i></router-link>
                </div>
            </div>
            <div class="queren">
                <div class="q-content">
                    <div class="q-text">
                        <p class="s-text">订单确认</p>
                        <div class="cheng"></div>
                    </div>
                    <div class="q-img" v-for="item in payList">
                        <div class="q-left">
                            <img :src="item.thumb" alt="">
                        </div>
                        <div class="q-right">
                            <div class="text1">
                                <p class="font">{{item.name_en}}</p>
                                <p>{{item.name_ch}}</p>
                                <p class="font2">{{item.size}}</p>
                            </div>
                            <div class="text2">
                                <p class="font3">{{item.goods_price}}</p>
                                <p class="font4">RMB</p>
                            </div>
                            <div class="two">X{{item.number}}</div>
                            <div class="have">有货</div>
                        </div>
                    </div>
                    <div class="total">
                        <div class="t-text">商品总价</div>
                        <div class="t-text2">{{totalPrice}}<p>RMB</p></div>
                    </div>
                    <div class="total2">
                        <div class="t-text">备注</div>
                        <div class="t-text3"><textarea placeholder="限45个字（请将购买需求在备注中做详细说明)" class="note" v-model="note"></textarea>
                        </div>
                    </div>
                </div>
            </div>
            <div class="fapiao">
                <div class="f-content">
                    <div class="total3">
                        <div class="t-text4">发票信息</div>
                        <div class="cheng2"></div>
                    </div>
                    <div class="total4">
                        <div class="t-text4">不开发票</div>
                    </div>
                </div>
            </div>
            <div class="foot">
                <div class="foot-content">
                    <div class="foot-left">
                        <span class="zi">付款</span>
                        <span style="color: rgb(255,203,63);font-weight: bold">{{totalPrice}}</span><span
                            style="font-size: 0.18rem">RMB</span>
                    </div>
                    <div class="foot-right">
                        <p @click="pay">去支付</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
    import Header from "@/components/Header";
    import {mapGetters} from "vuex";
    export default {
        name: "Order",
        data: () => ({
            address: null,
            note:""
        }),
        computed: {
            ...mapGetters(['payList']),
            totalPrice() {
                let total = 0;
                this.payList.forEach(v => {
                    total += v.price;
                });
                return total;
            }
        },
        components: {
            "my-header": Header,
        },
        methods: {
            fetchUserAddress() {
                this.$http.get("/api/address/address", {
                    params: {
                        uid: localStorage.login,
                        is_default: 1
                    }
                }).then(res => {
                    if (res.data.code === 200) {
                        this.address = res.data.data;
                        if (this.address.type) {
                            switch (this.address.type) {
                                case 1:
                                    this.address.type = "住宅";
                                    break;
                                case 2:
                                    this.address.type = "公司";
                                    break;
                                case 3:
                                    this.address.type = "学校";
                                    break;
                            }
                        }
                    }
                }).catch(() => {
                    console.log("获取用户地址失败");
                })
            },
            pay(){
                this.payList.forEach(v=>{
                    v.aid=this.address.id;
                    v.note=this.note;
                });
                this.$router.push("/pay");
            }
        },
        mounted: function () {
            if(localStorage.address){
                this.address=JSON.parse(localStorage.address);
                localStorage.removeItem("address");
            }else{
                this.fetchUserAddress();
            }
        }
    }
</script>

<style lang="scss" scoped>
    .add {
        width: 100%;
        height: 1rem;
        text-align: right;
        line-height: 1rem;
        font-size: 18px;
        text-decoration: underline;
    }

    .note {
        width: 100%;
        height: 0.7rem;
        border: 1px solid #ccc;
    }

    .max {
        width: 100%;
        height: auto;
        /*background: lime;*/
    }

    .nav {
        width: 100%;
        height: 0.88rem;
        /*background: lightcoral;*/
        position: relative;

        /*padding-left: 0.24rem;*/
        /*padding-right: 0.24rem;*/
    }

    .nav-content {
        padding-left: 0.24rem;
        padding-right: 0.24rem;
        width: 7.5rem;
        height: 0.88rem;
        background: rgb(255, 255, 255);
        margin: 0 auto;
        border-bottom: 1px solid rgb(238, 238, 238);
    }

    .nav-left {
        width: 0.15rem;
        height: 0.24rem;
        /*background: crimson;*/
        float: left;
        margin-left: 0.24rem;
        margin-top: 0.27rem;
    }

    /*.nav-left img{*/
    /*width: 0.15rem;*/
    /*height: 0.24rem;*/
    /*}*/
    .nav-center {
        width: 1.14rem;
        height: 0.28rem;
        color: rgb(0, 0, 0);
        /*background: lightgreen;*/
        float: left;
        text-align: center;
        line-height: 0.78rem;
        margin-left: 2.5rem;
        font-size: 0.28rem;
        font-family: MicrosoftYaHei;
    }

    .nav-right {
        float: left;
        width: 0.36rem;
        height: 0.08rem;
        margin-left: 2.2rem;
        margin-top: 0.27rem;
    }

    .shouhuo {
        width: 100%;
        /*background: lightcoral;*/
        padding-left: 0.24rem;
        padding-right: 0.24rem;
    }

    .s-content {
        margin: 0 auto;
        width: 7.03rem;
        height: 2.23rem;
        /*background: lightgreen;*/
        position: relative;
    }

    .s-content img {
        width: 7.03rem;
        height: 2.23rem;
    }

    .address {
        width: 6.39rem;
        height: 0.48rem;
        /*background: blueviolet;*/
        position: absolute;
        top: 0.27rem;
        left: 0.3rem;
        border-bottom: 1px solid rgb(242, 242, 242);
    }

    .s-text {
        width: 1.19rem;
        height: 0.28rem;
        font-size: 0.28rem;
        line-height: 0.36rem;
    }

    .cheng {
        width: 0.47rem;
        height: 0.02rem;
        background: rgb(255, 203, 63);
        margin-top: 0.18rem;
    }

    .zhu {
        width: 6.39rem;
        height: 0.33rem;
        /*background:lawngreen;*/
        position: absolute;
        top: 0.91rem;
        left: 0.3rem;
        /*border-bottom: 1px solid rgb(242,242,242);*/
    }

    .zhu .z-left {
        float: left;
        width: 0.55rem;
        height: 0.33rem;
        background: rgb(255, 203, 63);
        border-radius: 0.04rem;
        font-size: 0.18rem;
        line-height: 0.36rem;
        color: rgb(255, 255, 255);
        text-align: center;
        margin-right: 0.15rem;
        display: inline-block;
    }

    .zhu .z-text {
        float: left;
        width: 2.5rem;
        height: 0.22rem;
        font-size: 0.22rem;
        line-height: 0.36rem;
        display: inline-block;
        letter-spacing: 0.02rem;
    }

    .y {
        width: 6.39rem;
        height: 0.24rem;
        /*background: lightcoral;*/
        position: absolute;
        top: 1.27rem;
        left: 0.3rem;
    }

    .y-text {
        width: 2.8rem;
        height: 0.24rem;
        /*background: lightsalmon;*/
        float: left;
        font-size: 0.24rem;
        line-height: 0.36rem;
        font-weight: bold;
        letter-spacing: 0.02rem;
    }

    .y-right i {
        float: right;
        color: rgba(0, 0, 0, 0.7);
    }

    .w {
        width: 6.39rem;
        height: 0.24rem;
        /*background: gold;*/
        position: absolute;
        top: 1.6rem;
        left: 0.3rem;
    }

    .w-text {
        width: 2.29rem;
        height: 0.22rem;
        /*background: lightsalmon;*/
        float: left;
        font-size: 0.22rem;
        line-height: 0.36rem;
    }

    .queren {
        width: 100%;
        height: 4.87rem;
        /*background: magenta;*/
        padding-left: 0.24rem;
        padding-right: 0.24rem;
        margin-top: 0.31rem;
        float: left;
    }

    .q-content {
        width: 7.02rem;
        background: rgb(255, 255, 255);
        box-shadow: -1px 5px 5px 0 rgba(118, 118, 118, 0.17);
        border-radius: 0.1rem;
        margin: 0 auto;
    }

    .q-text {
        float: left;
        width: 6.39rem;
        height: 0.48rem;
        /*background: blueviolet;*/
        border-bottom: 1px solid rgb(242, 242, 242);
        margin-left: 0.28rem;
        margin-top: 0.31rem;
    }

    .s-text {
        width: 1.19rem;
        height: 0.28rem;
        font-size: 0.28rem;
        line-height: 0.36rem;
    }

    .cheng {
        width: 0.47rem;
        height: 0.02rem;
        background: rgb(255, 203, 63);
        margin-top: 0.18rem;
    }

    .q-img {
        float: left;
        width: 6.39rem;
        height: 0.85rem;
        /*background:orangered;*/
        /*border-bottom: 1px solid rgb(242,242,242);*/
        margin-left: 0.32rem;
        margin-top: 0.43rem;
    }

    .q-left {
        width: 1.02rem;
        height: 0.85rem;
        /*background: lightseagreen;*/
        float: left;
    }

    .q-left img {
        width: 1.02rem;
        height: 0.85rem;
    }

    .q-right {
        width: 5.23rem;
        height: 0.85rem;
        /*background: mediumblue;*/
        float: left;
        margin-left: 0.11rem;
    }

    .text1 {
        width: 1.56rem;
        height: 0.85rem;
        /*background: forestgreen;*/
        float: left;
    }

    .font {
        font-size: 0.18rem;
        line-height: 0.25rem;
        font-family: MicrosoftYaHeiLight;
    }

    .font2 {
        font-size: 0.18rem;
        line-height: 0.18rem;
    }

    .text2 {
        float: left;
        width: 1rem;
        height: 0.21rem;
        /*background: red;*/
        margin-left: 0.6rem;
        margin-top: 0.29rem;
    }

    .font3 {
        display: inline-block;
        font-size: 0.26rem;
        line-height: 0.36rem;
        font-weight: bold;
    }

    .font4 {
        display: inline-block;
        font-size: 0.18rem;
        line-height: 0.36rem;
    }

    .two {
        width: 0.31rem;
        height: 0.19rem;
        /*background: lightcoral;*/
        float: left;
        margin-left: 0.58rem;
        margin-top: 0.29rem;
        font-size: 0.24rem;
        line-height: 0.36rem;
    }

    .have {
        width: 0.5rem;
        height: 0.24rem;
        /*background: lightcoral;*/
        float: left;
        margin-left: 0.58rem;
        margin-top: 0.29rem;
        font-size: 0.24rem;
        line-height: 0.36rem;
    }

    .total {
        float: left;
        width: 6.43rem;
        height: 0.4rem;
        border-bottom: 1px solid rgb(217, 217, 217);
        margin-left: 0.32rem;
        margin-top: 0.4rem;
        /*background: lightseagreen;*/
    }

    .t-text {
        float: left;
        font-size: 0.24rem;
        line-height: 0.36rem;
    }

    .t-text2 {
        float: right;
        font-size: 0.24rem;
        line-height: 0.36rem;
        letter-spacing: 0.02rem;
    }

    .t-text2 p {
        float: right;
        font-size: 0.18rem;
        line-height: 0.36rem;
        margin-top: 0.03rem;
        letter-spacing: 0.02rem;
    }

    .total2 {
        float: left;
        width: 6.43rem;
        height: 1rem;
        margin-left: 0.32rem;
        margin-top: 0.4rem;
        background: white;
    }

    .t-text3 {
        float: left;
        width: 5.25rem;
        height: 0.8rem;
        font-size: 0.18rem;
        line-height: 0.36rem;
        margin-top: -0.03rem;
        letter-spacing: 0.02rem;
        margin-left: 0.34rem;
    }

    .fapiao {
        float: left;
        width: 100%;
        height: 1.96rem;
        /*background: lightcoral;*/
        margin-top: 0.34rem;
        padding-left: 0.24rem;
        padding-right: 0.24rem;
    }

    .f-content {
        width: 7.02rem;
        height: 1.96rem;
        background: rgb(255, 255, 255);
        box-shadow: -1px 5px 5px 0 rgba(118, 118, 118, 0.17);
        border-radius: 0.1rem;
        margin: 0 auto;
    }

    .cheng2 {
        width: 0.47rem;
        height: 0.03rem;
        background: rgb(255, 203, 63);
        margin-top: 0.47rem;
    }

    .total3 {
        float: left;
        width: 6.43rem;
        height: 0.51rem;
        border-bottom: 1px solid rgb(217, 217, 217);
        margin-left: 0.32rem;
        margin-top: 0.4rem;
        /*background: lightseagreen;*/
    }

    .t-text4 {
        float: left;
        font-size: 0.28rem;
        line-height: 0.36rem;
    }

    .total4 {
        float: left;
        width: 6.43rem;
        height: 0.51rem;
        margin-left: 0.32rem;
        margin-top: 0.25rem;
        /*background: lightseagreen;*/
    }

    .foot {
        float: left;
        width: 100%;
        height: 0.9rem;
        /*background: lightgreen;*/
        margin-top: 0.17rem;
        position: absolute;
        bottom: 0;
        /*padding-left: 0.24rem;*/
        /*padding-right: 0.24rem;*/

    }

    .foot-content {
        width: 7.5rem;
        height: 0.9rem;
        /*background: chocolate;*/
        margin: 0 auto;
        border-top: 1px solid rgb(229, 229, 229);
        padding-left: 0.24rem;

    }

    .foot-left {
        float: left;
        width: 2.5rem;
        height: 0.24rem;
        /*background: lightcoral;*/
        margin-top: 0.33rem;

    }

    .foot-left span {
        font-size: 0.28rem;
        line-height: 0.36rem;
        text-align: center;
    }

    .zi {
        font-size: 0.28rem;
        line-height: 0.36rem;
        text-align: center;
    }

    .foot-right {
        width: 2.12rem;
        height: 0.9rem;
        background: rgb(255, 203, 63);
        float: right;
        border-radius: 0.04rem;
        box-shadow: 0 2px 7px 0 rgba(224, 163, 0, 0.45);
    }

    .foot-right p {
        /*width: 0.9rem;*/
        /*height: 0.28rem;*/
        font-size: 0.28rem;
        line-height: 0.9rem;
        color: white;
        font-weight: bold;
        text-align: center;
    }


</style>