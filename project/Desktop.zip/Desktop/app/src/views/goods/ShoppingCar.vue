<template>
    <div style="height:100%;">
        <my-header></my-header>
        <div class="wrapper" ref="wrapper">
            <div class="inner">
                <ul class="product" v-if="cartLength>0">
                    <li class="list" v-for="item in cartList">
                        <div :class="['round',{active:item.checked}]" @click="item.checked=!item.checked">
                            <div class="round-small" v-show="item.checked"></div>
                        </div>
                        <div class="Commodity-images"><img :src="item.thumb" alt=""></div>
                        <div class="description"><p class="one">{{item.name_en}}</p>
                            <p class="two">{{item.name_ch}}</p>
                            <p class="three">{{item.size}}</p></div>
                        <div class="price"><span class="one">{{item.goods_price}}</span><span class="two">RMB</span>
                        </div>
                        <ul class="add">
                            <li style="cursor: pointer" @click="dec(item)">-</li>
                            <li class="number" style="border: none;width:0.46rem;cursor: pointer">{{item.number}}</li>
                            <li class="plus" style="border: 0.01rem solid orange;cursor: pointer" @click="plus(item)">
                                +
                            </li>
                        </ul>
                    </li>
                </ul>
                <div v-else class="empty">
                    还没有选择任何商品
                </div>
                <my-recommend :goods="this.goods"></my-recommend>
            </div>
        </div>
        <div class="close">
            <div :class="['round','checked',{active:checkAll}]" @click="handleCheckAll">
                <div class="round-small" v-show="checkAll"></div>
            </div>
            <span class="notice">{{checkAll?'取消全选':'全选'}}</span>
            <span style="font-size: 0.24rem">合计：</span><span
                style="font-size: 0.26rem;color: orange">{{totalPrice}}</span><span style="font-size: 0.18rem">RMB</span>
            <span style="font-size: 0.16rem;color: #ccc;margin-left: 1.6rem">免邮</span>
            <router-link to="/order" v-if="totalPrice>0"><input type="button" value="去结算" class="go"></router-link>
            <div v-else class="go2"></div>
        </div>
        <my-footer hot="shoppingcar"></my-footer>
    </div>
</template>

<script>
    import Header from "@/components/Header";
    import Footer from "@/components/Footer";
    import Recommend from "@/components/Recommend";
    import BScroll from "better-scroll";
    import {mapGetters, mapMutations} from "vuex";
    export default {
        name: "ShoppingCar",
        data: () => ({
            goods: [],
            total: 0,
            page: 1,
            checkAll: false
        }),
        computed: {
            ...mapGetters(['cartList', 'cartLength']),
            totalPrice:function () {
             let total=0;
             this.cartList.filter(v=>v.checked).forEach(v=>{
                total+=v.goods_price*v.number;
             });
             return total;
            }
        },
        methods: {
            ...mapMutations(['add', 'remove','concat']),
            fetchGoodsData: function () {
                this.$http.get("/api/goods/goods", {
                    params: {
                        page: this.page,
                        pageSize: 8
                    }
                }).then(res => {
                    if (res.data.code === 200) {
                        this.goods = [...this.goods, ...res.data.data];
                        this.total = res.data.total;

                        if (!this.scroll) {
                            this.$nextTick(() => {
                                this.scroll = new BScroll(this.$refs.wrapper, {
                                    pullUpLoad: {
                                        threshold: 0
                                    },
                                    click: true,
                                    preventDefault: false
                                });
                                this.scroll.on("pullingUp", () => {
                                    if (this.page * 8 > this.total) {
                                        this.scroll.finishPullUp();
                                        return;
                                    }
                                    this.page++;
                                    this.fetchGoodsData();
                                    this.scroll.finishPullUp();
                                });
                            })
                        } else {
                            this.scroll.refresh();
                        }
                    }
                }).catch(() => {
                    console.log("获取商品失败");
                })
            },
            plus: function (obj) {
                obj.number++;
            },
            dec: function (obj) {
                obj.number--;
                if (obj.number === 0) {
                    this.remove({id: obj.gid})
                }
            },
            handleCheckAll: function () {
                this.checkAll = !this.checkAll;
                if (this.checkAll) {
                    this.cartList.forEach(v => {
                        v.checked = true;
                    })
                } else {
                    this.cartList.forEach(v => {
                        v.checked = false;
                    })
                }
            },
            fetchOrderList:function(){
                this.$http.get("/api/orders/orders",{
                    params:{
                        uid:localStorage.login
                    }
                }).then(res=>{
                    if(res.data.code===200){
                      let orderList=res.data.data;
                      orderList.forEach(v=>{
                          v.checked=false;
                      });
                      this.concat(orderList);
                    }else{
                        console.log("获取失败");
                    }
                }).catch(()=>{
                    console.log("获取失败");
                })
            }
        },
        components: {
            "my-header": Header,
            "my-footer": Footer,
            "my-recommend": Recommend
        },
        beforeRouteLeave: function (to, from, next) {
            this.cartList.forEach(v => {
                if(to.name!=="order"){
                    v.checked = false;
                }
                v.price= v.number*v.goods_price;
                delete v.id;
            });
            this.$http.post("/api/orders/addOrder",{
               data:this.cartList,
               uid:localStorage.login
            }).then(res=>{
                if(res.data.code===200){
                    console.log("同步成功");
                }else{
                    console.log("同步失败");
                }
            }).catch(()=>{
                console.log("提交失败");
            });
            next();
        },
        mounted: function () {
            this.fetchGoodsData();
            if (localStorage.goods) {
                let obj = JSON.parse(localStorage.goods);
                obj.uid = localStorage.login;
                this.add(obj);
                localStorage.removeItem("goods");
            }
            this.fetchOrderList();
        }
    }
</script>

<style lang="scss" scoped>
    .notice{
        width:1rem;
    }
    .empty {
        width: 100%;
        height: 3rem;
        text-align: center;
        line-height: 3rem;
        color: #ccc;
        font-size: 16px;
    }

    .wrapper {
        width: 100%;
        height: calc(100% - 1.88rem);
        overflow: hidden;
        position: relative;
    }

    .head-two {
        width: 0.92rem;
        height: 0.3rem;
    }

    .head-two img {
        width: 0.92rem;
        height: 0.3rem;
    }

    .head-three {
        width: 0.36rem;
        height: 0.08rem;
        display: flex;
        justify-content: space-around;
    }

    .head-three > div {
        width: 0.08rem;
        height: 0.08rem;
        border-radius: 50%;
        background: #222222;
    }

    .product {
        width: 100%;
        border-top: 0.02rem solid orange;
        display: flex;
        flex-direction: column;
    }

    .list {
        width: 100%;
        height: 2rem;
        padding: 0.45rem 0.36rem;
        background: #ffffff;
        border-bottom: 0.01rem solid black;
        position: relative;
        display: flex;
        justify-content: space-around;
        align-items: center;
    }

    .list.active {
        box-shadow: 0 0 0.1rem #000;
    }

    .round {
        width: 0.18rem;
        height: 0.18rem;
        border: solid 0.01rem #a0a0a0;
        border-radius: 50%;
        position: absolute;
        left: 0.12rem;
    }

    .round.active {
        border: 0.01rem solid orange;
    }

    .round-small {
        width: 0.1rem;
        height: 0.1rem;
        background-color: #ffcb3f;
        border-radius: 50%;
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        margin: auto;
    }

    .Commodity-images {
        width: 1.5rem;
        height: 1.2rem;
    }

    .Commodity-images img {
        width: 1.5rem;
        height: 1.2rem;
    }

    .description {
        width: 2rem;
        height: 1.1rem;
        line-height: 0.3rem;
    }

    .description .one {
        font-size: 0.16rem;
        letter-spacing: 0.01rem;
        color: #000000;
    }

    .description .two {
        font-size: 0.18rem;
        letter-spacing: 0.02rem;
        color: #000000;
    }

    .description .three {
        font-size: 0.16rem;
        letter-spacing: 0.02rem;
        color: #000000;
        margin-top: 0.16rem;
    }

    .price {
        width: 1.5rem;
    }

    .price .one {
        font-size: 0.18rem;
        line-height: 0.36rem;
        letter-spacing: 0.02rem;
        color: #000000;
    }

    .add {
        height: 0.22rem;
        display: flex;
        justify-content: space-between;
        margin-right: 0.4rem;
    }

    .add > li {
        width: 0.22rem;
        height: 0.22rem;
        border: black solid 0.01rem;
        float: left;
        text-align: center;
        line-height: 0.22rem;
    }

    .number {
        width: 0.46rem;
        border: none;
        font-size: 0.18rem;
        font-weight: normal;
        font-stretch: normal;
        line-height: 0.36rem;
        letter-spacing: 0.02rem;
        color: #000000;
    }

    .plus {
        border: 0.01rem solid orange;
    }

    .money {
        width: 0.75rem;
        height: 0.15rem;
    }

    .del {
        width: 0.67rem;
        height: 0.24rem;
        font-family: iconfont;
        display: flex;
        justify-content: space-between;
        text-align: center;
        line-height: 0.24rem;
    }

    .del .icon {
        color: orange;
    }

    .list-one {
        width: 12.20rem;
        height: 1.90rem;
        background: #ffffff;
        border-bottom: 0.01rem solid black;
        position: relative;
        font-family: iconfont;
    }

    .check {
        float: left;
        margin-left: 0.3rem;
    }

    .iconfont {
        float: left;
        margin-left: 0.3rem;
    }

    .total-goods {
        width: 1.5rem;
        height: auto;
        margin-top: 1.4rem;
        margin-left: 0.32rem;
        float: left;
    }

    .total-price {
        float: right;
        display: inline-block;
        margin-top: 1.4rem;
        margin-right: 2.3rem;
    }

    .expurgate {
        width: auto;
        height: 0.2rem;
        position: absolute;
        top: 50%;
        left: 0.6rem;
    }

    .pay {
        width: 1.6rem;
        height: 0.54rem;
        background-color: #ffcb3f;
        box-shadow: -1px 7px 13px 0 rgba(224, 163, 0, 0.59);
        border-radius: 10px;
        text-align: center;
        line-height: 0.54rem;
        float: right;
        margin-top: 1.27rem;
        margin-right: -3.33rem;
    }

    .hot-one {
        width: 1.5rem;
        height: auto;
        border-left: 0.01rem solid orange;
        text-align: center;
        margin-top: 0.47rem;
    }

    #commodity {
        width: 100%;
        height: auto;
        background: #f6f6f6;
        display: flex;
        justify-content: space-around;
        flex-wrap: wrap;
        margin-top: 0.2rem;
    }

    .commodity-title {
        width: 3.3rem;
        height: 5.09rem;
        background-color: white;
        margin-bottom: 0.2rem;
    }

    .img {
        width: 3.3rem;
        height: 3.18rem;
    }

    .img img {
        width: 3.3rem;
        height: 3.18rem;
    }

    .wire {
        width: 0.32rem;
        height: 0.03rem;
        background-color: #000000;
        margin-left: 0.23rem;
        margin-top: 0.24rem;
    }

    .verfo-lab {
        width: 2.4rem;
        height: 0.46rem;
        font-size: 0.18rem;
        line-height: 0.46rem;
        color: #000000;
        margin-top: 0.1rem;
        margin-left: 0.2rem;
    }

    .buy {
        width: auto;
        height: 0.44rem;
        line-height: 0.44rem;
        text-align: center;
        float: left;
    }

    .add-one {
        width: 1.53rem;
        height: 0.44rem;
        background-color: #ffcb3f;
        border-radius: 0.04rem;
        float: right;
        padding: 0 0.10rem;
        line-height: 0.44rem;
        font-family: iconfont;
    }

    .add-one span {
        margin-left: 0.1rem;
    }

    .commodity-bottom {
        width: 100%;
        height: 0.44rem;
        padding: 0 .22rem;
        margin-top: 0.45rem;
    }

    .close {
        width: 100%;
        height: 0.9rem;
        background-color: #ffffff;
        border: solid 0.01rem #e5e5e5;
        padding-left: 0.42rem;
        position: fixed;
        left: 0;
        bottom: 0.98rem;
        display: flex;
        justify-content: space-between;
        align-items: center;
    }

    .close .go {
        width: 2.12rem;
        height: 0.89rem;
        background-color: #ffcb3f;
        border-radius: 0.04rem;
        float: right;
        display: inline-block;
        border:none;
    }
    .go2{
        width: 2.12rem;
        height: 0.89rem;
        float: right;
        display: inline-block;
    }

    .selected {
        width: 0.23rem;
        height: 0.23rem;
        border-radius: 50%;
        border: 0.01rem solid orange;
        display: inline-block;
        line-height: 0.23rem;
    }
</style>