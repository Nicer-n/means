<template>
    <div style="height:100%;">
        <my-header>
            <img src="../../assets/image/cys/10.1.png" alt="" class="back" @click="$router.back()">
        </my-header>
        <div class="container" ref="wrapper">
            <div class="inner">
                <div id="search">
                    <div class="search-left">
                        <input type="text" placeholder="布艺沙发" v-model="search" v-f>
                        <i class="iconfont icon-search"></i>
                    </div>
                    <div class="search-text">
                        <router-link :to="{name:'resultlist',query:{search}}">搜索</router-link>
                    </div>
                </div>
                <!--search-->
                <div class="title">
                    <div class="text">
                        <div class="hot">
                            搜索历史
                        </div>
                        <div
                                class="shop"
                                v-for="item in history"
                                @click="jump(item)"
                                :key="item"
                        >{{item}}
                        </div>
                        <div class="clear" @click="clear">清空搜索历史</div>
                    </div>
                </div>
                <my-recommend :goods="this.goods"></my-recommend>
                </div>
        </div>
    </div>
</template>

<script>
    import Header from "@/components/Header";
    import Recommend from "@/components/Recommend";
    import BScroll from "better-scroll";
    export default {
        name: "Search",
        data: () => ({
            search: "",
            history: [],
            goods:[],
            page:1,
            total:0
        }),
        components: {
            "my-header": Header,
            "my-recommend": Recommend
        },
        methods: {
            clear: function () {
                this.history = [];
                localStorage.removeItem("history");
            },
            jump: function (item) {
                this.search = item;
                this.$router.push({name: 'resultlist', query: {search: item}});
            },
            fetchGoodsData: function () {
                this.$http.get("/api/goods/goods", {
                    params: {
                        page: this.page,
                        pageSize: 8
                    }
                }).then(res => {
                    if (res.data.code === 200) {
                        this.goods = [...this.goods, ...res.data.data];
                        this.total = res.data.total;
                        if (!this.scroll) {
                            this.$nextTick(() => {
                                this.scroll = new BScroll(this.$refs.wrapper, {
                                    pullUpLoad: {
                                        threshold: 0
                                    },
                                    click: true,
                                    preventDefault: false
                                });
                                this.scroll.on("pullingUp", () => {
                                    if(this.page*8>this.total){
                                        this.scroll.finishPullUp();
                                        return;
                                    }
                                    this.page++;
                                    this.fetchGoodsData();
                                    this.scroll.finishPullUp();
                                });
                            })
                        } else {
                            this.scroll.refresh();
                        }
                    }
                }).catch(() => {
                    console.log("获取商品失败");
                })
            }
        },
        beforeRouteLeave(to, from, next) {
            // 导航离开该组件的对应路由时调用
            // 可以访问组件实例 `this`
            // indexOf -1  splice
            if (to.name !== "resultlist") {
                next();
                return;
            }
            if (this.search === "") {
                next("/search");
                return;
            }
            let index = this.history.indexOf(this.search);
            if (index !== -1) {
                this.history.splice(index, 1);
            }
            this.history.unshift(this.search);
            if (this.history.length > 10) {
                this.history = this.history.slice(0, 10);
                this.history.push("...");
            }
            localStorage.setItem("history", JSON.stringify(this.history));
            next();
        },
        mounted: function () {
            if (localStorage.history) {
                this.history = JSON.parse(localStorage.history);  //字符串
            }
            this.fetchGoodsData();
        },
        directives:{
            "f":{
                inserted:function(el){
                    el.focus();
                }
            },
            "color":{
                bind:function(el,binding){
                   el.style.background=binding.value;
                }
            }
        }
    }
</script>
<style lang="scss" scoped>
    .container {
        width: 100%;
        height: 100%;
        overflow: hidden;
        position: relative;
    }

    .inner {
        width: 100%;
        height: auto;
    }
    .shop {
        width: 1.49rem;
        height: 0.6rem;
        background-color: #efefef;
        border-radius: 0.3rem;
        display: inline-block;
        text-align: center;
        line-height: 0.6rem;
        margin: 0.2rem;
    }

    .clear {
        width: 100%;
        height: 0.6rem;
        line-height: 0.6rem;
        color: #4a87ff;
        text-align: center;
    }

    #head {
        width: 100%;
        height: 0.88rem;
        background-color: #ffffff;
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 0 0.12rem;
    }

    .head-one {
        width: 0.28rem;
        height: 0.3rem;
        text-align: center;
        line-height: 0.3rem;
        font-family: iconfont;
    }

    .head-two {
        width: 0.92rem;
        height: 0.3rem;
    }

    .head-two img {
        width: 0.92rem;
        height: 0.3rem;
    }

    .head-three {
        width: 0.36rem;
        height: 0.08rem;
        display: flex;
        justify-content: space-around;
    }

    .head-three > div {
        width: 0.08rem;
        height: 0.08rem;
        border-radius: 50%;
        background: #222222;
    }

    #search {
        width: 100%;
        height: 0.78rem;
        background-color: #ffffff;
        padding: 0 0.33rem;
        display: flex;
        align-items: center;
        justify-content: space-around;
    }

    .search-left {
        width: 6rem;
        height: 0.6rem;
        border-radius: 0.3rem;
        border: solid 0.01rem #d9d9d9;
        opacity: 0.6;
        float: left;
        text-align: right;
        line-height: 0.6rem;
        padding-right: 0.2rem;
        position: relative;
    }

    .search-left > input {
        width: 6.04rem;
        height: 0.6rem;
        line-height: 0.6rem;
        border-radius: 0.3rem;
        border: 0.01rem solid #ccc;
        outline: none;
        padding-left: 0.56rem;
    }

    .search-left > .iconfont {
        position: absolute;
        left: 0.19rem;
        top: 0;
        font-size: 0.24rem;
    }

    .search-top {
        font-family: iconfont;
        width: 0.24rem;
        height: 0.25rem;
        text-align: center;
        line-height: 0.25rem;
        font-size: 26px;
        float: left;
        margin-top: 0.175rem;
        margin-left: 0.1rem;
    }

    .search-text {
        width: auto;
        height: 0.78rem;
        line-height: 0.78rem;
    }

    .search-text a {
        font-size: 0.24rem;
        font-weight: normal;
        font-stretch: normal;
        letter-spacing: 0.01rem;
        color: #000000;
    }

    .title {
        width: 100%;
        height: auto;
        background: #f8f8f8;
        background-clip: border-box;
        padding: 0.6rem 0.24rem;
    }

    .text {
        width: 6.92rem;
        height: auto;
    }


</style>