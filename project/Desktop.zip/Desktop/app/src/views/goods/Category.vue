<template>
    <div>
        <my-header></my-header>
        <div id="search">
            <router-link to="/search" class="search-box">
                <div class="search-box-left">
                    <input type="text" placeholder="搜索店内精品">
                    <i class="iconfont icon-search"></i>
                </div>
                <div class="search-box-right">搜索</div>
            </router-link>
        </div>
        <!--search-->
        <div id="content">
            <div class="content-box">
                <div class="content-box-left">
                    <div class="content-left-row" @click="changeCategory(0)">
                        <div :class="['content-left-wipper',{active:activeCategory===0}]"></div>
                        全部宝贝
                    </div>
                    <div class="content-left-row active" v-for="item in categories" :key="item.id" @click="changeCategory(item.id)">
                        <div :class="['content-left-wipper',{active:activeCategory===item.id}]"></div>
                        {{item.category}}
                    </div>
                </div>
                <div class="content-box-right">
                    <div class="banner">
                        <ul class="banner-box">
                            <li>
                                <img :src="categoryImage" alt="" v-if="activeCategory!==0">
                                <img src="../../assets/image/chy/5.1.png" alt=""  v-else>
                            </li>
                        </ul>
                    </div>
                    <div class="new-box">
                        <div class="new-box-title">
                            <span class="new-title-left"></span>
                           {{activeCategory===0?'全部宝贝':categoryName}}
                            <span class="new-title-right"></span>
                        </div>
                        <div class="new-product" ref="wrapper">
                            <div class="new-product-row" ref="con">
                                <router-link class="product-row-box" v-for="item in goods" :to="{path:'/content',query:{id:item.id}}">
                                    <div class="product-row-img"><img :src="item.thumb" alt=""></div>
                                    <div class="product-row-title">{{item.name_ch}}</div>
                                    <div class="product-row-title">{{item.name_en}}</div>
                                    <div class="product-row-title">¥{{item.price}}</div>
                                    <div class="product-row-title">{{item.tags}}</div>
                                </router-link>
                                <div class="loading-wrapper" v-if="showMore">下拉加载更多\(^o^)/~</div>
                                <div class="loading-wrapper" v-else>没有商品啦！！！</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <my-footer hot="category"></my-footer>
    </div>
</template>

<script>
    import Header from "@/components/Header";
    import Footer from "@/components/Footer";
    import BScroll from 'better-scroll'
    export default {
        name: "Category",
        data: () => ({
            categories:[],
            activeCategory:0,
            total:0,
            page:1,
            goods:[],
            showMore:true
        }),
        //响应式的数据
        computed:{
           categoryImage:function(){
              return this.categories.find(v=>v.id===this.activeCategory).thumb;
           },
           categoryName:function(){
                return this.categories.find(v=>v.id===this.activeCategory).category;
           }
        },
        components: {
            "my-header": Header,
            "my-footer":Footer,
        },
        methods:{
            fetchCategoryData:function(){
              this.$http.get("/api/type/type").then(res=>{
                this.categories=res.data.data;
              }).catch(()=>{
                console.log("获取失败")
              })
            },
            changeCategory:function(id){
              this.activeCategory=id;
              this.page=1;
              this.goods=[];
              this.showMore=true;
              this.fetchGoodsData();
            },
            fetchGoodsData:function(){
                let params={
                    pageSize:12,
                    page:this.page
                };
                if(this.activeCategory!==0){
                    params.type=this.activeCategory;
                }
                this.$http.get("/api/goods/goods",{
                    params
                }).then(res=>{
                   if(res.data.code===200){
                       this.goods=[...this.goods,...res.data.data];
                       //concat a[1,2,3]  b[4,5,6]  a.concat(b) [1,2,3,4,5,6]
                       // 扩展运算符
                       // a [1,2,3]  b [4,5,6]  [...a,...b]
                       this.total=res.data.total;
                       if(!this.scroll){
                           //组件渲染完成
                           //保证当前网页已经渲染完成
                         this.$nextTick(()=>{

                           this.scroll = new BScroll(this.$refs.wrapper,{
                               //向下滚动超出多少像素时会触发上拉加载效果
                               pullUpLoad: {
                                   threshold:-50
                               },
                               //允许触发点击效果
                               click:true
                           });
                           this.scroll.on('pullingUp',()=>{
                               if(this.page*12>this.total){
                                 this.showMore=false;
                                 this.scroll.finishPullUp();
                                 return;
                               }
                               this.page++;
                               this.fetchGoodsData();
                               this.scroll.finishPullUp();
                           })
                       })
                       }else{
                         this.scroll.refresh();
                       }
                   }else{
                       console.log("获取失败");
                   }
                }).catch(()=>{
                    console.log("获取失败");
                })
            }
        },
        mounted:function(){
            this.fetchCategoryData();
            this.fetchGoodsData();
            // let obj={};
            // let arr=[]
            // let v;
            // function fn(){}
            // console.log(v);//undefined
            // console.log(obj.name); //undefined
            // console.log(arr[10]);//undefined
            // console.log(fn())//undefined
            // 0 "" NaN undefined false null
        }
    }
</script>
<style lang="scss" scoped>
    .loading-wrapper{
        width:100%;
        height:.5rem;
        font-size:16px;
        text-align: center;
        line-height:.5rem;
        color:#ccc;
        float:left;
    }
    #search {
        width: 100%;
        height: 0.74rem;
    }

    .search-box {
        width: 7.5rem;
        height: 0.6rem;
        margin: 0.14rem auto;
        display: block;
    }

    .search-box-left {
        width: 6.04rem;
        height: 0.6rem;
        float: left;
        margin-left: 0.33rem;
        position: relative;
    }

    .search-box-left > input {
        width: 6.04rem;
        height: 0.6rem;
        line-height: 0.6rem;
        border-radius: 0.3rem;
        border: 0.01rem solid #ccc;
        outline: none;
        padding-left: 0.56rem;
    }

    .search-box-left > .iconfont {
        position: absolute;
        top: 0.16rem;
        left: 0.19rem;
        font-size: 0.24rem;
    }

    .search-box-right {
        width: 0.5rem;
        height: 0.24rem;
        float: right;
        margin: 0.19rem 0.3rem 0 0.2rem;
        font-size: 0.24rem;
        letter-spacing: 0.01rem;
        color: #000000;
        line-height: 0.24rem;
        cursor: pointer;
    }

    /*search*/
    #content {
        width: 100%;
        height: 10.2rem;
    }

    .content-box {
        width: 7.5rem;
        height: 10.2rem;
    }

    .content-box-left {
        float: left;
        width: 2rem;
        height: 7.49rem;
    }

    .content-left-row {
        width: 2rem;
        height: 1.04rem;
        margin-bottom: 0.03rem;
        background-color: #f7f7f7;
        text-align: center;
        line-height: 1.04rem;
    }

    .content-left-row.active {
        background-color: #fcfcfc;
    }

    .content-left-wipper.active {
        width: 0.11rem;
        height: 1.04rem;
        background-color: #ffcb3f;
        float: left;
    }

    .content-box-right {
        float: left;
        width: 5.5rem;
        height: 10.2rem;
    }

    .banner {
        width: 5.04rem;
        height: 1.34rem;
        margin: 0 auto;
        position: relative;
    }

    .banner-box {
        width: 5.04rem;
        height: 1.34rem;
    }

    .banner-box > li > img {
        width: 5.04rem;
        height: 1.34rem;
    }

    .banner-page {
        width: 0.22rem;
        height: 0.05rem;
        display: flex;
        justify-content: space-between;
        position: absolute;
        bottom: 0.3rem;
        left: 2.3rem;
    }

    .banner-page > li {
        width: 0.04rem;
        height: 0.04rem;
        border-radius: 50%;
        border: 0.01rem solid #ccc;
    }

    .banner-page > li.active {
        background: #fff;
    }

    .new-box {
        width: 5.04rem;
        height: 8.17rem;
        margin: 0.6rem auto 0;
    }

    .new-box-title {
        width: 3.34rem;
        margin: 0 auto;
        text-align: center;
        line-height: 0.64rem;
        font-size: 0.32rem;
        letter-spacing: 0.02rem;
        color: #010101;
    }

    .new-title-left {
        float: left;
        width: 0.83rem;
        height: 0.01rem;
        background-color: #ffcb3f;
        margin-top: 0.19rem;
    }

    .new-title-right {
        float: right;
        width: 0.83rem;
        height: 0.01rem;
        background-color: #ffcb3f;
        margin-top: 0.19rem;
    }

    .new-product {
        width: 5.04rem;
        height: 7.85rem;
        overflow: scroll;
        position: relative;
    }
    .new-product-row{
        width: 5.04rem;
        height:auto;
        margin-top: 0.17rem;
    }
    .new-product-row:after{
        content:"";
        display: block;
        clear:both;
    }
    .product-row-box{
        width: 1.62rem;
        height: 2.99rem;
        float:left;
    }
    .product-row-img{
        width: 1.5rem;
        height: 1.42rem;
        margin: 0.06rem auto 0.28rem;
    }
    .product-row-img>img{
        width: 1.5rem;
        height: 1.42rem;
    }
    .product-row-title{
        width: 1.5rem;
        height:0.23rem;
        font-size: 0.22rem;
        line-height:0.23rem;
        letter-spacing: 0.01rem;
        color: #000000;
        margin: 0 auto;
    }

</style>