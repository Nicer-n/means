<template>
    <div style="height:100%;padding-bottom:0.94rem;">
        <my-header>
            <img src="../../assets/image/cys/10.1.png" alt="" class="back" @click="$router.back()">
        </my-header>
        <div class="wrapper" ref="wrapper">
            <div class="inner">
                <div id="banners">
                    <div class="detailed" id="active">商品详情
                        <div class="line"></div>
                    </div>
                    <div class="detailed">商品评论
                    </div>
                </div>
                <div class="routing">
                    <div class="routingBox">
                        <swiper :options="options" ref="banner">
                            <swiper-slide v-for="item in goods.pics" :key="item">
                                <div class="imageBox">
                                    <img :src="item" alt="">
                                </div>
                            </swiper-slide>
                        </swiper>
                    </div>
                    <div class="number">
                    </div>
                </div>
                <div class="detail">
                    <div class="detailBox">
                        <h2>{{goods.name_ch}}</h2>
                        <h2>{{goods.name_en}}</h2>
                        <div class="textOne">
                            <p>{{goods.description}}</p>
                        </div>
                        <div class="detailLine">
                            <div class="lineYellow"></div>
                        </div>
                        <div class="textOne">
                            <div class="textTitle">种类</div>
                            <p>{{goods.category}}</p>
                        </div>
                        <div class="textOne">
                            <div class="textTitle">标签</div>
                            <p>{{goods.tags}}</p>
                        </div>
                        <div class="textColor">
                            <div class="textTitle " style="margin-top: 0.07rem">尺寸</div>
                            <div class="colorBox">
                                <label v-for="item in goods.sizes" :key="item">
                                    {{item}}
                                    <input type="radio" :value="item" name="size" v-model="checked">
                                </label>
                            </div>
                        </div>

                        <div class="detailLine">
                            <div class="lineYellow"></div>
                        </div>
                        <div class="priceBox">
                            <div class="priceNum">{{goods.price}}</div>
                            <p>RMB</p>
                        </div>
                        <div class="numberBox">
                            <div class="numberBuy">购买数量</div>
                            <div class="numberRight">
                                <div class="rightRed" @click="number===1?number:number--">-</div>
                                <div class="rightNum">{{number}}</div>
                                <div class="rightRed" @click="number++">+</div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="see">
                    <div class="seeTitle">
                        <p> 您已经</p>
                        <p class="active">浏览</p>
                        <p>过的商品</p>
                    </div>
                    <div class="seeOver">
                        <swiper :options="options2" ref="mySwiper">
                            <swiper-slide v-for="item in viewGoods" :key="item.id">
                                <Goods :item="item"></Goods>
                            </swiper-slide>
                        </swiper>
                    </div>
                </div>
                <div class="content"><img :src="goods.content_mob" alt=""></div>
                <my-recommend :goods="goodsList"></my-recommend>
            </div>
        </div>
        <div class="footer">
            <div class="footerBox">
                <div class="footerLeft" @click="collect">
                    <img src="../../assets/image/yxx/6-1-21.png" alt="" v-if="collectState">
                    <img src="../../assets/image/yxx/6-1-20.png" alt="" v-else>
                    <p>{{collectState?"已收藏":"收藏"}}</p>
                </div>
                <div class="mid" @click="jumpToShoppingCar">加入购物车</div>
                <div class="footerRight">
                    <p>立即购买</p>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
    import Header from "@/components/Header";
    import Recommend from "@/components/Recommend"
    import Goods from "@/components/Goods"
    import 'swiper/dist/css/swiper.css'
    import {swiper, swiperSlide} from 'vue-awesome-swiper'
    import BScroll from "better-scroll";
    import {mapGetters, mapMutations} from "vuex";

    export default {
        name: "Content",
        data: () => ({
            id: 0,
            checked: "",
            goods: {},
            options: {
                pagination: {
                    el: '.number',
                    type: 'fraction',
                },
                autoplay: true
            },
            options2: {
                freeMode: true,
                slidesPerView: 2
            },
            goodsList: [],
            page: 1,
            total: 0,
            viewHistory: [],
            viewGoods: [],
            page2: 0,
            number: 1,
            state: false, //当前商品有没有加入过购物车
            collectState:false //当前商品的收藏状态
        }),
        computed: {
            swiper: function () {
                return this.$refs.mySwiper.swiper;
            },
            bannerSwiper: function () {
                return this.$refs.banner.swiper;
            },
            ...mapGetters(["hasSomeGoods"])
        },
        components: {
            "my-header": Header,
            swiper,
            swiperSlide,
            "my-recommend": Recommend,
            Goods
        },
        methods: {
            ...mapMutations(['add', "remove"]),
            fetchGoodsData: function () {
                this.$http.get("/api/goods/goods", {
                    params: {id: this.id}
                }).then(res => {
                    if (res.data.code === 200) {
                        let data = res.data.data;
                        data.pics = data.pics.split(";");
                        data.sizes = data.sizes.split(",");
                        this.goods = data;
                        this.checked = data.sizes[0];
                        this.state = this.hasSomeGoods(data.id);

                        if (this.state) {
                            this.number = this.state.number;
                            this.checked = this.state.size;
                        }
                        if(localStorage.login){
                            this.$http.get("/api/collect/collect",{params:{
                                uid:localStorage.login,
                                gid:data.id
                                }}).then(res=>{
                                if(res.data.code===200){
                                    this.collectState=true;
                                }
                            }).catch(()=>{
                                console.log("收藏信息获取失败");
                            })
                        }
                    } else {
                        console.log("信息获取失败")
                    }
                }).catch(() => {
                    console.log("信息获取失败")
                })
            },
            fetchGoodsList: function () {
                this.$http.get("/api/goods/goods", {
                    params: {
                        page: this.page,
                        pageSize: 8
                    }
                }).then(res => {
                    if (res.data.code === 200) {
                        this.goodsList = [...this.goodsList, ...res.data.data];
                        this.total = res.data.total;
                        if (!this.scroll) {
                            this.$nextTick(() => {
                                this.scroll = new BScroll(this.$refs.wrapper, {
                                    pullUpLoad: {
                                        threshold: 0
                                    },
                                    click: true
                                });
                                this.scroll.on("pullingUp", () => {
                                    if (this.page * 8 > this.total) {
                                        this.scroll.finishPullUp();
                                        return;
                                    }
                                    this.page++;
                                    this.fetchGoodsList();
                                    this.scroll.finishPullUp();
                                })
                            })
                        } else {
                            this.scroll.refresh();
                        }
                    } else {
                        console.log("获取失败")
                    }
                }).catch(() => {
                    console.log("获取失败")
                })
            },
            fetchViewHistory: function () {
                let data = this.viewHistory.slice(this.page2 * 5, this.page2 * 5 + 5);
                data.forEach(id => {
                    if (id === this.id) {
                        return;
                    }
                    this.$http.get("/api/goods/goods", {
                        params: {id}
                    }).then(res => {
                        if (res.data.code === 200) {
                            this.viewGoods.push(res.data.data);
                        } else {
                            console.log("浏览历史获取失败");
                        }
                    }).catch(() => {
                        console.log("浏览历史获取失败");
                    })
                })
            },
            jumpToShoppingCar: function () {
                if (this.state) {
                    this.remove({id:this.goods.id});
                }
                if (localStorage.login) {
                    this.add({
                        gid: this.id,
                        size: this.checked,
                        number: this.number,
                        state: 0,
                        name_ch: this.goods.name_ch,
                        name_en: this.goods.name_en,
                        thumb: this.goods.thumb,
                        tags: this.goods.tags,
                        goods_price: this.goods.price,
                        checked: false,
                        uid: localStorage.login
                    })
                } else {
                    localStorage.goods = JSON.stringify({
                        gid: this.id,
                        sizes: this.checked,
                        number: this.number,
                        state: 0,
                        name_ch: this.goods.name_ch,
                        name_en: this.goods.name_en,
                        thumb: this.goods.thumb,
                        tags: this.goods.tags,
                        goods_price: this.goods.price,
                        checked: false
                    })
                }
                this.$router.push({name: "shoppingcar"})
            },
            collect:function(){
               if(this.collectState){
                   this.$http.delete("/api/collect/collect",{
                       params:{
                         uid:localStorage.login,
                         gid:this.goods.id
                       }
                   }).then(res=>{
                       if(res.data.code===200){
                           this.collectState=false;
                       }else{
                           console.log("操作失败");
                       }
                   }).catch(()=>{
                       console.log("操作失败");
                   })
               }else{
                   if(localStorage.login){
                      this.$http.post("/api/collect/collect",{
                          uid:localStorage.login,
                          gid:this.goods.id
                      }).then(res=>{
                         if(res.data.code===200){
                             this.collectState=true;
                         }else{
                             console.log("操作失败");
                         }
                      }).catch(()=>{
                          console.log("操作失败");
                      })
                   }else{
                      this.$router.push("/login");
                   }
               }
            }
        },
        beforeRouteUpdate: function (to, from, next) {
            this.id = String(to.query.id);
            this.fetchGoodsData();
            this.viewGoods = [];
            this.page2 = 0;
            this.fetchViewHistory();
            this.$nextTick(() => {
                this.swiper.slideTo(0, 0);
                this.bannerSwiper.slideTo(0, 0);
            });
            this.scroll.scrollTo(0, 0, 300);
            next();
        },
        mounted: function () {
            //初始化当前组件数据
            let {id} = this.$route.query;
            this.id = String(id);
            if (localStorage.viewHistory) {
                this.viewHistory = JSON.parse(localStorage.viewHistory);
            }
            if (!this.viewHistory.includes(this.id)) {
                this.viewHistory.push(this.id);
                localStorage.viewHistory = JSON.stringify(this.viewHistory);
            }
            //调用获取数据的方法
            this.fetchGoodsData();
            this.fetchGoodsList();
            this.fetchViewHistory();
            //注册事件
            this.swiper.on("reachEnd", () => {
                if (this.page2 * 5 > this.viewHistory.length) {
                    return;
                }
                this.page2++;
                this.fetchViewHistory();
            });
        }
    }
</script>

<style lang="scss" scoped>
    .wrapper {
        width: 100%;
        height: 100%;
        overflow: hidden;
        position: relative;
    }

    .radio {
        vertical-align: middle;
    }

    .content img {
        width: 100%;
        height: auto;
    }

    .false {
        width: 0.28rem;
        height: 0.3rem;
        text-align: center;
        line-height: 0.3rem;
        margin-top: 0.29rem;
        font-size: 18px;
        color: rgb(0, 0, 0);
    }

    .tu {
        width: 0.92rem;
        height: 0.3rem;
        margin-top: 0.29rem;
    }

    .tu > img {
        width: 100%;
        height: 100%;
    }

    .more {
        width: 0.36rem;
        height: 0.08rem;
        text-align: center;
        line-height: 0.08rem;
        margin-top: 0.4rem;
        font-size: 18px;
        color: rgb(0, 0, 0);
    }

    /*头部结束*/
    #banners {
        width: 100%;
        height: 0.97rem;
        border-bottom: 0.01rem solid rgb(255, 203, 63);
    }

    .detailed {
        width: 3.75rem;
        height: 0.97rem;
        line-height: 0.97rem;
        font-size: 0.24rem;
        letter-spacing: 0.01rem;
        color: rgba(0, 0, 0, 0.7);
        position: relative;
        float: left;
        text-align: center;
    }

    #active {
        font-weight: bold;
        color: rgb(255, 203, 63);
    }

    .line {
        position: absolute;
        top: 0.93rem;
        left: 0;
        right: 0;
        margin: auto;
        width: 0.55rem;
        height: 0.03rem;
        background: rgb(255, 203, 63);
    }

    /*banner*/
    .routing {
        width: 100%;
        height: 5.32rem;
        overflow: hidden;
    }

    .routingBox {
        width: 100%;
        height: 5rem;
    }

    .imageBox {
        width: 100%;
        height: 5rem;
    }

    .imageBox img {
        width: 100%;
        height: 5rem;
    }

    .number {
        width: auto;
        height: 0.32rem;
        float: right;
        margin-right: 0.28rem;
    }

    .number span {
        width: auto;
        height: 0.32rem;
        line-height: 0.32rem;
        color: rgb(255, 203, 63);
        font-family: ArialMT;
        font-size: 0.3rem;
        letter-spacing: 0.02rem;
        float: left;
    }

    .number span:last-child {
        width: auto;
        font-size: 0.24rem;
        letter-spacing: 0.01rem;
        height: 0.3rem;
        line-height: 0.4rem;
        float: left;
    }

    /*轮播*/
    .detail {
        width: 100%;
        height: 5rem;
        padding-top: 0.32rem;
    }

    .detailBox {
        width: 6.66rem;
        height: 4.49rem;

        margin: 0 auto;
    }

    .detailBox h2 {
        width: auto;
        letter-spacing: 0.03rem;
        font-size: 0.3rem;
    }

    .detailLine {
        width: 6.58rem;
        height: 0.02rem;
        margin: 0.22rem auto 0.29rem;
        background: rgb(215, 215, 215);
    }

    .lineYellow {
        width: 0.47rem;
        height: 0.03rem;
        margin-top: -0.01rem;
        background: rgb(255, 203, 63);
    }

    .detailBox .textOne {
        width: 100%;
        height: 0.3rem;
        margin-bottom: 0.25rem;
    }

    .textTitle {
        width: 0.77rem;
        height: 0.3rem;
        line-height: 0.3rem;
        font-size: 0.24rem;
        letter-spacing: 0.02rem;
        color: black;
        float: left;
    }

    .textOne p {
        float: left;
        width: auto;
        height: 100%;
        line-height: 0.3rem;
        font-size: 0.24rem;
        letter-spacing: 0.02rem;
        color: black;
    }

    .textColor {
        width: 100%;
        height: 0.45rem;
        margin: 0.07rem 0 0.28rem;
    }

    .colorBox {
        width: 3.19rem;
        height: 100%;
        display: flex;
        justify-content: space-between;
        align-items: center;
    }

    .colorBox img:nth-child(1) {
        width: 0.44rem;
        height: 0.44rem;
    }

    .colorBox img {
        width: 0.37rem;
        height: 0.37rem;
        /*  margin-top: 0.04rem;
          display: block;*/
    }

    .priceBox {
        width: 100%;
        height: 0.34rem;
    }

    .priceNum {
        width: auto;
        height: 100%;
        font-size: 0.34rem;
        line-height: 0.34rem;
        letter-spacing: 0.03rem;
        color: black;
        float: left;
    }

    .priceBox p {
        width: auto;
        line-height: 0.42rem;
        float: left;
        font-size: 0.14rem;
        letter-spacing: 0.02rem;
    }

    .numberBox {
        width: 100%;
        height: 0.6rem;
        float: left;
    }

    .numberBuy {
        width: auto;
        height: 0.3rem;
        letter-spacing: 0.02rem;
        font-size: 0.24rem;
        line-height: 0.3rem;
        margin-top: 0.25rem;
        float: left;

    }

    .numberRight {
        width: 1.6rem;
        height: 100%;
        float: right;
        margin-right: 0.65rem;
        padding-top: 0.2rem;
    }

    .rightRed {
        width: 0.42rem;
        height: 0.42rem;
        border: 0.02rem solid rgba(0, 0, 0, 0.1);
        background: white;
        text-align: center;
        line-height: 0.32rem;
        float: left;
        font-size: 0.3rem;
    }

    .rightNum {
        width: 0.75rem;
        background: white;
        height: 0.42rem;
        text-align: center;
        line-height: 0.42rem;
        float: left;
    }

    /*详情信息*/
    .see {
        width: 100%;
        background: white;
        margin-top: 0.6rem;
    }

    .seeTitle {
        width: 3rem;
        height: 0.65rem;
        margin-left: 0.4rem;
        border-top: 0.01rem solid rgb(215, 215, 215);
    }

    .seeTitle p {
        width: auto;
        height: 0.27rem;
        margin-top: 0.3rem;
        float: left;
        font-size: 0.26rem;
        letter-spacing: 0.03rem;
    }

    .active {
        color: rgb(255, 203, 63);
        font-weight: bold;
    }

    .seeOver {
        width: 100%;
        height: auto;
        overflow: hidden;
        margin-top: 0.3rem;
    }

    .seeBox {
        width: 10rem;
        height: 5.1rem;
    }

    .newItem {
        width: 3.1rem;
        height: 5.1rem;
        float: left;
        margin-right: 0.23rem;
        box-shadow: 0 0 0.1rem 0.05rem, rgba(0, 0, 0, 0.2);
    }

    .newItem .newItemImage {
        width: 3.1rem;
        height: 3.1rem;
        overflow: hidden;
    }

    .newItem .newItemImage img {
        width: auto;
        height: 100%;
    }

    .newItem .newItemText {
        width: 100%;
        height: 2.19rem;
        padding: 0.17rem 0.14rem 0.23rem;
    }

    .newItem .newItemText .newItemLine {
        width: 0.27rem;
        height: 0.02rem;
        background: black;
        margin-bottom: 0.12rem;
    }

    .newItem .newItemText .newItemTextEng {
        font-size: 0.18rem;
        letter-spacing: 0.01rem;
    }

    .newItem .newItemText .newItemTextChi {
        font-size: 0.24rem;
        margin-top: 0.08rem;
        letter-spacing: 0.01rem;
    }

    .newPrice {
        width: 100%;
        height: 0.48rem;
        margin-top: 0.42rem;
    }

    .newPrice .newNumber {
        font-size: 0.26rem;
        width: 0.48rem;
        float: left;
        line-height: 0.48rem;
    }

    /*.newPrice .rmb{
        font-size: 0.12rem;
        width: 0.3rem;
        float: left;
        line-height: 0.3rem;
    }*/
    .click {
        float: right;
        width: 1.53rem;
        height: 0.44rem;
        text-align: center;
        line-height: 0.44rem;
        border-radius: 0.02rem;
        font-size: 0.22rem;
        letter-spacing: 0.01rem;
        font-weight: bold;
        color: white;
        background: rgb(255, 203, 63);
    }

    .click a {
        width: 0.89rem;
        height: 0.25rem;
        text-align: center;
        line-height: 0.25rem;
        border-radius: 0.30rem;
        font-size: 10px;
        font-weight: bold;
        color: white;
        background: rgb(255, 203, 63);
    }

    .click a:hover {
        color: black;
    }

    /*浏览*/
    .product {
        width: 100%;
        height: 0.96rem;
    }

    .newProduct {
        width: 2.3rem;
        height: 0.96rem;
        margin: 0.8rem auto 0.73rem;
    }

    .newProduct .firstLine {
        width: 0.47rem;
        height: 0.02rem;
        background: rgb(255, 203, 63);
        margin-left: 0.43rem;
    }

    .newProduct .secondLine {
        width: 1.47rem;
        height: 0.02rem;
        background: rgb(215, 215, 215);
        margin: 0.08rem auto 0;
    }

    .newProduct .newText {
        font-family: ArialMT;
        width: 100%;
        font-size: 0.14rem;
        white-space: nowrap;
        text-align: center;
        margin-top: 0.09rem;
    }

    .newChinese {
        width: 1.5rem;
        height: 0.32rem;
        margin: 0.11rem auto 0.18rem;
    }

    .chinese {
        width: auto;
        height: 0.32rem;
        font-size: 0.32rem;
        margin: 0 auto 0 auto;
        line-height: 0.32rem;
        text-align: center;
    }

    .chinese.chineseOne {
        float: left;
    }

    .chinese.chineseTwo {
        color: #ffcb3f;
        float: right;
    }

    .newProduct .thirdLine {
        width: 0.34rem;
        height: 0.02rem;
        background: black;
        /*margin-top:14px;*/
        margin: 0.12rem auto 0;
    }

    /*题目*/
    .imgBox3 {
        width: 100%;
        height: auto;
        margin: 0 auto;
    }

    .imgBox3 img {
        display: block;
        width: 6.41rem;
        height: 5.48rem;
        margin: 0 auto;
    }

    .imgBox1 {
        width: 100%;
        height: 4.14rem;
        margin-top: 1.07rem;
    }

    .imgBox1 img {
        width: 100%;
        height: 4.14rem;
        display: block;
    }

    .imgTitle {
        width: 100%;
        height: 2.14rem;
        padding-top: 0.7rem;
    }

    .imgTitle .scene {
        width: 1.4rem;
        height: 0.8rem;
        margin: 0 auto;
    }

    .scene p:nth-child(1) {
        width: auto;
        font-size: 0.24rem;
        letter-spacing: 0.02rem;
        color: rgb(0, 0, 0);
        margin-bottom: 0.09rem;
    }

    .scene p:nth-child(2) {
        font-size: 0.18rem;
        letter-spacing: 0.02rem;
    }

    .imgBox2 {
        width: 100%;
        height: 5.18rem;
    }

    .imgBox2 img {
        width: 100%;
        height: 5.18rem;
    }

    /*img*/
    .productNum {
        width: 100%;
        height: 2.47rem;
    }

    .productNum img {
        width: 6.64rem;
        height: 2rem;
        display: block;
        margin: 0 auto;
    }

    .recommend {
        width: 100%;
        height: 12.2rem;
        margin: 0 auto;
        padding-top: 1.2rem;
    }

    .recTitle {
        width: 100%;
        height: 0.3rem;
        background: white;
        border-left: 0.03rem solid rgb(255, 203, 63);
        margin-left: 0.24rem;
    }

    .recTitle P {
        margin-left: 0.12rem;
        font-size: 0.3rem;
        letter-spacing: 0.02rem;
    }

    .recommendBox {
        width: 7rem;
        height: auto;
        background: lightblue;
        margin: 0.36rem 0 0 0.3rem;
    }

    .footer {
        width: 100%;
        height: 0.96rem;
        background: lightcyan;
        position: fixed;
        left: 0;
        bottom: 0;
    }

    .footerBox {
        width: 7.5rem;
        height: 0.94rem;
        background: rgb(252, 252, 252);
        z-index: 66;
        border-top: 0.02rem solid rgb(238, 238, 238);
    }

    .footerLeft {
        width: 1.3rem;
        height: 0.94rem;
        background: white;
        border-right: 0.02rem solid rgb(238, 238, 238);
        float: left;
    }

    .footerLeft img {
        width: 0.38rem;
        height: 0.38rem;
        margin: 0.15rem 0 0 0.42rem;
    }

    .footerLeft p {
        width: auto;
        color: rgb(102, 102, 102);
        text-align: center;
    }

    .footerRight {
        width: 3.1rem;
        height: 100%;
        background: rgb(255, 203, 63);
        border-radius: 0.04rem;
        float: right;
    }

    .footerRight p {
        width: auto;
        height: 0.94rem;
        line-height: 0.94rem;
        text-align: center;
        font-weight: bold;
        color: white;
        font-size: 0.28rem;
        letter-spacing: 0.03rem;
    }

    .mid {
        width: 3.1rem;
        height: 0.94rem;
        line-height: 0.94rem;
        text-align: center;
        color: rgb(102, 102, 102);
        font-size: 0.28rem;
        letter-spacing: 0.03rem;
        float: left;
    }

</style>