<template>
    <div style="height:100%">
        <div class="container">
            <my-header></my-header>
            <!--评价-->
            <div class="wrapper" ref="wrapper">
                <div class="inner">
                    <div id="evaluate">
                        <div class="ping">我的订单</div>
                    </div>
                    <div class="order">
                        <div class="imgBox">
                        </div>
                        <div class="text">
                            <p class="textChi"><b>您的订单已完成 宝贝正在飞奔向你~</b></p>
                        </div>
                        <div class="clickBox">
                            <div class="click" @click="$router.push('/index')">返回首页</div>
                            <div class="click" @click="$router.push('/orderlist')">查看订单</div>
                        </div>
                    </div>
                    <my-recommend :goods="this.goods"></my-recommend>
                </div>
            </div>
            <my-footer hot="shoppingcar"></my-footer>
        </div>
    </div>
</template>

<script>
    import Header from "@/components/Header";
    import Footer from "@/components/Footer";
    import Recommend from "@/components/Recommend";
    import BScroll from "better-scroll";

    export default {
        name: "PayResult",
        data: () => ({
            goods: []
        }),
        methods: {
            fetchGoodsData: function () {
                this.$http.get("/api/goods/goods", {
                    params: {
                        page: this.page,
                        pageSize: 8
                    }
                }).then(res => {
                    if (res.data.code === 200) {
                        this.goods = [...this.goods, ...res.data.data];
                        this.total = res.data.total;
                        if (!this.scroll) {
                            this.$nextTick(() => {
                                this.scroll = new BScroll(this.$refs.wrapper, {
                                    pullUpLoad: {
                                        threshold: 0
                                    },
                                    click: true,
                                    preventDefault: false
                                });
                                this.scroll.on("pullingUp", () => {
                                    if (this.page * 8 > this.total) {
                                        this.scroll.finishPullUp();
                                        return;
                                    }
                                    this.page++;
                                    this.fetchGoodsData();
                                    this.scroll.finishPullUp();
                                });
                            })
                        } else {
                            this.scroll.refresh();
                        }
                    }
                }).catch(() => {
                    console.log("获取商品失败");
                })
            }
        },
        mounted() {
            this.fetchGoodsData();
        },
        components: {
            "my-header": Header,
            "my-footer": Footer,
            "my-recommend": Recommend
        }
    }
</script>

<style lang="scss" scoped>
    .container {
        background: #fcfcfc;
        height: 100%;
    }

    .wrapper {
        width: 100%;
        height: 100%;
        overflow: hidden;
        position: relative;
    }

    #evaluate {
        width: 100%;
        height: 0.78rem;
        /*padding-top: 0.26rem;*/
        border-bottom: 1px solid #e3e3e3;
        /*background: deepskyblue;*/
        position: relative;

    }

    .toLeft {
        width: 0.15rem;
        height: 0.24rem;
        margin-left: 0.24rem;
        line-height: 0.24rem;
        font-size: 13px;
        color: rgb(0, 0, 0);
        float: left;
        /*background:red;*/
        position: absolute;
        top: 0.27rem;
    }

    .toLeft > i {
        font-size: 0.34rem;
        text-align: center;
        line-height: 0.24rem;
        margin-left: -0.04rem;
    }

    .ping {
        /*float: left;*/
        width: 100%;
        height: 100%;
        line-height: 0.78rem;
        text-align: center;
        font-family: MicrosoftYaHei;
        font-size: 0.28rem;

        /*top: 1.14rem;*/
        /*left: 0;*/
        /*right: 0;*/
        /*bottom: 0;*/
        /*margin-left:auto;*/
        /*margin-right: auto;*/
        /*background:#fcd7a2;*/
        letter-spacing: 0.01rem;

    }

    .order {
        width: 7.02rem;
        height: 3.35rem;
        /*background:#a79bcd;*/
        box-shadow: 0 0.01rem 0.15rem #cfcfcf;
        margin: 0 auto;
        border-radius: 0.13rem;
        position: relative;
    }

    .order > .imgBox {
        width: 3.85rem;
        height: 2.25rem;
        /*background:#f6b7d2;*/
        margin: 0 auto;
    }

    .order > .imgBox > img {
        width: 100%;
        height: 100%;
    }

    .order > .text {
        width: 100%;
        position: absolute;
        top: 0.74rem;
    }

    .order > .text > .textChi {
        width: 100%;
        /*background:#5ec2d1;*/
        font-size: 0.28rem;
        text-align: center;
    }

    .order > .text > .textEng {
        width: 100%;
        /*background:#5ec2d1;*/
        font-size: 0.18rem;
        text-align: center;
        color: #737373;
    }

    .order > .clickBox {
        width: 100%;
        height: 0.49rem;
        /*background:#a7d4ad;*/
        margin-top: 0.25rem;
        padding: 0 1.07rem 0 1.7rem;
        display: flex;
        justify-content: space-between;
    }

    .order > .clickBox > .click {
        width: 1.45rem;
        height: 100%;
        font-size: 0.24rem;
        color: black;
        letter-spacing: 0.02rem;
        text-align: center;
        line-height: 0.49rem;
        border-radius: 0.12rem;
    }

    /*推荐开始*/
    .recommend {
        padding: 0 0.37rem;
    }

    .titleBox {
        width: 100%;
        height: 0.3rem;
        /*background:#a7d4ad;*/
        margin-top: 0.36rem;
    }

    .titleBox > .titleLine {
        width: 0.03rem;
        height: 0.21rem;
        background: #ffcb3f;
        float: left;
        margin: 0.04rem 0.1rem 0 0;
    }

    .titleBox > .titleText {
        font-size: 0.3rem;
        letter-spacing: 0.01rem;
        line-height: 0.3rem;
    }

    .recommend > .itemBox {
        width: 6.77rem;
        height: 10.4rem;
        /*background:#a79bcd;*/
        margin: 0.36rem auto 0.35rem auto;
        display: flex;
        flex-wrap: wrap;
        justify-content: space-between;
    }

    .recommend > .itemBox > .item {
        width: 3.24rem;
        height: 5.08rem;
        /*background:#5ec2d1;*/
        float: left;
        box-shadow: 0 0.01rem 0.15rem #cfcfcf;
    }

    .recommend > .itemBox > .item > a {
        display: block;
        width: 100%;
        height: 100%;
    }

    .recommend > .itemBox > .item > a > .imgBox {
        width: 100%;
        height: 3.05rem;
        /*background:#ee857f;*/
    }

    .recommend > .itemBox > .item > a > .imgBox > img {
        width: 100%;
        height: 100%;
    }

    .recommend > .itemBox > .item > a > .textBox {
        width: 100%;
        height: auto;
        /*background:#fff57f;*/
        margin-top: 0.2rem;
        padding-left: 0.22rem;
    }

    .recommend > .itemBox > .item > a > .textBox > .textLine {
        width: 0.32rem;
        height: 0.02rem;
        background: black;
    }

    .recommend > .itemBox > .item > a > .textBox > .textEng {
        font-size: 0.18rem;
        margin-top: 0.1rem;
    }

    .recommend > .itemBox > .item > a > .priceBox {
        width: 100%;
        height: 0.44rem;
        /*background:#accd02;*/
        margin-top: 0.54rem;
        padding: 0 0.2rem;
        float: left;
    }

    .recommend > .itemBox > .item > a > .priceBox > .priceText {
        /*background:#ee857f;*/
        float: left;
    }

    .recommend > .itemBox > .item > a > .priceBox > .priceText > span:nth-child(1) {
        font-size: 0.22rem;
        line-height: 0.44rem;
    }

    .recommend > .itemBox > .item > a > .priceBox > .priceText > span:nth-child(2) {
        font-size: 0.16rem;
        line-height: 0.44rem;
    }

    .recommend > .itemBox > .item > a > .priceBox > .click {
        width: 1.53rem;
        height: 0.44rem;
        background: #ffcb3f;
        border-radius: 0.1rem;
        float: right;
        padding: 0 0 0 0.23rem;
    }

    .recommend > .itemBox > .item > a > .priceBox > .click > .icon {
        width: 0.16rem;
        height: 0.16rem;
        /*background:#fff57f;*/
        margin-top: 0.12rem;
        line-height: 0.16rem;
        text-align: center;
        float: left;

    }

    .recommend > .itemBox > .item > a > .priceBox > .click > .icon > i {
        font-size: 0.2rem;
        color: white;

    }

    .recommend > .itemBox > .item > a > .priceBox > .click > .text {
        font-size: 0.2rem;
        color: white;
        float: left;
        line-height: 0.44rem;
        margin-left: 0.05rem;
    }

    .toLeft img {
        width: 0.2rem;
        height: 0.3rem;
        margin-left: 0.1rem;
    }

</style>