<template>
    <div>
        <div class="max">
            <my-header></my-header>
            <div class="nav">
                <div class="nav-content">
                    <div class="nav-left"><i class="iconfont icon-arrow-left"></i></div>
                    <div class="nav-right">我的收藏</div>
                </div>
            </div>
            <!--图片-->
            <div class="img-bj">
                <div class="img-max">
                    <div class="img-box">
                        <div class="img-left">
                            <img src="../../assets/image/ljq/11-1.png" alt="">
                        </div>
                        <div class="img-right">
                            <div class="text-top">
                                <p class="text1">BOSC XISTERA</p>
                                <p class="text2">现代客厅沙发</p>
                                <p class="text3">￥520*2</p>
                            </div>
                            <div class="text-top2">
                                <p class="text4">绿色/单人座</p>
                            </div>
                            <div class="text-top3">
                                <p class="text5">2019-03-20</p>
                                <span class="text6" style="font-size:0.24rem;">1040 <span
                                        class="text7">RMB</span></span>
                            </div>
                            <div class="text-top4">
                                <div class="text8">
                                    <p class="text9">取消订单</p>
                                    <p class="text10">加入购物车</p>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="img-box">
                        <div class="img-left">
                            <img src="../../assets/image/ljq/11-2.png" alt="">
                        </div>
                        <div class="img-right">
                            <div class="text-top">
                                <p class="text1">BOSC XISTERA</p>
                                <p class="text2">现代客厅沙发</p>
                                <p class="text3">￥520*2</p>
                            </div>
                            <div class="text-top2">
                                <p class="text4">绿色/单人座</p>
                            </div>
                            <div class="text-top3">
                                <p class="text5">2019-03-20</p>
                                <span class="text6" style="width: 1.1rem">520<span class="text7">RMB</span></span>
                            </div>
                            <div class="text-top4">
                                <div class="text8">
                                    <p class="text9">取消订单</p>
                                    <p class="text10">加入购物车</p>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="img-box">
                        <div class="img-left">
                            <img src="../../assets/image/ljq/11-3.png" alt="">
                        </div>
                        <div class="img-right">
                            <div class="text-top">
                                <p class="text1">BOSC XISTERA</p>
                                <p class="text2">现代客厅沙发</p>
                                <p class="text3">￥520*2</p>
                            </div>
                            <div class="text-top2">
                                <p class="text4">绿色/单人座</p>
                            </div>
                            <div class="text-top3">
                                <p class="text5">2019-03-20</p>
                                <span class="text6" style="width: 1.1rem">520<span class="text7">RMB</span></span>
                            </div>
                            <div class="text-top4">
                                <div class="text8">
                                    <p class="text9">取消订单</p>
                                    <p class="text10">加入购物车</p>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>

                <!--推荐-->
                <div class="for-you">
                    <div class="for-text">
                        <div class="text-t">
                            <div class="t-left"></div>
                            <div class="t-right">推荐商品</div>
                        </div>
                    </div>
                </div>
                <div class="center">
                    <div class="img-list">
                        <img src="../../assets/image/ljq/11-4.png" alt="">
                        <div class="xian"></div>
                        <div class="hanzi">
                            <p class="han1">VERFO LAB</p>
                            <p class="h2">现代简约时尚布艺沙发</p>
                        </div>
                        <div class="click">
                            <div class="number">
                                <p class="number1">800</p>
                                <p class="number2">RMB</p>
                            </div>
                            <div class="click-b">
                                <div class="click-l"><i class="iconfont icon-add"></i></div>
                                <div class="click-t">点击购买</div>
                            </div>
                        </div>
                    </div>

                    <div class="img-list" style="margin-left: 0.4rem">
                        <img src="../../assets/image/ljq/11-4.png" alt="">
                        <div class="xian"></div>
                        <div class="hanzi">
                            <p class="han1">VERFO LAB</p>
                            <p class="h2">现代简约时尚布艺沙发</p>
                        </div>
                        <div class="click">
                            <div class="number">
                                <p class="number1">800</p>
                                <p class="number2">RMB</p>
                            </div>
                            <div class="click-b">
                                <div class="click-l"><i class="iconfont icon-add"></i></div>
                                <div class="click-t">点击购买</div>
                            </div>
                        </div>
                    </div>

                    <div class="img-list">
                        <img src="../../assets/image/ljq/11-4.png" alt="">
                        <div class="xian"></div>
                        <div class="hanzi">
                            <p class="han1">VERFO LAB</p>
                            <p class="h2">现代简约时尚布艺沙发</p>
                        </div>
                        <div class="click">
                            <div class="number">
                                <p class="number1">800</p>
                                <p class="number2">RMB</p>
                            </div>
                            <div class="click-b">
                                <div class="click-l"><i class="iconfont icon-add"></i></div>
                                <div class="click-t">点击购买</div>
                            </div>
                        </div>
                    </div>

                    <div class="img-list" style="margin-left: 0.4rem;">
                        <img src="../../assets/image/ljq/11-4.png" alt="">
                        <div class="xian"></div>
                        <div class="hanzi">
                            <p class="han1">VERFO LAB</p>
                            <p class="h2">现代简约时尚布艺沙发</p>
                        </div>
                        <div class="click">
                            <div class="number">
                                <p class="number1">800</p>
                                <p class="number2">RMB</p>
                            </div>
                            <div class="click-b">
                                <div class="click-l"><i class="iconfont icon-add"></i></div>
                                <div class="click-t">点击购买</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <my-footer></my-footer>
    </div>
</template>

<script>
    import Header from "@/components/Header";
    import Footer from "@/components/Footer";
    export default {
        name: "Collect",
        data: () => ({}),
        components: {
            "my-header": Header,
            "my-footer":Footer,
        }
    }
</script>

<style lang="scss" scoped>
    .max {
        width: 100%;
        height: auto;
    }

    .nav {
        width: 100%;
        height: 0.78rem;
    }

    .nav-left {
        width: 0.15rem;
        height: 0.24rem;
        float: left;
        margin-left: 0.24rem;
        margin-top: 0.27rem;
    }

    .nav-content {
        width: 7.5rem;
        height: 0.78rem;
        background: rgb(255, 255, 255);
        border-bottom: 1px solid rgb(238, 238, 238);
        margin: 0 auto;
    }

    .nav-right {
        width: 1.14rem;
        height: 0.28rem;
        color: rgb(0, 0, 0);
        float: left;
        text-align: center;
        line-height: 0.78rem;
        margin-left: 2.78rem;
        font-size: 0.28rem;
        font-family: MicrosoftYaHei;
    }
    
    /*我的订单*/
    .img-bj {
        width: 100%;
        height: auto;
        padding-left: 0.24rem;
        padding-right: 0.24rem;
        background: rgb(238, 238, 238);
        float: left;
    }

    .img-max {
        width: 100%;
        height: 9.5rem;
        float: left;
    }

    .img-box {
        width: 7.02rem;
        height: 2.76rem;
        background: rgb(255, 255, 255);
        border-radius: 0.1rem;
        box-shadow: 0 0.01rem 0.21rem 0 rgba(0, 0, 0, 0.09);
        margin: 0.23rem auto;
    }

    .img-left {
        width: 1.86rem;
        height: 1.36rem;
        float: left;
        margin-left: 0.2rem;
        margin-top: 0.52rem;
    }

    .img-left img {
        width: 100%;
        height: 100%;
    }

    .img-right {
        float: left;
        width: 4.6rem;
        height: 2rem;
        margin-left: 0.14rem;
        margin-top: 0.52rem;
    }

    .text-top {
        width: 100%;
        height: 0.24rem;
    }

    .text1 {
        color: rgb(0, 0, 0);
        font-family: MicrosoftYaHeiLight;
        font-size: 0.18rem;
        letter-spacing: 0.01rem;
        float: left;
        line-height: 0.18rem;
    }

    .text2 {
        float: left;
        color: rgb(0, 0, 0);
        font-family: MicrosoftYaHei;
        font-size: 0.24rem;
        letter-spacing: 0.01rem;
        line-height: 0.18rem;
    }

    .text3 {
        float: right;
        color: rgb(0, 0, 0);
        font-size: 0.24rem;
        letter-spacing: 0.02rem;
        line-height: 0.18rem;
    }

    .text-top2 {
        width: 100%;
        height: 0.24rem;
        /*background: lightpink;*/
        margin-top: 0.09rem;
    }

    .text4 {
        width: 1.5rem;
        height: 0.18rem;
        font-size: 0.18rem;
        letter-spacing: 0.02rem;
        line-height: 0.18rem;
        color: rgba(0, 0, 0, 0.7);
    }

    .text-top3 {
        width: 100%;
        height: 0.35rem;
        /*background: tomato;*/
        margin-top: 0.37rem;
    }

    .text5 {
        float: left;
        width: 1.30rem;
        height: 0.15rem;
        font-size: 0.18rem;
        letter-spacing: 0.02rem;
        line-height: 0.36rem;
        color: rgba(0, 0, 0, 0.7);
    }

    .text6 {
        float: right;
        width: 1.27rem;
        height: 0.21rem;
        font-size: 0.26rem;
        letter-spacing: 0.03rem;
        line-height: 0.36rem;
        color: rgb(0, 0, 0);
        font-weight: bold;
        margin-top: 0.09rem;
    }

    .text7 {
        float: right;
        font-size: 0.18rem;
        letter-spacing: 0.02rem;
        line-height: 0.36rem;
        color: rgb(0, 0, 0);
        font-family: MicrosoftYaHei;
        margin-top: 0.04rem;
    }

    .text-top4 {
        width: 100%;
        height: 0.44rem;
        margin-top: 0.27rem;
    }

    .text8 {
        float: right;
        width: 2.75rem;
        height: 0.44rem;
    }

    .text9 {
        float: left;
        width: 1.13rem;
        height: 0.24rem;
        font-size: 0.24rem;
        line-height: 0.36rem;
        color: rgb(153, 153, 153);
        margin-right: 0.26rem;
    }

    .text10 {
        float: left;
        width: 1.34rem;
        height: 0.44rem;
        border: 1px solid rgb(255, 203, 63);
        border-radius: 0.04rem;
        font-size: 0.24rem;
        line-height: 0.44rem;
        color: rgb(255, 203, 63);
        text-align: center;
    }

    .for-you {
        float: left;
        width: 100%;
        height: auto;
        margin-top: 0.51rem;
    }

    .for-text {
        width: 100%;
        height: 0.3rem;
    }

    .text-t {
        width: 2rem;
        height: 0.3rem;
        float: left;
    }

    .t-left {
        float: left;
        width: 0.03rem;
        height: 0.21rem;
        background: rgb(255, 203, 63);
        margin-top: 0.05rem;
    }

    .t-right {
        float: left;
        width: 1.5rem;
        height: 0.3rem;
        color: rgb(0, 0, 0);
        font-size: 0.3rem;
        line-height: 0.3rem;
        margin-left: 0.08rem;
        letter-spacing: 0.02rem;
    }

    .center {
        width: 100%;
        height: 10.5rem;
        overflow: hidden;
        float: left;
        margin-bottom: 1.5rem;
    }

    .img-list {
        width: 3.24rem;
        height: 5.08rem;
        float: left;
        margin-top: 0.36rem;
        overflow: hidden;
        background: white;
    }

    .img-list img {
        width: 4.7rem;
        height: 3.12rem;
    }

    .xian {
        width: 0.32rem;
        height: 0.03rem;
        background: rgb(0, 0, 0);
        margin-left: 0.23rem;
    }

    .hanzi {
        width: 2.4rem;
        height: 0.62rem;
        margin-left: 0.23rem;
        margin-top: 0.14rem;
    }

    .hanzi .han1 {
        font-size: 0.18rem;
        line-height: 0.2rem;
    }

    .hanzi .han2 {
        font-size: 0.24rem;
        line-height: 0.2rem;
    }

    .click {
        width: 100%;
        height: 0.44rem;
        margin-top: 0.54rem;
    }

    .number {
        /*float: left;*/
        width: 0.9rem;
        height: 0.19rem;
        margin-left: 0.23rem;
        /*background: lightslategray;*/
        float: left;
    }

    .number p {
        display: inline-block;
    }

    .number1 {
        font-size: 0.23rem;
        line-height: 0.2rem;
        font-weight: bold;
        float: left;
    }

    .number2 {
        font-size: 0.18rem;
        line-height: 0.2rem;
        float: left;
        margin-top: 0.01rem;

    }

    .click-b {
        float: left;
        margin-left: 0.5rem;
        margin-top: -0.05rem;
        width: 1.53rem;
        height: 0.44rem;
        background: rgb(255, 203, 63);
        border-radius: 0.04rem;
    }

    .click-b i {
        width: 0.16rem;
        height: 0.16rem;
        line-height: 0.44rem;
        margin-left: 0.17rem;
        color: white;
        float: left;
    }

    .click-t {
        width: 0.89rem;
        height: 0.22rem;
        font-size: 0.22rem;
        color: rgb(255, 255, 255);
        float: left;
        text-align: center;
        margin-left: 0.49rem;
        line-height: 0.1rem;
    }

    .nav-right {
        width: 1.14rem;
        height: 0.28rem;
        color: rgb(0, 0, 0);
        float: left;
        text-align: center;
        line-height: 0.78rem;
        margin-left: 2.78rem;
        font-size: 0.28rem;
        font-family: MicrosoftYaHei;
    }

    #content {
        width: 100%;
        height: 0.98rem;
        display: flex;
        justify-content: space-between;

    }

    #content > ul {
        width: 100%;
        height: 0.98rem;
        padding-top: 0.14rem;
        display: flex;
        justify-content: space-between;
    }

    #content > ul > li {
        float: left;
        width: 0.62rem;
        height: 0.7rem;
    }

    #content > ul > li > div {
        width: 0.4rem;
        height: 0.4rem;
        margin-left: 0.11rem;
        font-size: 0.44rem;
        line-height: 0.4rem;
        text-align: center;
    }

    #content > ul > li > span {
        display: block;
        width: 0.62rem;
        height: 0.2rem;
        text-align: center;
        margin-top: 0.1rem;
        line-height: 0.2rem;
        font-size: 0.2rem;
        font-family: MicrosoftYaHei;
        color: rgb(0, 0, 0);
    }

    #content > ul > li > div.active {
        color: rgb(255, 203, 63);
    }

    #content > ul > li > span.active {
        color: rgb(255, 203, 63);
    }

</style>