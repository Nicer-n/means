<template>
    <div style="height:100%;background:#efefef;">
        <my-header></my-header>
        <div class="wrapper" ref="wrapper">
            <div class="inner">
                <ul id="nav">
                    <li><a href="">产品分类</a></li>
                    <li><a href="">案例展示</a></li>
                    <li><a href="">设计团队</a></li>
                    <li><a href="">品牌故事</a></li>
                </ul>
                <!--nav-->
                <div id="banner">
                    <swiper :options="options">
                        <swiper-slide>
                            <ul class="banner-box">
                                <li><img src="../../assets/image/cys/banner.png" alt=""></li>
                                <li class="banner-box-row">
                                    <p class="banner-row-one">THE CHAIR</p>
                                    <p class="banner-row-one">DESIGN</p>
                                    <p class="banner-row-two">告别繁琐多余的浮夸</p>
                                    <p class="banner-row-more">MORE</p>
                                </li>
                            </ul>
                        </swiper-slide>
                        <swiper-slide>
                            <ul class="banner-box">
                                <li><img src="../../assets/image/cys/banner.png" alt=""></li>
                                <li class="banner-box-row">
                                    <p class="banner-row-one">THE CHAIR</p>
                                    <p class="banner-row-one">DESIGN</p>
                                    <p class="banner-row-two">告别繁琐多余的浮夸</p>
                                    <p class="banner-row-more">MORE</p>
                                </li>
                            </ul>
                        </swiper-slide>
                        <swiper-slide>
                            <ul class="banner-box">
                                <li><img src="../../assets/image/cys/banner.png" alt=""></li>
                                <li class="banner-box-row">
                                    <p class="banner-row-one">THE CHAIR</p>
                                    <p class="banner-row-one">DESIGN</p>
                                    <p class="banner-row-two">告别繁琐多余的浮夸</p>
                                    <p class="banner-row-more">MORE</p>
                                </li>
                            </ul>
                        </swiper-slide>
                    </swiper>
                    <ul class="banner-page">
                    </ul>
                </div>
                <!--banner-->
                <div class="new-top" style="margin-bottom: 0.49rem">
                    <div class="new-box">
                        <div class="whippletree"></div>
                        <div class="whippletree2"></div>
                        <div class="new-title">NEW PRODUCT</div>
                        <div class="new-title2">
                            <span class="new-title2-left">新品</span>
                            <span class="new-title2-right">首发</span>
                        </div>
                    </div>
                </div>
                <!--new top-->
                <div class="new-product">
                    <swiper :options="options2">
                        <swiper-slide v-for="item in newProduct" :key="item.id">
                            <Goods :item="item"></Goods>
                        </swiper-slide>
                    </swiper>
                </div>
                <!--new-product-->
                <div class="new-top">
                    <div class="new-box">
                        <div class="whippletree"></div>
                        <div class="whippletree2"></div>
                        <div class="new-title">HOT PRODUCT</div>
                        <div class="new-title2">
                            <span class="new-title2-left">热销</span>
                            <span class="new-title2-right">产品</span>
                        </div>
                    </div>
                </div>
                <!--hot top-->
                <div id="hot-product">
                    <div class="sofa-box">
                        <div class="kong"></div>
                        <div class="sofa-box-img"><img src="../../assets/image/cys/re1.png" alt=""></div>
                        <div class="sofa-box-title">舒适棉麻 布艺沙发</div>
                        <div class="sofa-box-title2">告别繁琐多余的浮夸 保留实用主义的本质</div>
                        <div class="sofa-box-price">4450<span class="sofa-box-rmb">RMB</span></div>
                        <div class="sofa-box-buy">BUY NOW</div>
                        <ul class="sofa-box-page">
                            <li></li>
                            <li style="width: 0.21rem;height: 0.21rem;background-color: #cecdca;"></li>
                            <li style="background-color: #ffcb3f;"></li>
                        </ul>
                    </div>
                    <div class="sofa-box-two">
                        <div class="box-tow-box" style="margin-right: 0.24rem;">
                            <p class="tow-box-title">FENDI CASA TUDOR</p>
                            <p class="tow-box-title2">现代简约客厅沙发</p>
                            <div class="tow-box--img"><img src="../../assets/image/cys/re2.png" alt=""></div>
                            <div class="tow-box-price">520<span>RMB</span></div>
                            <div class="tow-box-buy">BUY NOW</div>
                            <ul class="tow-box-page">
                                <li></li>
                                <li style="width: 0.18rem;height: 0.18rem;background-color: #97d1d7;"></li>
                                <li style="background-color: #97a0d7;"></li>
                            </ul>
                        </div>
                        <div class="box-tow-box">
                            <p class="tow-box-title">FENDI CASA TUDOR</p>
                            <p class="tow-box-title2">现代简约客厅沙发</p>
                            <div class="tow-box--img"><img src="../../assets/image/cys/re3.png" alt=""></div>
                            <div class="tow-box-price">520<span>RMB</span></div>
                            <div class="tow-box-buy">BUY NOW</div>
                            <ul class="tow-box-page">
                                <li></li>
                                <li style="width: 0.18rem;height: 0.18rem;background-color: #97d1d7;"></li>
                                <li style="background-color: #97a0d7;"></li>
                            </ul>
                        </div>
                    </div>
                    <div class="sofa-box-two">
                        <div class="box-tow-box" style="margin-right: 0.24rem;">
                            <p class="tow-box-title">FENDI CASA TUDOR</p>
                            <p class="tow-box-title2">现代简约客厅沙发</p>
                            <div class="tow-box--img"><img src="../../assets/image/cys/re4.png" alt=""></div>
                            <div class="tow-box-price">520<span>RMB</span></div>
                            <div class="tow-box-buy">BUY NOW</div>
                            <ul class="tow-box-page">
                                <li></li>
                                <li style="width: 0.18rem;height: 0.18rem;background-color: #97d1d7;"></li>
                                <li style="background-color: #97a0d7;"></li>
                            </ul>
                        </div>
                        <div class="box-tow-box">
                            <p class="tow-box-title">FENDI CASA TUDOR</p>
                            <p class="tow-box-title2">现代简约客厅沙发</p>
                            <div class="tow-box--img"><img src="../../assets/image/cys/re5.png" alt=""></div>
                            <div class="tow-box-price">520<span>RMB</span></div>
                            <div class="tow-box-buy">BUY NOW</div>
                            <ul class="tow-box-page">
                                <li></li>
                                <li style="width: 0.18rem;height: 0.18rem;background-color: #97d1d7;"></li>
                                <li style="background-color: #97a0d7;"></li>
                            </ul>
                        </div>
                    </div>
                    <div class="hot-product-more">
                        <div class="product-more-box">
                            <div class="product-more-box-left"></div>
                            <div class="product-more-box-row">查看更多</div>
                            <div class="product-more-box-right"></div>
                        </div>
                    </div>
                </div>
                <!--hot-product-->
                <div class="new-top">
                    <div class="new-box">
                        <div class="whippletree"></div>
                        <div class="whippletree2"></div>
                        <div class="new-title">BRAND STORY</div>
                        <div class="new-title2">
                            <span class="new-title2-left">案例</span>
                            <span class="new-title2-right">展示</span>
                        </div>
                    </div>
                </div>
                <!--case top-->
                <div id="case">
                    <div class="case-box">
                        <img src="../../assets/image/cys/anli1.png" alt="">
                        <div class="case-box-img"><img src="../../assets/image/cys/anli1-1.png" alt=""></div>
                    </div>
                    <div class="case-box-text">
                        <div class="box-text-title">About the chair designer.</div>
                        <div class="box-text-title2">
                            <p>透气性与柔和感并存，</p>
                            <p>像三月的威风，也像五月的阳光，像恋人的热吻，</p>
                            <p>也像傍晚归时的路灯。</p>
                            <p>棉麻的柔软触感，让不大的客厅更加具有安全感，陷阱沙发</p>
                            <p>的温柔里，追剧的日子变得幸福异常。</p>
                        </div>
                        <div class="box-text-more">了解更多</div>
                    </div>
                </div>
                <!--case-->
                <div class="new-top">
                    <div class="new-box">
                        <div class="whippletree"></div>
                        <div class="whippletree2"></div>
                        <div class="new-title" style="margin-left: 0">COMMODITYDETAILS</div>
                        <div class="new-title2">
                            <span class="new-title2-left">品牌</span>
                            <span class="new-title2-right">故事</span>
                        </div>
                    </div>
                </div>
                <!--brand top-->
                <div id="brand">
                    <div class="brand-box">
                        <img src="../../assets/image/cys/pinpai1.png" alt="">
                        <div class="brand-box-row">
                            <div class="brand-box-title">VICOR</div>
                            <div class="brand-box-wipper"></div>
                            <div class="brand-box-title2"> 因为顾家，所以爱家</div>
                            <div class="brand-box-title3">
                                <p>34年沙发制造工艺，保证每一张沙发都拥有出色品质，真材实料,</p>
                                <p>现代设计，让你的家更迷人温馨。</p>
                            </div>
                            <div class="brand-box-img"><img src="../../assets/image/cys/pingpai1-1.png" alt=""></div>
                        </div>
                    </div>
                </div>
                <!--brand -->
            </div>
        </div>
        <my-footer hot="index"></my-footer>
    </div>
</template>
<script>
    import Header from "@/components/Header";
    import Footer from "@/components/Footer";
    import 'swiper/dist/css/swiper.css'
    import {swiper, swiperSlide} from 'vue-awesome-swiper'
    import Goods from "@/components/Goods"
    import BScroll from "better-scroll";
    export default {
        name: "Index",
        data: () => ({
            options: {
                autoplay: true,
                pagination: {
                    el: '.banner-page',
                }
            },
            options2: {
                slidesPerView: 2,
                spaceBetween: 15,
                freeMode: true
            },
            newProduct: [],
            num: 100
        }),
        methods: {
            fetchNewProduct: function () {
                this.$http.get("/api/goods/goods", {
                    params: {
                        page: 1,
                        pageSize: 8
                    }
                }).then(res => {
                    if (res.data.code === 200) {
                        this.newProduct = res.data.data;
                    } else {
                        console.log("获取失败");
                    }
                }).catch(() => {
                    console.log("获取失败");
                })
            },
        },
        components: {
            "my-header": Header,
            "my-footer": Footer,
            swiper,
            swiperSlide,
            Goods
        },
        mounted: function () {
            this.$nextTick(() => {
                new BScroll(this.$refs.wrapper, {
                    click: true
                })
            });
            this.fetchNewProduct();
        }
    }
</script>
<style lang="scss" scoped>
    .wrapper {
        width: 100%;
        height: calc(100% - 0.98rem);
        overflow: hidden;
        position: relative;
    }

    #nav {
        width: 100%;
        height: 0.88rem;
        display: flex;
        justify-content: space-around;
        align-items: center;
        box-shadow: 0 0.04rem 0.08rem rgba(51, 51, 51, 0.45);
    }

    #nav > li {
        width: 1rem;
        height: 0.24rem;
        font-size: 0.24rem;
        color: #000000;
        opacity: 0.7;
    }

    /*nav*/
    #banner {
        width: 100%;
        height: 3.84rem;
        margin-top: 0.05rem;
        position: relative;
    }

    .banner-box {
        width: 100%;
        height: 3.84rem;
    }

    .banner-box > li > img {
        width: 100%;
        height: 3.84rem;
    }

    .banner-box-row {
        width: 4.22rem;
        height: 2rem;
        position: absolute;
        top: 0.87rem;
        left: 0.57rem;
    }

    .banner-row-one {
        width: 4.22rem;
        height: 0.525rem;
        font-size: 0.58rem;
        line-height: 0.525rem;
        letter-spacing: 0.12rem;
        color: #ffcb3f;
    }

    .banner-row-two {
        height: 0.18rem;
        font-size: 0.18rem;
        line-height: 0.18rem;
        letter-spacing: 0.18rem;
        color: #000000;
        margin-top: 0.23rem;
    }

    .banner-row-more {
        width: 1.09rem;
        height: 0.33rem;
        background-color: #ffcb3f;
        border-radius: 0.05rem;
        text-align: center;
        color: #fff;
        margin-top: 0.21rem;
        line-height: 0.33rem;
        font-size: 0.18rem;
        box-shadow: 0.03rem 0.06rem 0.05rem rgba(94, 184, 255, 0.34);
    }

    .banner-page {
        position: absolute;
        bottom: 0.15rem;
        left: 3.07rem;
        width: 0.89rem;
        height: 0.09rem;
        display: flex;
        justify-content: space-between;
        z-index: 99999;
    }

    .banner-page > li {
        width: 0.08rem;
        height: 0.08rem;
        border: solid 1px #f8f8f8;
        border-radius: 50%;
    }

    .banner-page > li.active {
        background: #ffffff;
    }

    /*banner*/
    .new-top {
        width: 100%;
        height: 0.91rem;
        margin: 0.79rem 0 0.57rem 0;
    }

    .new-box {
        width: 1.68rem;
        height: 0.91rem;
        margin: 0 auto;
        text-align: center;
    }

    .whippletree {
        width: 0.58rem;
        height: 0.02rem;
        background-color: #ffcb3f;
    }

    .whippletree2 {
        width: 1.68rem;
        height: 0.02rem;
        background-color: #d7d7d7;
        margin-top: 0.08rem;
    }

    .new-title {
        width: 1.8rem;
        font-size: 0.18rem;
        margin: 0.05rem 0 0 0;
        letter-spacing: 0.01rem;
        color: #000000;
    }

    .new-title2 {
        width: 1.8rem;
        height: 0.31rem;
        font-size: 0.32rem;
        line-height: 0.31rem;
        letter-spacing: 0.02rem;
        color: #000000;
        margin: 0.2rem 0 0;
        text-align: center;
    }

    .new-title2-right {
        color: #ffcb3f;
    }

    /*new top*/

    #new-product {
        width: 6.99rem;
        height: 5.29rem;
        overflow: hidden;
        margin: 0 auto;
    }

    .new-product {
        width: 7.5rem;
        height: 5.46rem;
    }

    .new-product-page {
        width: 90%;
        height: 0.17rem;
        font-size: 0.22rem;
        line-height: 0.17rem;
        letter-spacing: 0.01rem;
        color: #333;
        text-align: right;
    }

    .new-product-page > span {
        color: #ffcb3f;
    }

    .new-product-box {
        margin-top: 0.36rem;
        width: 3.09rem;
        height: 5.11rem;
        background: #ffffff;
        position: relative;
    }

    .product-box-hot {
        position: absolute;
        top: -0.18rem;
        left: 0.18rem;
        width: 0.45rem;
        height: 0.55rem;

    }

    .product-box-hot > img {
        width: 0.45rem;
        height: 0.55rem;
    }

    .product-box-img {
        width: 3.09rem;
        height: 2.89rem;
        overflow: hidden;
    }

    .product-box-img > img {
        width: 4.79rem;
        height: 2.89rem;
    }

    .product-box-whipp {
        width: 0.27rem;
        height: 0.02rem;
        background-color: #000000;
        margin: 0.2rem 0 0 0.17rem;
    }

    .product-box-verfo {
        width: 0.86rem;
        height: 0.14rem;
        font-size: 0.18rem;
        line-height: 0.14rem;
        letter-spacing: 0.01rem;
        color: #000000;
        margin: 0.08rem 0 0 0.17rem;
        opacity: 0.8;
    }

    .product-box-title {
        width: 2.53rem;
        height: 0.24rem;
        font-size: 0.12rem;
        line-height: 0.24rem;
        letter-spacing: 0.01rem;
        color: #000000;
        margin: 0.1rem 0 0 0.17rem;
    }

    .product-price {
        float: left;
        margin: 0.91rem 0 0 0.17rem;
        width: 1rem;
        height: 0.21rem;
        line-height: 0.21rem;
        letter-spacing: -0.01rem;
    }

    .product-rmb-num {
        font-size: 0.26rem;
        color: #000000;
    }

    .product-rmb-rmb {
        font-size: 0.18rem;
        color: #000000;
    }

    .product-buy-box {
        width: 1.46rem;
        height: 0.43rem;
        background: #ffcb3f;
        border-radius: 0.04rem;
        float: right;
        margin: 0.79rem 0.23rem 0.23rem;
        line-height: 0.43rem;
    }

    .product-buy-box .iconfont {
        font-size: 0.22rem;
        color: #ffffff;
        margin-left: 0.12rem;
    }

    .product-buy {
        font-size: 0.22rem;
        letter-spacing: 0.01rem;
        color: #ffffff;
        margin-left: 0.02rem;
    }

    /*new-product*/

    #hot-product {

    }

    .sofa-box {
        width: 6.99rem;
        height: 6.93rem;
        background-color: #ffffff;
        margin: 0 auto;
        position: relative;
    }

    .kong {
        height: 1.11rem;
    }

    .sofa-box-img {
        width: 6.25rem;
        height: 2.62rem;
        margin: 0 auto;
    }

    .sofa-box-img > img {
        width: 6.25rem;
        height: 2.62rem;
    }

    .sofa-box-title {
        width: 2.7rem;
        height: 0.31rem;
        font-size: 0.31rem;
        letter-spacing: 0.01rem;
        color: #000000;
        margin: 0.57rem 0 0 0.6rem;
    }

    .sofa-box-title2 {
        width: 3.9rem;
        height: 0.21rem;
        font-size: 0.2rem;
        letter-spacing: 0.01rem;
        color: #000000;
        margin: 0.14rem 0 0 0.6rem;
    }

    .sofa-box-price {
        width: 1.15rem;
        height: 0.22rem;
        margin: 1rem 0 0 0.6rem;
        font-size: 0.3rem;
        letter-spacing: 0.02rem;
        color: #000000;
    }

    .sofa-box-rmb {
        font-size: 0.18rem;
        letter-spacing: 0.01rem;
        color: #000000;
        opacity: 0.8;
    }

    .sofa-box-buy {
        width: 0.98rem;
        height: 0.14rem;
        font-size: 0.18rem;
        color: #000000;
        margin: 0.13rem 0 0 0.6rem;
    }

    .sofa-box-page {
        position: absolute;
        right: 0.81rem;
        bottom: 1.11rem;
        height: 1.05rem;
        width: 0.21rem;
        display: flex;
        justify-content: space-around;
        flex-wrap: wrap;
    }

    .sofa-box-page > li {
        width: 0.16rem;
        height: 0.16rem;
        border-radius: 50%;
        background-color: #abe3e6;
    }

    .sofa-box-two {
        width: 6.99rem;
        height: 4.16rem;
        margin: 0.22rem auto;
        position: relative;
        display: flex;
        justify-content: space-between;
        flex-wrap: nowrap;
    }

    .box-tow-box {
        width: 3.38rem;
        height: 4.16rem;
        background-color: #ffffff;
        position: relative;
    }

    .tow-box-title {
        width: 2.13rem;
        height: 0.18rem;
        font-size: 0.18rem;
        color: #000000;
        margin: 0.19rem 0 0 0.45rem;
        opacity: 0.8;
    }

    .tow-box-title2 {
        width: 2.2rem;
        height: 0.38rem;
        font-size: 0.26rem;
        letter-spacing: 0.01rem;
        color: #000000;
        margin: 0.19rem 0 0 0.45rem;
    }

    .tow-box--img {
        width: 1.8rem;
        height: 1.62rem;
        margin: 0.48rem 0 0 0.42rem;
    }

    .tow-box--img > img {
        width: 1.8rem;
        height: 1.62rem;
    }

    .tow-box-price {
        width: 0.88rem;
        height: 0.21rem;
        font-size: 0.26rem;
        letter-spacing: 0.01rem;
        color: #000000;
        margin: 0.37rem 0 0 0.42rem;
    }

    .tow-box-price > span {
        font-size: 0.18rem;
        letter-spacing: 0.01rem;
        color: #000000;
    }

    .tow-box-buy {
        width: 1.2rem;
        height: 0.15rem;
        font-size: 0.14rem;
        color: #000000;
        margin: 0.09rem 0 0 0.42rem;
    }

    .tow-box-page {
        position: absolute;
        right: 0.36rem;
        bottom: 0.63rem;
        height: 0.8rem;
        width: 0.18rem;
        display: flex;
        justify-content: space-around;
        flex-wrap: wrap;
    }

    .tow-box-page > li {
        width: 0.14rem;
        height: 0.14rem;
        background-color: #efd28e;
        border-radius: 50%;
    }

    .hot-product-more {
        width: 100%;
        height: 0.19rem;
        margin-top: 0.38rem;
    }

    .product-more-box {
        width: 3.77rem;
        height: 0.19rem;
        margin: 0 auto;
        text-align: center;
    }

    .product-more-box-left {
        width: 1.13rem;
        height: 0.02rem;
        border: solid 1px #d9d9d9;
        float: left;
    }

    .product-more-box-row {
        height: 0.19rem;
        font-size: 0.18rem;
        color: #333;
        float: left;
        margin-left: 0.4rem;
        line-height: 0.19rem;
    }

    .product-more-box-right {
        width: 1.13rem;
        height: 0.02rem;
        border: solid 1px #d9d9d9;
        float: right;
    }

    /*hot-product*/
    #case {
        width: 100%;
        height: 8rem;
    }

    .case-box {
        width: 7.02rem;
        height: 4.38rem;
        margin: 0 auto;
        position: relative;
    }

    .case-box > img {
        width: 7.02rem;
        height: 4.38rem;
    }

    .case-box-img {
        width: 1.28rem;
        height: 1.31rem;
        position: absolute;
        left: 2.86rem;
        top: 1.48rem;
    }

    .case-box-img > img {
        width: 1.28rem;
        height: 1.31rem;
    }

    .case-box-text {
        width: 6.6rem;
        height: 3.16rem;
        margin: 0.41rem auto 0;
        text-align: center;
    }

    .box-text-title {
        width: 6.6rem;
        height: 0.26rem;
        font-size: 0.28rem;
        line-height: 0.26rem;
        color: #000000;
    }

    .box-text-title2 {
        width: 6.6rem;
        height: 1.68rem;
        font-size: 0.24rem;
        line-height: 0.36rem;
        letter-spacing: 0.01rem;
        color: #000000;
        opacity: 0.8;
        margin-top: 0.28rem;
    }

    .box-text-more {
        width: 1.4rem;
        height: 0.6rem;
        border-radius: 0.3rem;
        border: solid 0.01rem #fbca4a;
        font-size: 0.18rem;
        line-height: 0.6rem;
        color: #000000;
        text-align: center;
        margin: 0.34rem auto 0;
        opacity: 0.8;
    }

    /*case*/
    #brand {
        width: 100%;
        height: 5rem;
    }

    .brand-box {
        width: 7.5rem;
        height: 3.34rem;
        margin: 0 auto;
        position: relative;
    }

    .brand-box > img {
        width: 7.5rem;
        height: 3.34rem;
    }

    .brand-box-row {
        position: absolute;
        left: 1.1rem;
        top: 0.83rem;
        width: 5.5rem;
        height: 1.98rem;
    }

    .brand-box-title {
        width: 0.96rem;
        height: 0.22rem;
        font-size: 0.3rem;
        color: #ffffff;
        margin: 0 auto;
    }

    .brand-box-wipper {
        width: 0.78rem;
        height: 0.02rem;
        background-color: #fbca4a;
        margin: 0.14rem auto 0;
    }

    .brand-box-title2 {
        width: 2.5rem;
        height: 0.29rem;
        font-size: 0.24rem;
        color: #ffffff;
        margin: 0.15rem auto 0;
    }

    .brand-box-title3 {
        width: 5.5rem;
        height: 0.5rem;
        font-size: 0.18rem;
        color: #ffffff;
        opacity: 0.6;
        margin: 0.15rem auto 0;
        text-align: center;
    }

    .brand-box-img {
        width: 0.18rem;
        height: 0.15rem;
        margin: 0.2rem auto;
    }

    .brand-box-img > img {
        width: 0.18rem;
        height: 0.15rem;
        display: block;
        -webkit-animation: rightan 1s infinite;
        -webkit-animation-fill-mode: both;
    }

    @-webkit-keyframes rightan {

        from {
            bottom: 0;
            opacity: 0;
        }
        to {
            bottom: 5%;
            opacity: 1;
        }
    }

    /*brand */


</style>