<template>
    <div>
        <my-header></my-header>
        <div class="title">
            <div class="text">
                <div id="hot">热卖商品</div>
                <ul id="commodity">
                    <li class="commodity-title">
                        <div class="img"><img src="../../assets/image/chy/5.2.png" alt=""></div>
                        <div class="wire"></div>
                        <div class="verfo-lab"><p>VERFO LAB </p>
                            <p style="font-size: 0.24rem;font-weight: bold">现代简约时尚布艺沙发</p></div>
                        <div class="commodity-bottom">
                            <div class="buy"><span style="font-size: 0.26rem;font-weight: bold">800</span><span
                                    style="font-size: 0.18rem">RMB</span></div>
                            <div class="add"><span style="font-size:0.16rem;line-height: 0.22rem">&#xe601;</span><span
                                    style="font-size: 0.2rem;color: #ffffff;line-height: 0.22rem">点击购买</span></div>
                        </div>
                    </li>
                    <li class="commodity-title">
                        <div class="img"><img src="../../assets/image/chy/5.6.png" alt=""></div>
                        <div class="wire"></div>
                        <div class="verfo-lab"><p>VERFO LAB </p>
                            <p style="font-size: 0.24rem;font-weight: bold">现代简约时尚布艺沙发</p></div>
                        <div class="commodity-bottom">
                            <div class="buy"><span style="font-size: 0.26rem;font-weight: bold">800</span><span
                                    style="font-size: 0.18rem">RMB</span></div>
                            <div class="add"><span style="font-size:0.16rem;line-height: 0.22rem">&#xe601;</span><span
                                    style="font-size: 0.2rem;color: #ffffff;line-height: 0.22rem">点击购买</span></div>
                        </div>
                    </li>
                    <li class="commodity-title">
                        <div class="img"><img src="../../assets/image/chy/5.1.png" alt=""></div>
                        <div class="wire"></div>
                        <div class="verfo-lab"><p>VERFO LAB </p>
                            <p style="font-size: 0.24rem;font-weight: bold">现代简约时尚布艺沙发</p></div>
                        <div class="commodity-bottom">
                            <div class="buy"><span style="font-size: 0.26rem;font-weight: bold">800</span><span
                                    style="font-size: 0.18rem">RMB</span></div>
                            <div class="add"><span style="font-size:0.16rem;line-height: 0.22rem">&#xe601;</span><span
                                    style="font-size: 0.2rem;color: #ffffff;line-height: 0.22rem">点击购买</span></div>
                        </div>
                    </li>
                    <li class="commodity-title">
                        <div class="img"><img src="../../assets/image/chy/5.4.png" alt=""></div>
                        <div class="wire"></div>
                        <div class="verfo-lab"><p>VERFO LAB </p>
                            <p style="font-size: 0.24rem;font-weight: bold">现代简约时尚布艺沙发</p></div>
                        <div class="commodity-bottom">
                            <div class="buy"><span style="font-size: 0.26rem;font-weight: bold">800</span><span
                                    style="font-size: 0.18rem">RMB</span></div>
                            <div class="add"><span style="font-size:0.16rem;line-height: 0.22rem">&#xe601;</span><span
                                    style="font-size: 0.2rem;color: #ffffff;line-height: 0.22rem">点击购买</span></div>
                        </div>
                    </li>
                    <li class="commodity-title">
                        <div class="img"><img src="../../assets/image/chy/5.10.png" alt=""></div>
                        <div class="wire"></div>
                        <div class="verfo-lab"><p>VERFO LAB </p>
                            <p style="font-size: 0.24rem;font-weight: bold">现代简约时尚布艺沙发</p></div>
                        <div class="commodity-bottom">
                            <div class="buy"><span style="font-size: 0.26rem;font-weight: bold">800</span><span
                                    style="font-size: 0.18rem">RMB</span></div>
                            <div class="add"><span style="font-size:0.16rem;line-height: 0.22rem">&#xe601;</span><span
                                    style="font-size: 0.2rem;color: #ffffff;line-height: 0.22rem">点击购买</span></div>
                        </div>
                    </li>
                    <li class="commodity-title">
                        <div class="img"><img src="../../assets/image/chy/5.11.png" alt=""></div>
                        <div class="wire"></div>
                        <div class="verfo-lab"><p>VERFO LAB </p>
                            <p style="font-size: 0.24rem;font-weight: bold">现代简约时尚布艺沙发</p></div>
                        <div class="commodity-bottom">
                            <div class="buy"><span style="font-size: 0.26rem;font-weight: bold">800</span><span
                                    style="font-size: 0.18rem">RMB</span></div>
                            <div class="add"><span style="font-size:0.16rem;line-height: 0.22rem">&#xe601;</span><span
                                    style="font-size: 0.2rem;color: #ffffff;line-height: 0.22rem">点击购买</span></div>
                        </div>
                    </li>
                    <li class="commodity-title">
                        <div class="img"><img src="../../assets/image/chy/5.6.png" alt=""></div>
                        <div class="wire"></div>
                        <div class="verfo-lab"><p>VERFO LAB </p>
                            <p style="font-size: 0.24rem;font-weight: bold">现代简约时尚布艺沙发</p></div>
                        <div class="commodity-bottom">
                            <div class="buy"><span style="font-size: 0.26rem;font-weight: bold">800</span><span
                                    style="font-size: 0.18rem">RMB</span></div>
                            <div class="add"><span style="font-size:0.16rem;line-height: 0.22rem">&#xe601;</span><span
                                    style="font-size: 0.2rem;color: #ffffff;line-height: 0.22rem">点击购买</span></div>
                        </div>
                    </li>
                    <li class="commodity-title">
                        <div class="img"><img src="../../assets/image/chy/5.2.png" alt=""></div>
                        <div class="wire"></div>
                        <div class="verfo-lab"><p>VERFO LAB </p>
                            <p style="font-size: 0.24rem;font-weight: bold">现代简约时尚布艺沙发</p></div>
                        <div class="commodity-bottom">
                            <div class="buy"><span style="font-size: 0.26rem;font-weight: bold">800</span><span
                                    style="font-size: 0.18rem">RMB</span></div>
                            <div class="add"><span style="font-size:0.16rem;line-height: 0.22rem">&#xe601;</span><span
                                    style="font-size: 0.2rem;color: #ffffff;line-height: 0.22rem">点击购买</span></div>
                        </div>
                    </li>
                    <li class="commodity-title">
                        <div class="img"><img src="../../assets/image/chy/5.2.png" alt=""></div>
                        <div class="wire"></div>
                        <div class="verfo-lab"><p>VERFO LAB </p>
                            <p style="font-size: 0.24rem;font-weight: bold">现代简约时尚布艺沙发</p></div>
                        <div class="commodity-bottom">
                            <div class="buy"><span style="font-size: 0.26rem;font-weight: bold">800</span><span
                                    style="font-size: 0.18rem">RMB</span></div>
                            <div class="add"><span style="font-size:0.16rem;line-height: 0.22rem">&#xe601;</span><span
                                    style="font-size: 0.2rem;color: #ffffff;line-height: 0.22rem">点击购买</span></div>
                        </div>
                    </li>
                    <li class="commodity-title bottom">
                        <div class="img"><img src="../../assets/image/chy/5.2.png" alt=""></div>
                        <div class="wire"></div>
                        <div class="verfo-lab"><p>VERFO LAB </p>
                            <p style="font-size: 0.24rem;font-weight: bold">现代简约时尚布艺沙发</p></div>
                        <div class="commodity-bottom">
                            <div class="buy"><span style="font-size: 0.26rem;font-weight: bold">800</span><span
                                    style="font-size: 0.18rem">RMB</span></div>
                            <div class="add"><span style="font-size:0.16rem;line-height: 0.22rem">&#xe601;</span><span
                                    style="font-size: 0.2rem;color: #ffffff;line-height: 0.22rem">点击购买</span></div>
                        </div>
                    </li>
                </ul>
            </div>
        </div>
        <my-footer></my-footer>
    </div>
</template>

<script>
    import Header from "@/components/Header";
    import Footer from "@/components/Footer";

    export default {
        name: "Hot",
        data: () => ({}),
        components: {
            "my-header": Header,
            "my-footer": Footer,
        }
    }
</script>

<style lang="scss" scoped>
    .title {
        width: 100%;
        height: auto;
        background: #f8f8f8;
        padding: 0.6rem 0.24rem;
    }

    .text {
        width: 6.92rem;
        /*height: 3.88rem;*/
    }

    .hot {
        width: 1.5rem;
        height: auto;
        border-left: 0.01rem solid orange;
        text-align: center;
    }


    .shop {
        width: 1.49rem;
        height: 0.6rem;
        background-color: #efefef;
        border-radius: 0.3rem;
        display: inline-block;
        text-align: center;
        line-height: 0.6rem;
        margin-top: 0.2rem;
    }

    #commodity {
        width: 100%;
        height: auto;
        background: #f6f6f6;
        display: flex;
        justify-content: space-around;
        flex-wrap: wrap;
        margin-top: 0.2rem;
    }

    .commodity-title {
        width: 3.3rem;
        height: 5.09rem;
        background-color: white;
        margin-bottom: 0.2rem;
    }

    .img {
        width: 3.3rem;
        height: 3.18rem;
    }

    .img img {
        width: 3.3rem;
        height: 3.18rem;
    }

    .wire {
        width: 0.32rem;
        height: 0.03rem;
        background-color: #000000;
        margin-left: 0.23rem;
        margin-top: 0.24rem;
    }

    .verfo-lab {
        width: 2.4rem;
        height: 0.46rem;
        font-family: ArialNarrow;
        font-size: 0.18rem;
        font-weight: normal;
        font-stretch: normal;
        line-height: 0.2rem;
        letter-spacing: 0rem;
        color: #000000;
        margin-top: 0.1rem;
    }

    .buy {
        width: auto;
        height: 0.44rem;
        line-height: 0.44rem;
        text-align: center;
        float: left;
    }

    .add {
        width: 1.53rem;
        height: 0.44rem;
        background-color: #ffcb3f;
        border-radius: 0.04rem;
        float: right;
        padding: 0.12rem 0.19rem 0.1rem 0.23rem;
        font-family: iconfont;
    }

    .commodity-bottom {
        width: 100%;
        height: 0.44rem;
        padding: 0 .22rem;
        margin-top: 0.45rem;
    }

    #hot {
        font-size: 0.3rem;
        text-align: center;
        font-weight: bold;
        margin-top: -0.2rem;
        margin-bottom: 0.4rem;
    }

    .bottom {
        margin-bottom: 1rem;
    }

</style>