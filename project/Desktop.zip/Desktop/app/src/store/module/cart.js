export default {
    state: {
        orderList: []  //所有订单
    },
    getters: {   //计算属性
        //所有订单
        orderList(state) {
            return state.orderList
        },
        //购物车列表
        cartList(state) {
            return state.orderList.filter(v => v.state === 0);
        },
        //待发货列表
        sendList(state) {
            return state.orderList.filter(v => v.state === 1);
        },
        //待收货列表
        getList(state) {
            return state.orderList.filter(v => v.state === 2);
        },
        //待评价列表
        commentList(state) {
            return state.orderList.filter(v => v.state === 3);
        },
        //待退货列表
        backList(state) {
            return state.orderList.filter(v => v.state === 4);
        },
        //购物车中的商品种类
        cartLength(state, getters) {
            return getters.cartList.length;
        },
        //判断当前订单当中有没有某个商品
        hasSomeGoods(state, getters) {
            return (id) => {
                let obj = getters.cartList.find(obj =>
                    1 * obj.gid === id * 1);
                if (obj) {
                    return obj;
                } else {
                    return false;
                }
            }
        },
        //需要结算的订单
        payList(state) {
            return state.orderList.filter(v => v.checked);
        }
    },
    mutations: {
        add(state, payload) {
            state.orderList.push(payload);
        },
        remove(state, payload) {
            let index = state.orderList.findIndex((obj) => {
                if (1 * obj.gid === 1 * payload.id) {
                    return true;
                }
            });
            state.orderList.splice(index, 1);
        },
        concat(state, payload) {
            //payload 从数据库中获取到的当前用户的订单信息
            //orderList 当前用户向购物车中添加的信息
            payload = payload.filter(function (v) {
                //  v 数据库中当前用户的每一个订单
                let r = state.orderList.find(function (val) {
                    //val vuex当前用户的每一个订单
                    return val.gid == v.gid && val.state == v.state
                });
                if (r) {
                    return false;
                } else {
                    return true;
                }
            });
            state.orderList = [...state.orderList, ...payload];
        }
    },
    actions: {}
}