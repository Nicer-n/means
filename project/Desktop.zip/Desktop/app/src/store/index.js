// 核心引入
import Vue from 'vue'
import Vuex from 'vuex'
// 根级别的 action和mutation引入
import mutations from "./mutations"
import actions from "./action"
// 其它模块的引入
import cart from "./module/cart"

Vue.use(Vuex);
export default new Vuex.Store({
    state:{},
    getters:{},
    mutations,
    actions,
    modules:{
      cart
    }
})
