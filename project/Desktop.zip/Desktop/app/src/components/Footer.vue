<template>
     <div id="footer">
            <div class="footer-box">
                <router-link to="/index">
                    <div class="footer-box-row">
                        <div class="footer-img"><i :class="['iconfont', 'icon-shouye',{active:hot==='index'}]"></i></div>
                        <div :class="['footer-title',{active:hot==='index'}]">首页</div>
                    </div>
                </router-link>
                <router-link to="/category">
                    <div class="footer-box-row">
                        <div class="footer-img"><i :class="['iconfont', 'icon-leimupinleifenleileibie',{active:hot==='category'}]"></i></div>
                        <div :class="['footer-title',{active:hot==='category'}]">分类</div>
                    </div>
                </router-link>
                <router-link to="/shoppingcar">
                    <div class="footer-box-row">
                        <div class="footer-img"><i :class="['iconfont', 'icon-gouwuchekong',{active:hot==='shoppingcar'}]"></i></div>
                        <div :class="['footer-title',{active:hot==='shoppingcar'}]">购物车</div>
                    </div>
                </router-link>
                <router-link to="/my">
                    <div class="footer-box-row">
                        <div class="footer-img"><i :class="['iconfont', 'icon-Icon_wode',{active:hot==='my'}]"></i></div>
                        <div :class="['footer-title',{active:hot==='my'}]">我的</div>
                    </div>
                </router-link>
            </div>
        </div>
</template>

<script>
    export default {
        name: "Footer",
        data: () => ({}),
        props:{
            hot:{
               type:String,
               required:true
            }
        }
    }
</script>

<style lang="scss" scoped>
    @import "../assets/font.css";
    #footer {
        width: 100%;
        height: 0.98rem;
        position: fixed;
        bottom: 0;
        left:0;
        z-index:9999999999;
    }

    .footer-box {
        width: 7.5rem;
        height: 0.98rem;
        background-color: #fafafa;
        border: solid 0.01rem #bfbfbf;
        margin: 0 auto;
        display: flex;
        justify-content: space-around;
    }

    .footer-box-row {
        float: left;
        height: 0.79rem;
        margin-top: 0.14rem;
        text-align: center;
    }

    .footer-img {
        margin: 0 auto;
    }

    .footer-img > .iconfont {
        font-size: 0.38rem;
    }

    .footer-img > .iconfont.active {
        color: #ffac13;
    }

    .footer-title {
        height: 0.2rem;
        font-size: 0.2rem;
        line-height: 0.2rem;
        letter-spacing: 0.01rem;
        margin-top: 0.09rem;
        color: #333;
    }

    .footer-title.active {
        color: #ffcb3f;
    }

</style>