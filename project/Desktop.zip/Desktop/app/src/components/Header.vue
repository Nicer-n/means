<template>
    <div id="top">
        <slot>
            <div class="back"></div>
        </slot>
        <img src=".././assets/image/cys/vicor.png" alt="" class="vicor">
        <img src=".././assets/image/cys/10.2.png" alt="" class="more" @click="$router.push({name:'index'})">
    </div>

</template>

<script>
    export default {
        name: "Header",
        data: () => ({})
    }
</script>

<style lang="scss" scoped>
    #top {
        width: 100%;
        height: 0.88rem;
        border-bottom: 1px solid #ccc;
        display: flex;
        justify-content: space-between;
        align-items: center;
        position: fixed;
        top:0;
        left:0;
        background:#fff;
        z-index:9999999;
    }

    .back {
        width: 0.23rem;
        height: 0.23rem;
        margin-left:0.5rem;
    }

    .vicor {
        width: 0.92rem;
        height: 0.3rem;
        color: #000000;
    }

    .more {
        width: 0.36rem;
        height: 0.08rem;
        margin-right:0.5rem;
    }

</style>