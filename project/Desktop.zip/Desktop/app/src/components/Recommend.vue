<template>
    <div>
        <div class="hot-one" v-if="showTitle">
            推荐商品
        </div>
        <ul id="commodity">
            <Goods
                    v-for="item in goods"
                    :key="item.id"
                    :item="item"
            ></Goods>
        </ul>
    </div>
</template>
<script>
    import Goods from "./Goods";
    export default {
        name: "Recommend",
        data: () => ({
        }),
        props:{
            goods:{
                type:Array,
                required:true
            },
            showTitle:{
                type:Boolean,
                default:true
            }
        },
        components: {
            Goods
        },
    }
</script>

<style lang="scss" scoped>

    .hot {
        width: 1.5rem;
        height: auto;
        border-left: 0.01rem solid orange;
        text-align: center;
    }

    .hot-one {
        width: 1.5rem;
        height: auto;
        border-left: 0.01rem solid orange;
        text-align: center;
        margin-top: 0.47rem;
    }

    #commodity {
        width: 100%;
        height: auto;
        background: #f6f6f6;
        overflow: hidden;
        margin-top: 0.47rem;
    }

</style>