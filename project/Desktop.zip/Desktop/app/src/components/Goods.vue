<template>
    <li class="commodity-title" @click="$router.push({name:'content',query:{id:item.id}})">
        <div class="img"><img :src="item.thumb" alt=""></div>
        <div class="wire"></div>
        <div class="verfo-lab"><p>{{item.name_en}} </p>
            <p style="font-size: 0.24rem;font-weight: bold">{{item.name_ch}}</p></div>
        <div class="commodity-bottom">
            <div class="buy"><span style="font-size: 0.26rem;font-weight: bold">{{item.price}}</span><span
                    style="font-size: 0.18rem">RMB</span></div>
            <div class="add"><span style="font-size:0.16rem;line-height: 0.22rem">&#xe601;</span><span
                    style="font-size: 0.2rem;color: #ffffff;line-height: 0.22rem">点击购买</span></div>
        </div>
    </li>
</template>

<script>
    export default {
        name: "Goods",
        data: () => ({}),
        props:{
           item:{
               type:Object,
               required:true
           }
        }
    }
</script>

<style lang="scss" scoped>

    .commodity-title {
        width:3.75rem;
        height:5.3rem;
        padding-bottom: 0.2rem;
        margin-bottom: 0.2rem;
        float:left;
        background:#fff;
    }

    .img {
        width: 3.3rem;
        height: 3.18rem;
        display: block;
        margin:0 auto;
    }

    .img img {
        width: 3.3rem;
        height: 3.18rem;
    }

    .wire {
        width: 0.32rem;
        height: 0.03rem;
        background-color: #000000;
        margin-left: 0.23rem;
        margin-top: 0.24rem;
    }

    .verfo-lab {
        width: 2.8rem;
        height: 0.66rem;
        font-family: ArialNarrow;
        font-size: 0.18rem;
        font-weight: normal;
        font-stretch: normal;
        line-height: 0.33rem;
        color: #000000;
        margin-top: 0.1rem;
        padding-left:0.23rem;
    }

    .buy {
        width: auto;
        height: 0.44rem;
        line-height: 0.44rem;
        text-align: center;
        float: left;
    }

    .add {
        width: 1.53rem;
        height: 0.44rem;
        background-color: #ffcb3f;
        border-radius: 0.04rem;
        float: right;
        font-family: iconfont;
        display: flex;
        justify-content: space-around;
        align-items: center;
    }

    .commodity-bottom {
        width: 100%;
        height: 0.44rem;
        padding: 0 .22rem;
        margin-top: 0.45rem;
    }
</style>