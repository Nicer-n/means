import Vue from 'vue'
import App from './App.vue'
import router from './router'
import store from './store/index.js'
import Axios from 'axios'

Vue.config.productionTip = false;
Vue.prototype.$http = Axios;
// 添加请求拦截器
Axios.interceptors.request.use(function (config) {
    // 在发送请求之前做些什么
    if(localStorage.token) {
        config.headers = {
            'x-access-token': localStorage.token
        };
    }
    return config;
}, function (error) {
    // 对请求错误做些什么
    return Promise.reject(error);
});
// 添加响应拦截器
Axios.interceptors.response.use(function (response) {
    // 对响应数据做点什么
    if(response.data.msg==="token验证失败"){
       localStorage.to="index";
       router.push({name:"login"});
    }
    return response;
}, function (error) {
    // 对响应错误做点什么
    return Promise.reject(error);
});
// 路由导航守卫
router.beforeEach((to, from, next) => {
    if(to.name==="shoppingcar"||to.name==="order"||to.name==="my"){
        if(localStorage.login){
            next();
        }else{
            localStorage.to=to.name;
            next("/login");
        }
    }else{
       next();
    }
});
new Vue({
    router,
    store,
    render: h => h(App)
}).$mount('#app')
