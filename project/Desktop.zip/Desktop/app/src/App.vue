<template>
    <div id="app">
        <transition name="fade">
           <router-view></router-view>
        </transition>
    </div>
</template>
<style lang="scss">
    .fade-enter-active, .fade-leave-active {
        transition: opacity .5s;
    }
    .fade-enter, .fade-leave-to /* .fade-leave-active below version 2.1.8 */ {
        opacity: 0;
    }
    #app {
        font-family: 'Avenir', Helvetica, Arial, sans-serif;
        -webkit-font-smoothing: antialiased;
        -moz-osx-font-smoothing: grayscale;
        /*text-align: center;*/
        color: #2c3e50;
        height:100%;
    }
    * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
    }

    ul {
        list-style: none;
    }

    a {
        text-decoration: none;
        list-style: none;
        color: inherit;
    }

    i {
        font-style: normal;
    }

    html {
        width:100%;
        height:100%;
        overflow-x: hidden;
    }

    body {
        font-size: 12px;
        width:100%;
        height:100%;
        overflow-x: hidden;
        padding-top:0.88rem;
    }

    @media (min-width: 320px) {
        html {
            font-size: 42.666667px;
        }
    }

    @media (min-width: 360px) {
        html {
            font-size: 48px;
        }
    }

    @media (min-width: 375px) {
        html {
            font-size: 50px;
        }
    }

    @media (min-width: 414px) {
        html {
            font-size: 55.2px;
        }
    }

    input:focus{
        outline: none;
    }
</style>
