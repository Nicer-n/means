import Vue from 'vue'
import Router from 'vue-router'

import Index from '@/views/index/Index';
import Hot from '@/views/index/Hot';


import Category from '@/views/goods/Category';
import Address from '@/views/goods/Address';
import Content from '@/views/goods/Content';
import Order from '@/views/goods/Order';
import Pay from '@/views/goods/Pay';
import PayResult from '@/views/goods/PayResult';
import ShoppingCar from '@/views/goods/ShoppingCar';
import Collect from '@/views/goods/Collect';
import Search from '@/views/goods/Search';
import ResultList from '@/views/goods/ResultList';

import PerAddress from '@/views/personal/Address';
import Comments from '@/views/personal/Comments';
import Login from '@/views/personal/Login';
import My from '@/views/personal/My';
import OrderList from '@/views/personal/OrderList';
import Path from '@/views/personal/Path';
import Profile from "./views/personal/Profile";
import Sign from "./views/personal/Sign";



Vue.use(Router)

export default new Router({
    routes: [
        {
            path: '/',
            redirect: '/index'
        },
        {
            path: '/index',
            name: 'index',
            component: Index,
        },
        {
            path: '/hot',
            name: 'hot',
            component:Hot,
        },
        {
            path: '/search',
            name: 'search',
            component:Search,
        },
        {
            path: '/resultlist',
            name: 'resultlist',
            component:ResultList,
        },

        {
            path: '/category',
            name: 'category',
            component:Category,
        },
        {
            path: '/address',
            name: 'address',
            component:Address,
        },
        {
            path: '/content',
            name: 'content',
            component:Content,
        },
        {
            path: '/order',
            name: 'order',
            component:Order,
        },
        {
            path: '/pay',
            name: 'pay',
            component:Pay,
        },
        {
            path: '/payresult',
            name: 'payresult',
            component:PayResult,
        },
        {
            path: '/shoppingcar',
            name: 'shoppingcar',
            component:ShoppingCar,
        },
        {
            path: '/collect',
            name: 'collect',
            component:Collect,
        },

        {
            path: '/peraddress',
            name: 'peraddress',
            component:PerAddress,
        },
        {
            path: '/comments',
            name: 'comments',
            component:Comments,
        },
        {
            path: '/login',
            name: 'login',
            component:Login,
        },
        {
            path: '/my',
            name: 'my',
            component:My,
        },
        {
            path: '/orderlist',
            name: 'orderlist',
            component:OrderList,
        },
        {
            path: '/path',
            name: 'path',
            component:Path,
        },
        {
            path: '/profile',
            name: 'profile',
            component:Profile,
        },
        {
            path: '/sign',
            name: 'sign',
            component:Sign,
        },





    ]
})
