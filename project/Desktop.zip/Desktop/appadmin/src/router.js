import Vue from 'vue'
import Router from 'vue-router'
const UserShow = () => import(/* webpackChunkName: "users" */ '@/views/UserShow');
const UserAdd = () => import(/* webpackChunkName: "users" */ '@/views/UserAdd');
const UserEdit = () => import(/* webpackChunkName: "users" */ '@/views/UserEdit');
const TypeShow = () => import(/* webpackChunkName: "type" */ '@/views/TypeShow');
const TypeAdd = () => import(/* webpackChunkName: "type" */ '@/views/TypeAdd');
const TypeEdit = () => import(/* webpackChunkName: "type" */ '@/views/TypeEdit');
const GoodsShow = () => import(/* webpackChunkName: "goods" */ '@/views/GoodsShow');
const GoodsAdd = () => import(/* webpackChunkName: "goods" */ '@/views/GoodsAdd');
const GoodsEdit = () => import(/* webpackChunkName: "goods" */ '@/views/GoodsEdit');
const CommentsShow = () => import(/* webpackChunkName: "comments" */ '@/views/CommentsShow');
const CommentsEdit = () => import(/* webpackChunkName: "comments" */ '@/views/CommentsEdit');
const Password = () => import(/* webpackChunkName: "admin" */ '@/views/AdminPasswordChange');
const AdminShow = () => import(/* webpackChunkName: "admin" */ '@/views/AdminShow');
const AdminAdd = () => import(/* webpackChunkName: "admin" */ '@/views/AdminAdd');
const AdminEdit = () => import(/* webpackChunkName: "admin" */ '@/views/AdminEdit');

Vue.use(Router);
export default new Router({
  routes: [
      {
         path:"/userShow",
         name:"usershow",
         component:UserShow
      },
      {
          path:"/userAdd",
          name:"useradd",
          component:UserAdd
      },
      {
          path:"/userEdit/:id",
          name:"useredit",
          component:UserEdit
      },
      {
          path:"/typeShow",
          name:"typeshow",
          component:TypeShow
      },
      {
          path:"/typeAdd",
          name:"typeadd",
          component:TypeAdd
      },
      {
          path:"/typeEdit/:id",
          name:"typeedit",
          component:TypeEdit
      },
      {
          path:"/goodsShow",
          name:"goodsshow",
          component:GoodsShow
      },
      {
          path:"/goodsAdd",
          name:"goodsadd",
          component:GoodsAdd
      },
      {
          path:"/goodsEdit/:id",
          name:"goodsedit",
          component:GoodsEdit
      },
      {
          path:"/commentsShow",
          name:"commentsshow",
          component:CommentsShow
      },
      {
          path:"/commentsEdit/:id",
          name:"commentsedit",
          component:CommentsEdit
      },
      {
          path:"/adminPasswordChange",
          name:"password",
          component:Password
      },
      {
          path:"/adminShow",
          name:"adminshow",
          component:AdminShow
      },
      {
          path:"/adminAdd",
          name:"adminadd",
          component:AdminAdd
      },
      {
          path:"/adminEdit/:id",
          name:"adminedit",
          component:AdminEdit
      }
  ]
})
