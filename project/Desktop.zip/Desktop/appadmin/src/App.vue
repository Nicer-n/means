<template>
  <div id="app">
    <el-container class="container">
      <el-header>
         <el-row>
            <el-col :span="12">i-cake商城后台管理系统</el-col>
            <el-col :span="4" :offset="8" class="right">欢迎<span v-if="role">超级</span>管理员 <span>{{name}}</span>&nbsp;&nbsp;<a href="##" @click="logout">退出</a></el-col>
         </el-row>
      </el-header>
      <el-container class="bottom">
        <el-aside width="200px">
          <el-menu
                  :default-active="active"
                  class="el-menu-vertical-demo"
                  :router="true"
                  :unique-opened="true"
                 >
            <el-submenu index="admin">
              <template slot="title">
                 <span>管理模块</span>
              </template>
              <el-menu-item index="/adminPasswordChange">修改密码</el-menu-item>
              <el-menu-item v-if="role" index="/adminShow">查看管理员</el-menu-item>
              <el-menu-item v-if="role" index="/adminAdd">新增管理员</el-menu-item>
            </el-submenu>
            <el-submenu index="user">
              <template slot="title">
                <span>用户模块</span>
              </template>
              <el-menu-item index="/userShow" >查看用户</el-menu-item>
              <el-menu-item index="/userAdd" >新增用户</el-menu-item>
              <el-menu-item index="/addressShow" >用户地址</el-menu-item>
            </el-submenu>
            <el-submenu index="goods">
               <template slot="title">
                 商品模块
               </template>
               <el-menu-item index="/typeShow">分类查看</el-menu-item>
               <el-menu-item index="/typeAdd">增加分类</el-menu-item>
              <el-menu-item index="/goodsShow">商品查看</el-menu-item>
              <el-menu-item index="/goodsAdd">增加商品</el-menu-item>
              <el-menu-item index="/commentsShow">评论查看</el-menu-item>
            </el-submenu>
            <el-submenu index="orders">
              <template slot="title">订单模块</template>
              <el-menu-item index="/orderShow">订单查看</el-menu-item>
              <el-menu-item index="/orderCount">订单统计</el-menu-item>
            </el-submenu>
          </el-menu>
        </el-aside>
        <el-main>
          <router-view></router-view>
        </el-main>
      </el-container>
    </el-container>
  </div>
</template>
<script>
   export default {
       data:()=>({
           name:JSON.parse(sessionStorage.login).name,
           role:JSON.parse(sessionStorage.login).role
       }),
       methods:{
          logout:function(){
              sessionStorage.clear();
              location.reload();
          }
       },
       computed:{
           active:function(){
               return this.$store.state.active;
           }
       }
   }
</script>
<style lang="scss">
*{
  margin:0;
  padding:0;
}
html,body,#app{
  width:100%;
  height:100%;
}
#app {
  font-family: 'Avenir', Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}
.el-header{
  background:#333;
  color:#fff;
  line-height:60px;
  font-size:24px;
  font-weight:bold;
  transition:all .5s;
  cursor:pointer;
  a{
    color: #4979ff;
    text-decoration: none;
  }
  .right{
    font-size:16px;
  }
}
.container{
  height:100%;
  .bottom{
    height:calc(100% - 60px);
    .el-aside{
      height:100%;
      .el-menu{
         height:100%;
      }
    }
  }
}
</style>
