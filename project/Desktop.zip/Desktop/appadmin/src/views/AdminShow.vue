<template>
    <div>
        <el-table :data="tableData">
            <el-table-column
                    label="id"
                    prop="id"
            ></el-table-column>
            <el-table-column
                    label="姓名"
                    prop="name"
            >
            </el-table-column>
            <el-table-column
                    label="激活状态"
            >
                <template slot-scope="scope">
                    <el-switch
                            v-model="scope.row.state"
                            active-color="#13ce66"
                            inactive-color="#ff4949"
                            @change="changeState(scope.row)"
                    >
                    </el-switch>
                </template>
            </el-table-column>
            <el-table-column
                    align="center"
            >
                <template slot="header" slot-scope="scope">
                    <el-input
                            v-model="search"
                            size="mini"
                            placeholder="输入管理员名称搜索"
                            @change="change"
                    />
                </template>
                <template slot-scope="scope">
                    <el-button type="primary" icon="el-icon-edit" circle @click="handleEdit(scope.row.id)"></el-button>
                    <el-button type="danger" icon="el-icon-delete" circle
                               @click="handleDelete(scope.row.id)"></el-button>
                </template>
            </el-table-column>
        </el-table>
        <div class="block">
            <el-pagination

                    :current-page="page"
                    :page-sizes="[5,10,20,40]"
                    :page-size="pageSize"
                    layout="total, sizes, prev, pager, next, jumper"
                    :total="total"
                    @size-change="sizeChange"
                    @current-change="currentChange"
                    @prev-clicck="prevClick"
                    @next-click="nextClick"
            >
            </el-pagination>
        </div>
    </div>
</template>

<script>
    export default {
        name: "AdminShow",
        data: () => ({
            tableData: [],
            url: "/api/admin/admin",
            page: 1,
            pageSize: 5,
            search:"",
            total: 0
        }),
        methods: {
            fetchData: function () {
                this.$http.get(this.url, {
                    params: {
                        page: this.page,
                        pageSize: this.pageSize,
                        search: this.search
                    }
                }).then(res => {
                    if (res.data.code === 200) {
                        let data = res.data.data.map(v => {
                            v.state = v.state === 1 ? true : false;
                            return v;
                        });
                        this.tableData = data;
                        this.total = res.data.total;
                    } else {
                        this.$message.error("获取失败");
                    }
                }).catch(() => {
                    this.$message.error("获取失败");
                })
            },
            currentChange:function(p){
                this.page=p;
            },
            nextClick:function(p){
                this.page=p;
            },
            prevClick:function(p){
                this.page=p;
            },
            sizeChange:function(size){
                this.pageSize=size;
                this.fetchData();
            },
            change:function(){
                this.page=1;
                this.fetchData();
            },
            changeState:function(r){
                r.state=r.state?1:0;
                this.$http.put(this.url,r).then(res=>{
                   if(res.data.code===200){
                       this.$message.success("修改成功");
                       this.fetchData();
                   }else{
                       this.$message.error("修改失败")
                   }
                }).catch(()=>{
                    this.$message.error("修改失败")
                })
            },
            handleDelete:function(id){
                this.$confirm('确定要删除当前管理员吗?', '提示', {
                    confirmButtonText: '确定',
                    cancelButtonText: '取消',
                    type: 'warning'
                }).then(() => {
                    this.$http.delete(this.url,{
                        params:{
                            id
                        }
                    }).then(res=>{
                        if(res.data.code===200){
                            this.$message({
                                message:res.data.msg,
                                type:"success"
                            });
                            this.fetchData();
                        }else{
                            this.$message({
                                message:res.data.msg,
                                type:"error"
                            })
                        }
                    }).catch(()=>{
                        this.$message({
                            message:"未知错误",
                            type:"error"
                        });
                    });
                }).catch(() => {
                    this.$message({
                        type: 'info',
                        message: '已取消删除'
                    });
                });
            },
            handleEdit:function(id){
                this.$router.push({name:"adminedit",params:{id}})
            }
        },
        watch: {
            page: function () {
                this.fetchData();
            }
        },
        mounted: function () {
            this.$store.commit("changeActive", "/adminShow");
            this.fetchData();
        }
    }
</script>

<style lang="scss" scoped>
    .block {
        width: 100%;
        height: 100px;
        display: flex;
        justify-content: center;
        align-items: center;
    }
</style>