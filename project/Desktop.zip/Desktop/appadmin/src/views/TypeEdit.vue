<template>
    <div>
        <el-col :span="12">
            <el-form label-width="80px" :model="form" :rules="rules" ref="form">
                <el-form-item label="分类名称" prop="category">
                    <el-input placeholder="请输入分类名称" v-model="form.category"></el-input>
                </el-form-item>
                <el-form-item label="分类图片" prop="thumb">
                    <el-upload
                            class="avatar-uploader" action="/api/upload/upload"
                            :show-file-list="false" :on-success="handleAvatarSuccess"
                            :before-upload="beforeAvatarUpload">
                        <img v-if="form.thumb" :src="form.thumb" class="avatar">
                        <i v-else class="el-icon-plus avatar-uploader-icon"></i>
                    </el-upload>
                    <el-input v-model="form.thumb" type="hidden"></el-input>
                </el-form-item>
                <el-form-item label="排序">
                    <el-input type="number" v-model="form.sort"></el-input>
                </el-form-item>
                <el-form-item>
                    <el-button type="primary" @click="submit">提交</el-button>
                </el-form-item>
            </el-form>
        </el-col>
    </div>
</template>

<script>
    export default {
        name: "TypeAdd",
        data: () => ({
            form: {
                category: "",
                sort: "",
                thumb: ""
            },
            rules:{
                category:[
                    {
                        required:true,
                        message:"请填写分类名称",
                        trigger:"blur"}
                ],
                thumb:[
                    {
                        required:true,
                        message:"请上传分类图片"
                    }
                ]
            },
            url:"/api/type/type"
        }),
        methods:{
            handleAvatarSuccess:function(r){
                if(r!==""){
                    this.form.thumb=r;
                }
            },
            beforeAvatarUpload:function(file){
                const isJPG = file.type === 'image/jpeg' || file.type === 'image/png';
                const isLt500Kb = file.size / 1024 / 1024 < 0.5;

                if (!isJPG) {
                    this.$message.error('上传头像图片只能是 JPG或者PNG 格式!');
                }
                if (!isLt500Kb) {
                    this.$message.error('上传头像图片大小不能超过 500kb!');
                }
                return isJPG && isLt500Kb;
            },
            submit:function(){
                this.$refs.form.validate((v)=>{
                    if(v){
                       this.$http.put(this.url,this.form).then((res)=>{
                           if(res.data.code===200){
                               this.$alert('修改成功', '', {
                                   confirmButtonText: '确定',
                                   callback: action => {
                                       this.$router.push({name:"typeshow"});
                                   }
                               });
                           }else{
                              this.$message.error(res.data.msg)
                           }
                       }).catch(()=>{
                           this.$message.error("未知错误")
                       })
                    }
                })
            },
            fetchData:function(){
               this.$http.get(this.url,{
                   params:{
                       id:this.$route.params.id
                   }
               }).then((res)=>{
                   if(res.data.code===200){
                       this.$message.success(res.data.msg);
                       this.form=res.data.data;
                   }else{
                       this.$message.error(res.data.msg);
                   }
               }).catch(function(){
                  this.$message.error("未知错误");
               }.bind(this))
            }
        },
        mounted: function () {
            this.$store.commit("changeActive", "/typeShow");
            this.fetchData();
        }
    }
</script>

<style lang="scss" scoped>
    .avatar-uploader-icon {
        font-size: 28px;
        color: #8c939d;
        width: 178px;
        height: 178px;
        line-height: 178px;
        text-align: center;
        border: 1px dashed #d9d9d9;
    }

    .avatar-uploader-icon:hover {
        border-color: #409EFF;
    }

    .avatar {
        width: 178px;
        height: 178px;
        display: block;
    }
</style>