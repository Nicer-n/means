<template>
    <div>
        <el-col :span="12">
            <el-form label-width="100px" :model="form" :rules="rules" ref="form">
                <el-form-item label="管理员姓名" prop="name">
                    <el-input placeholder="管理员姓名" v-model="form.name"></el-input>
                </el-form-item>
                <el-form-item label="重设密码" prop="password">
                    <el-input placeholder="重设密码" type="password" show-password v-model="form.password"></el-input>
                </el-form-item>
                <el-form-item>
                    <el-button type="primary" @click="submit">提交</el-button>
                </el-form-item>
            </el-form>
        </el-col>
    </div>
</template>

<script>
    export default {
        name: "AdminAdd",
        data: () => {
            let passwordValid = (rules, val, callback) => {
                if(val===""){
                    callback();
                    return;
                }
                let reg = /^[0-9a-zA-Z]{6,}$/;
                if (reg.test(val)) {
                    callback();
                } else {
                    callback(new Error("密码必须由6位以上的字母或者数字组成"));
                }
            };
            return {
                form: {
                    name: "",
                    password: ""
                },
                rules: {
                    name: [{
                        required: true,
                        message: "请输入管理员姓名",
                        trigger: "blur"
                    }],
                    password: [{
                        validator:passwordValid,
                        trigger: "blur"
                    }]
                },
                url:"/api/admin/admin"
            }
        },
        methods: {
            submit: function () {
                this.$refs.form.validate((valid) => {
                    if (valid) {
                        if(this.form.password===""){
                            delete this.form.password;
                        }
                        this.$http.put(this.url, this.form).then(res => {
                            if (res.data.code === 200) {
                                this.$alert('修改成功', '', {
                                    confirmButtonText: '确定',
                                    callback: () => {
                                        this.$router.push({name:"adminshow"})
                                    }
                                });
                            } else {
                                this.$message.error(res.data.msg);
                            }
                        }).catch(() => {
                            this.$message.error("提交失败")
                        })
                    } else {
                        return false;
                    }
                })
            },
            fetchData: function () {
                this.$http.get(this.url, {
                    params: {
                        id: this.$route.params.id
                    }
                }).then(res => {
                    if (res.data.code === 200) {
                        this.$message.success(res.data.msg);
                        this.form = res.data.data;
                        this.form.password ="";
                    } else {
                        this.$message.error(res.data.msg)
                    }
                }).catch(() => {
                    this.$message.error("未知错误")
                })
            }
        },
        mounted: function () {
            this.$store.commit("changeActive", "/adminShow");
            this.fetchData();
        }
    }
</script>

<style lang="scss" scoped>

</style>