<template>
    <div>
        <el-form :inline="true" class="demo-form-inline" label-width="80px">
            <el-form-item label="商品名称">
                <el-input placeholder="请输入要搜索的商品名称" size="small" v-model="name"></el-input>
            </el-form-item>
            <el-form-item label="商品分类">
                <el-select v-model="value" placeholder="请选择" size="small" :clearable="true">
                    <el-option
                            v-for="item in options"
                            :key="item.value"
                            :label="item.label"
                            :value="item.value">
                    </el-option>
                </el-select>
            </el-form-item>
            <el-form-item label="价格区间">
                <el-col :span="11">
                    <el-input placeholder="最低" type="number" min="0" max="1000" size="small" v-model="low"></el-input>
                </el-col>
                <el-col :span="1">-</el-col>
                <el-col :span="11">
                    <el-input placeholder="最高" type="number" min="0" max="1000" size="small" v-model="high"></el-input>
                </el-col>
            </el-form-item>
            <el-form-item label="上架状态">
                <el-switch
                        v-model="state"
                        active-color="#13ce66"
                        inactive-color="#ff4949">
                </el-switch>
            </el-form-item>
            <el-form-item>
                <el-button type="primary" @click="search">搜索</el-button>
            </el-form-item>
        </el-form>
        <el-table
                :data="tableData"
                style="width: 100%">
            <el-table-column type="expand">
                <template slot-scope="props">
                    <el-form label-position="left" inline class="demo-table-expand" label-width="80px">
                        <el-form-item label="中文名称:">
                            <span>{{ props.row.name_ch }}</span>
                        </el-form-item>
                        <el-form-item label="英文名称:">
                            <span>{{ props.row.name_en }}</span>
                        </el-form-item>
                        <el-form-item label="商品价格:">
                            <span>{{ props.row.price}}</span>
                        </el-form-item>
                        <el-form-item label="商品分类:">
                            <span>{{ props.row.category}}</span>
                        </el-form-item>
                        <el-form-item label="当前销量:">
                            <span>{{ props.row.sells}}</span>
                        </el-form-item>
                        <el-form-item label="商品标签:">
                            <span>{{ props.row.tags}}</span>
                        </el-form-item>
                        <el-form-item label="商品描述:">
                            <span>{{ props.row.description}}</span>
                        </el-form-item>
                        <el-form-item label="商品尺寸:">
                            <span>{{ props.row.size_dec}}</span>
                        </el-form-item>
                        <el-form-item label="适宜人群:">
                            <span>{{ props.row.suit}}</span>
                        </el-form-item>
                        <el-form-item label="存储方式:">
                            <span>{{ props.row.store}}</span>
                        </el-form-item>
                        <el-form-item label="使用场合:">
                            <span>{{ props.row.situation}}</span>
                        </el-form-item>
                        <el-form-item label="附赠餐具:">
                            <span>{{ props.row.covers}}</span>
                        </el-form-item>
                        <el-form-item label="内部材料:">
                            <span>{{ props.row.material}}</span>
                        </el-form-item>
                    </el-form>
                </template>
            </el-table-column>
            <el-table-column
                    label="商品 ID"
                    prop="id"
                    align="center"
            >
            </el-table-column>
            <el-table-column
                    label="商品名称"
                    prop="name_ch"
                    align="center"
            >
            </el-table-column>
            <el-table-column
                    label="商品图片"
                    align="center"
            >
                <template slot-scope="scope">
                    <img :src="scope.row.thumb" alt="" style="width:50px;height:50px;border-radius:50%;">
                </template>
            </el-table-column>
            <el-table-column
                    label="操作"
                    align="center"
            >
                <template slot-scope="scope">
                    <el-button type="primary" icon="el-icon-edit" circle @click="handleEdit(scope.row.id)"></el-button>
                    <el-button type="danger" icon="el-icon-delete" circle @click="handleDelete(scope.row.id)" v-if="role"></el-button>
                </template>
            </el-table-column>
            <el-table-column
                    label="上架操作"
                    align="center"
            >
                <template slot-scope="scope">
                    <el-button v-if="scope.row.state===0" type="text" @click="changeState(scope.row.id,1)">上架</el-button>
                    <el-button v-else type="text" @click="changeState(scope.row.id,0)">下架</el-button>
                </template>
            </el-table-column>
        </el-table>
        <div class="block">
            <el-pagination

                    :current-page="page"
                    :page-sizes="[5,10,20,40]"
                    :page-size="pageSize"
                    layout="total, sizes, prev, pager, next, jumper"
                    :total="total"
                    @size-change="sizeChange"
                    @current-change="currentChange"
                    @prev-clicck="prevClick"
                    @next-click="nextClick"
            >
            </el-pagination>
        </div>
    </div>
</template>

<script>
    export default {
        name: "GoodsShow",
        data: () => ({
            tableData: [],
            url: "/api/goods/goods",
            page: 1,
            pageSize: 5,
            total: 0,
            options: [],
            name:'',
            value: '',
            state: true,
            low:"",
            high:"",
            role:JSON.parse(sessionStorage.login).role
        }),
        methods: {
            fetchData: function () {
                this.$http.get(this.url, {
                    params: {
                        page: this.page,
                        pageSize: this.pageSize
                    }
                }).then(res => {
                    if (res.data.code === 200) {
                        this.$message.success(res.data.msg);
                        this.tableData = res.data.data;
                        this.total = res.data.total;
                    } else {
                        this.$message.error(res.data.msg)
                    }
                }).catch(() => {
                    this.$message.error("未知错误")
                })
            },
            currentChange: function (p) {
                this.page = p;
            },
            nextClick: function (p) {
                this.page = p;
            },
            prevClick: function (p) {
                this.page = p;
            },
            sizeChange: function (size) {
                this.pageSize = size;
                this.fetchData();
            },
            fetchTypeData: function(){
               this.$http.get("/api/type/type").then((res)=>{
               if(res.data.code===200){
                 this.options=res.data.data.map(v=>({label:v.category,value:v.id}));
               }else{
                   this.$message.error(res.data.msg);
               }
               }).catch(()=>{
                   this.$message.error("分类信息获取失败");
               })
            },
            search:function(){
               let params={};
               if(this.name!==""){
                   params.name=this.name;
               }
               if(this.value!==""){
                   params.type=this.value;
               }
               if(this.low<=this.high){
                   if(this.high>0){
                       params.low=this.low;
                       params.high=this.high;
                   }
               }else{
                   this.$message.error("价格区间输入有误");
                   return;
               }
               if(this.state){
                   params.state=1;
               }else{
                   params.state=0;
               }
               this.$http.get(this.url,{
                   params
               }).then(res=>{
                  if(res.data.code===200){
                      this.$message.success(res.data.msg);
                      this.tableData=res.data.data;
                      this.total=res.data.total;
                  }else{
                      this.$message.success(res.data.msg);

                  }
               }).catch(()=>{
                   this.$message.error("未知错误")
               });
            },
            handleDelete:function(id){
                this.$confirm('此操作将永久删除该商品, 是否继续?', '提示', {
                    confirmButtonText: '确定',
                    cancelButtonText: '取消',
                    type: 'warning'
                }).then(() => {
                    this.$http.delete(this.url,{
                        params:{
                            id
                        }
                    }).then((res)=>{
                        if(res.data.code===200){
                            this.$message.success(res.data.msg);
                            this.fetchData();
                        }else{
                            this.$message.error(res.data.msg);
                        }
                    }).catch(()=> {
                        this.$message.error("未知错误")
                    })
                }).catch(() => {
                    this.$message({
                        type: 'info',
                        message: '已取消删除'
                    });
                });
            },
            changeState:function(id,state){
                this.$http.put(this.url,{id,state}).then(res=>{
                    if(res.data.code===200){
                        this.$message.success(res.data.msg);
                        this.fetchData();
                    }else{
                        this.$message.success(res.data.msg);
                    }
                }).catch(()=>{
                    this.$message.error("操作失败");
                });
            },
            handleEdit:function(id){
               this.$router.push({name:"goodsedit",params:{id}})
            }
        },
        watch: {
            page: function () {
                this.fetchData();
            }
        },
        mounted: function () {
            this.$store.commit("changeActive", "/goodsShow");
            this.fetchData();
            this.fetchTypeData();
        }
    }
</script>

<style lang="scss" scoped>
    .demo-table-expand {
        font-size: 0;
    }

    .demo-table-expand label {
        width: 90px;
        color: #99a9bf;
    }

    .demo-table-expand .el-form-item {
        margin-right: 0;
        margin-bottom: 0;
        width: 50%;
    }

    .block {
        width: 100%;
        height: 100px;
        display: flex;
        justify-content: center;
        align-items: center;
    }
</style>