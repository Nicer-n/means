<template>
    <div>
        <el-col :span="12">
            <el-form label-width="100px" :model="form" :rules="rules" ref="form">
                <el-form-item label="账号名称" prop="name">
                    <el-input v-model="form.name" :readonly="true"></el-input>
                </el-form-item>
                <el-form-item label="原始密码" prop="password">
                    <el-input type="password" v-model="form.password"></el-input>
                </el-form-item>
                <el-form-item label="新密码" prop="newpassword1">
                    <el-input type="password" v-model="form.newpassword1"></el-input>
                </el-form-item>
                <el-form-item label="确认新密码" prop="newpassword2">
                    <el-input type="password" v-model="form.newpassword2"></el-input>
                </el-form-item>
                <el-form-item>
                    <el-button type="primary" @click="submit">提交</el-button>
                </el-form-item>
            </el-form>
        </el-col>
    </div>
</template>

<script>
    export default {
        name: "AdminPasswordChange",
        data: function () {
            let passwordReg = (rule, value, callback) => {
                let reg = /^[a-zA-Z0-9]{6,}$/;
                if (reg.test(value)) {
                    callback();
                } else {
                    callback(new Error("密码必须由6位以上的字母或数字组成"));
                }
            };
            let repeatReg = (rule, value, callback) => {
                if (value !== this.form.newpassword1) {
                    callback(new Error("两次输入必须一致"));
                } else {
                    callback();
                }
            };
            return {
                form: {
                    name: JSON.parse(sessionStorage.login).name,
                    password: "",
                    newpassword1: "",
                    newpassword2: ""
                },
                rules: {
                    password: [{
                        required: true,
                        message: "请输入原始密码",
                        trigger: "blur"
                    }],
                    newpassword1: [{
                        required: true,
                        message: "请输入新密码",
                        trigger: "blur"
                    }, {
                       validator: passwordReg, trigger: "blur"
                    }],
                    newpassword2: [{
                        required: true,
                        message: "请重新输入新密码",
                        trigger: "blur"
                    }, {
                        validator: repeatReg, trigger: "blur"
                    }]
                }
            }
        },
        methods:{
            submit(){
               this.$refs.form.validate((valid)=>{
                   if(valid){
                       this.$http.put("/api/admin/changePassword",this.form).then(res=>{
                          if(res.data.code===200){
                              this.$message.success("修改成功");
                          }
                       }).catch(()=>{
                          this.$message.error("请求失败")
                       })

                   }else{
                       return false;
                   }
               })
            }
        },
        mounted: function () {
            this.$store.commit("changeActive", "/adminPasswordChange");
        }
    }
</script>

<style lang="scss" scoped>

</style>