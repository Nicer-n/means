<template>
    <div>
        <el-form :inline="true" class="demo-form-inline" label-width="120px">
            <el-form-item label="按商品查询">
               <el-input placeholder="请输入商品名称" v-model="goodsName"></el-input>
            </el-form-item>
            <el-form-item label="按用户查询">
               <el-input placeholder="请输入用户名称" v-model="userName"></el-input>
            </el-form-item>
            <el-form-item>
                <el-button type="primary" @click="search">搜索</el-button>
            </el-form-item>
        </el-form>
      <el-table
            :data="tableData"
            style="width: 100%">
        <el-table-column
                label="用户名"
                prop="username"
                align="center"
        >
        </el-table-column>
        <el-table-column
                label="商品名称"
                prop="name_ch"
                align="center"
        >
        </el-table-column>
        <el-table-column
                label="评论内容"
                prop="content"
                align="center"
        >
        </el-table-column>
          <el-table-column
                  label="评论时间"
                  prop="time"
                  align="center"
          >
          </el-table-column>
        <el-table-column
                label="操作"
                align="center"
        >
            <template slot-scope="scope">
                <el-button
                        size="mini"
                        @click="handleEdit(scope.row.id)">回复
                </el-button>
                <el-button
                        size="mini"
                        type="danger"
                        @click="handleDelete(scope.row.id)">删除
                </el-button>
            </template>
        </el-table-column>
    </el-table>
      <div class="block">
        <el-pagination
                :current-page="page"
                :page-sizes="[5,10,20,40]"
                :page-size="pageSize"
                layout="total, sizes, prev, pager, next, jumper"
                :total="total"
                @size-change="sizeChange"
                @current-change="currentChange"
                @prev-clicck="prevClick"
                @next-click="nextClick"
        >
        </el-pagination>
    </div>
    </div>
</template>

<script>
    export default {
        name: "commentsShow",
        data: () => ({
            tableData: [],
            url: "/api/comments/comments",
            page: 1,
            pageSize: 5,
            total:0,
            goodsName:"",
            userName:""
        }),
        methods: {
            fetchData: function () {
                this.$http.get(this.url, {
                    params: {
                        page: this.page,
                        pageSize: this.pageSize,
                        userName: this.userName,
                        goodsName: this.goodsName
                    }
                }).then(res => {
                    if (res.data.code === 200) {
                        this.$message.success(res.data.msg);
                        this.tableData = res.data.data;
                        this.total=res.data.total;
                    } else {
                        this.$message.error(res.data.msg)
                    }
                }).catch(() => {
                    this.$message.error("未知错误")
                })
            },
            currentChange:function(p){
                this.page=p;
            },
            nextClick:function(p){
                this.page=p;
            },
            prevClick:function(p){
                this.page=p;
            },
            sizeChange:function(size){
                this.pageSize=size;
                this.fetchData();
            },
            change:function(){
                this.page=1;
                this.fetchData();
            },
            handleDelete:function(id){
                this.$confirm('此操作将永久删除该分类, 是否继续?', '提示', {
                    confirmButtonText: '确定',
                    cancelButtonText: '取消',
                    type: 'warning'
                }).then(() => {
                    this.$http.delete(this.url,{
                        params:{
                            id
                        }
                    }).then((res)=>{
                        if(res.data.code===200){
                            this.$message.success(res.data.msg);
                            this.fetchData();
                        }else{
                            this.$message.error(res.data.msg);
                        }
                    }).catch(()=> {
                        this.$message.error("未知错误")
                    })
                }).catch(() => {
                    this.$message({
                        type: 'info',
                        message: '已取消删除'
                    });
                });
            },
            handleEdit:function(id){
              this.$router.push({name:"commentsedit",params:{id}});
            },
            search:function(){
                this.fetchData();
            }
        },
        watch:{
            page:function(){
              this.fetchData();
            }
        },
        mounted: function () {
            this.$store.commit("changeActive", "/commentsShow");
            this.fetchData();
        }
    }
</script>

<style lang="scss" scoped>
.block{
    width:100%;
    height:100px;
    display: flex;
    justify-content: center;
    align-items: center;
}
</style>