<template>
    <div>
        <el-col :span="12">
            <el-form label-width="120px" :model="form" :rules="rules" ref="form">
                <el-form-item label="选择分类" prop="tid">
                    <el-select v-model="form.tid" placeholder="请选择">
                        <el-option
                                v-for="item in options"
                                :key="item.value"
                                :label="item.label"
                                :value="item.value">
                        </el-option>
                    </el-select>
                </el-form-item>
                <el-form-item label="中文名称" prop="name_ch">
                    <el-input placeholder="请输入中文名称" v-model="form.name_ch"></el-input>
                </el-form-item>
                <el-form-item label="英文名称" prop="name_en">
                    <el-input placeholder="请输入英文名称" v-model="form.name_en"></el-input>
                </el-form-item>
                <el-form-item label="商品价格" prop="price">
                    <el-input placeholder="请输入价格" v-model="form.price"></el-input>
                </el-form-item>
                <el-form-item label="缩略图" prop="thumb">
                    <el-upload
                            class="avatar-uploader" action="/api/upload/upload"
                            :show-file-list="false" :on-success="handleAvatarSuccess1"
                            :before-upload="beforeAvatarUpload">
                        <img v-if="form.thumb" :src="form.thumb" class="avatar">
                        <i v-else class="el-icon-plus avatar-uploader-icon"></i>
                    </el-upload>
                    <el-input v-model="form.thumb" type="hidden"></el-input>
                </el-form-item>
                <el-form-item label="商品图片" prop="pics">
                    <el-upload
                            class="upload-demo"
                            action="/api/upload/upload"
                            :limit="5" :on-exceed="handleExceed" :on-success="handleAvatarSuccess4"
                            :on-remove="handleRemove"
                            :before-remove="beforeRemove"
                            :file-list="fileList"
                            list-type="picture">
                        <el-button size="small" type="primary">点击上传</el-button>
                        <div slot="tip" class="el-upload__tip">只能上传jpg/png文件，且不超过500kb</div>
                    </el-upload>
                    <el-input type="hidden" v-model="form.pics"></el-input>
                </el-form-item>
                <el-form-item label="蛋糕尺寸" prop="sizes">
                    <el-checkbox-group v-model="form.sizes">
                        <el-checkbox  label="6寸"></el-checkbox>
                        <el-checkbox label="8寸"></el-checkbox>
                        <el-checkbox label="10寸"></el-checkbox>
                    </el-checkbox-group>
                </el-form-item>
                <el-form-item label="商品标签" prop="tags">
                    <el-input placeholder="请输入商品标签" v-model="form.tags"></el-input>
                </el-form-item>
                <el-form-item label="商品描述" prop="description">
                    <el-input type="textarea" placehodler="请输入商品描述" v-model="form.description"></el-input>
                </el-form-item>
                <el-form-item label="PC端内容" prop="content_pc">
                    <el-upload
                            class="avatar-uploader" action="/api/upload/upload"
                            :show-file-list="false" :on-success="handleAvatarSuccess2"
                            :before-upload="beforeAvatarUpload">
                        <img v-if="form.content_pc" :src="form.content_pc" class="avatar">
                        <i v-else class="el-icon-plus avatar-uploader-icon"></i>
                    </el-upload>
                    <el-input v-model="form.content_pc" type="hidden"></el-input>
                </el-form-item>
                <el-form-item label="移动端内容" prop="content_mob">
                    <el-upload
                            class="avatar-uploader" action="/api/upload/upload"
                            :show-file-list="false" :on-success="handleAvatarSuccess3"
                            :before-upload="beforeAvatarUpload">
                        <img v-if="form.content_mob" :src="form.content_mob" class="avatar">
                        <i v-else class="el-icon-plus avatar-uploader-icon"></i>
                    </el-upload>
                    <el-input v-model="form.content_mob" type="hidden"></el-input>
                </el-form-item>
                <el-form-item label="适宜人群" prop="suit">
                    <el-input v-model="form.suit" placeholder="请输入适宜人群"></el-input>
                </el-form-item>
                <el-form-item label="存储方式" prop="store">
                    <el-input placeholder="请输入存储方式" v-model="form.store"></el-input>
                </el-form-item>
                <el-form-item label="适用场合" prop="situation">
                    <el-input placeholder="请输入适用场合" v-model="form.situation"></el-input>
                </el-form-item>
                <el-form-item label="配套餐具" prop="covers">
                    <el-input placeholder="请输入配套餐具" v-model="form.covers"></el-input>
                </el-form-item>
                <el-form-item label="尺寸描述" prop="size_dec">
                    <el-input placeholder="请输入配套餐具" v-model="form.size_dec"></el-input>
                </el-form-item>
                <el-form-item label="内部材料" prop="material">
                    <el-input placeholder="请输入配套餐具" v-model="form.material"></el-input>
                </el-form-item>
                <el-form-item label="是否上架" prop="state">
                    <el-radio v-model="form.state" :label="1">上架</el-radio>
                    <el-radio v-model="form.state" :label="0">暂不上架</el-radio>
                </el-form-item>
                <el-form-item>
                    <el-button type="primary" @click="submit">提交修改</el-button>
                </el-form-item>
            </el-form>
        </el-col>
    </div>
</template>
<script>
    export default {
        name: "GoodsAdd",
        data: () => ({
            options: [],
            form: {
                name_ch: "",
                name_en: "",
                tid: "",
                sizes: [],
                pics: "",
                price: "",
                tags: "",
                thumb: "",
                description: "",
                sells: 0,
                content_pc: "",
                content_mob: "",
                suit: "",
                covers: "",
                store: "",
                situation: "",
                size_dec: "",
                material: "",
                state: ""
            },
            rules: {
                name_ch: [{required: true, message: "请输入商品名称", trigger: "blur"}],
                name_en: [{required: true, message: "请输入商品英文名称", trigger: "blur"}],
                thumb: [{required: true, message: "请选择商品图片"}],
                tid: [{required: true, message: "请选择商品分类", trigger: "change"}],
                sizes: [{type: "array", required: true, message: "请选择商品尺寸", trigger: "change"}],
                price: [{required: true, message: "请输入商品价格", trigger: "blur"}],
                tags: [{required: true, message: "请输入商品标签", trigger: "blur"}],
                description: [{required: true, message: "请输入商品描述", trigger: "blur"}],
                content_pc: [{required: true, message: "请选择详情图片-pc"}],
                content_mob: [{required: true, message: "请选择详情图片-mob"}],
                suit: [{required: true, message: "请输入适宜人群", trigger: "blur"}],
                store: [{required: true, message: "请输入存储方式", trigger: "blur"}],
                covers: [{required: true, message: "请输入配套餐具", trigger: "blur"}],
                situation: [{required: true, message: "请输入适宜人群", trigger: "blur"}],
                size_dec: [{required: true, message: "请输入型号描述", trigger: "blur"}],
                material: [{required: true, message: "请输入组成材料", trigger: "blur"}],
                pics: [{required: true, message: "请上传商品图片", trigger: "blur"}],
                state: [{required: true, message: "请设置是否上架", trigger: "change"}]
            },
            fileList: [],
        }),
        methods: {
            fetchTypeData: function () {
                this.$http.get("/api/type/type").then((res) => {
                    if (res.data.code === 200) {
                        this.options = res.data.data.map(v => ({label: v.category, value: v.id}));
                    } else {
                        this.$message.error(res.data.msg);
                    }
                }).catch(() => {
                    this.$message.error("分类信息获取失败");
                })
            },
            handleExceed(files, fileList) {
                this.$message.warning(`当前限制选择 5 个文件，本次选择了 ${files.length} 个文件，共选择了 ${files.length + fileList.length} 个文件`);
            },
            handleAvatarSuccess1: function (r) {
                if (r !== "") {
                    this.form.thumb = r;
                }
            },
            handleAvatarSuccess2: function (r) {
                if (r !== "") {
                    this.form.content_pc = r;
                }
            },
            handleAvatarSuccess3: function (r) {
                if (r !== "") {
                    this.form.content_mob = r;
                }
            },
            handleAvatarSuccess4: function (r, file) {
                if (r !== "") {
                    this.fileList.push(file);
                }
            },
            beforeRemove(file) {
                return this.$confirm(`确定移除 ${ file.name }？`);
            },
            handleRemove: function (file, filelist) {
                console.log(filelist);
                this.fileList = filelist;
            },
            beforeAvatarUpload: function (file) {
                const isJPG = file.type === 'image/jpeg' || file.type === 'image/png';
                const isLt500Kb = file.size / 1024 / 1024 < 0.5;

                if (!isJPG) {
                    this.$message.error('上传头像图片只能是 JPG或者PNG 格式!');
                }
                if (!isLt500Kb) {
                    this.$message.error('上传头像图片大小不能超过 500kb!');
                }
                return isJPG && isLt500Kb;
            },
            submit: function () {
                this.form.pics=this.fileList.map(v=>v.response).join(";");
                this.$refs.form.validate((valid) => {
                    if (valid) {
                     this.form.sizes=this.form.sizes.join();
                     this.$http.put("/api/goods/goods",this.form).then((res)=>{
                         if(res.data.code===200){
                             this.$alert('修改成功','', {confirmButtonText: '确定',
                                 callback: () => {
                                     this.$router.push({name:"goodsshow"})
                                 }
                             });
                         }else{
                             this.$message.error(res.data.msg);
                             this.form.sizes=this.form.sizes.split(",");
                         }
                     }).catch(()=>{
                         this.$message.error("修改失败");
                         this.form.sizes=this.form.sizes.split(",");
                     })
                    } else {
                        return false;
                    }
                })
            },
            fetchGoodsData:function(){
              this.$http.get("/api/goods/goods",{params:{id:this.$route.params.id}}).then(res=>{
                  if(res.data.code===200) {
                      this.form = res.data.data;
                      this.form.sizes=this.form.sizes.split(",");
                      this.fileList=this.form.pics.split(";").map((v,i)=>({response:v,url:v,uid:i}));
                  }else{
                      this.$message.error("获取失败");
                  }
              }).catch(()=>{
                  this.$message.error("获取失败");
              })
            }
        },
        mounted: function () {
            this.$store.commit("changeActive", "/goodsShow");
            this.fetchTypeData();
            this.fetchGoodsData();
        }
    }
</script>
<style lang="scss" scoped>
    .avatar-uploader-icon {
        font-size: 28px;
        color: #8c939d;
        width: 178px;
        height: 178px;
        line-height: 178px;
        text-align: center;
        border: 1px dashed #d9d9d9;
    }

    .avatar-uploader-icon:hover {
        border-color: #409EFF;
    }

    .avatar {
        width: 178px;
        height: 178px;
        display: block;
    }
</style>