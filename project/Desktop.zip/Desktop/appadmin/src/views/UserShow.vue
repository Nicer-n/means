<template>
    <div>
        <el-table
                :data="tableData"
                style="width:100%">
            <el-table-column
                    label="用户名"
                    prop="username"
                    align="center"
            >
            </el-table-column>
            <el-table-column
                    label="头像"
                    prop="avatar"
                    align="center"
            >
                <template slot-scope="scope">
                    <img :src="scope.row.avatar" alt="" width="50" height="50" style="border-radius: 50%;">
                </template>
            </el-table-column>
            <el-table-column
                    label="性别"
                    prop="sex"
                    align="center"
            >
                <template slot-scope="scope">                          {{scope.row.sex===1?'男':'女'}}
                </template>
            </el-table-column>
            <el-table-column
                    align="right">
                <template slot="header" slot-scope="scope">
                    <el-input
                            v-model="search"
                            size="mini"
                            placeholder="输入用户名搜索"
                            @change="change"
                    />
                </template>
                <template slot-scope="scope">
                    <el-button
                            size="mini"
                            @click="handleEdit(scope.row.id)">编辑
                    </el-button>
                    <el-button
                            size="mini"
                            type="danger"
                            @click="handleDelete(scope.row.id)">删除
                    </el-button>
                </template>
            </el-table-column>
        </el-table>
        <div class="block">
            <el-pagination
                    :current-page="page"
                    :page-sizes="[5,10,20,40]"
                    :page-size="pageSize"
                    layout="total, sizes, prev, pager, next, jumper"
                    :total="total"
                    @current-change="currentChange"
                    @prev-click="prevClick"
                    @next-click="nextClick"
                    @size-change="sizeChange"
            >
            </el-pagination>
        </div>
    </div>
</template>
<script>
    export default {
        name: "UserShow",
        data: () => ({
            tableData: [],
            search: '',
            page: 1,   //当前的页数
            pageSize: 5,  //每页显示的条数
            total: 0,
            url:"/api/users/users"
        }),
        methods: {
            fetchData: function () {
                this.$http.get(this.url,{
                    params:{
                       page:this.page,
                       pageSize:this.pageSize,
                       search:this.search
                    }
                }).then(r => {
                    if (r.data.code === 200) {
                        this.$message({
                            message: r.data.msg,
                            type: "success"
                        });
                        this.tableData = r.data.data;
                        this.total = r.data.total;
                    }
                })
            },
            currentChange: function (p) {
               this.page=p;
            },
            prevClick:function(p){
               this.page=p;
            },
            nextClick:function(p){
               this.page=p;
            },
            sizeChange:function(size){
               this.pageSize=size;
               this.fetchData();
            },
            change:function(){
               this.page=1;
               this.fetchData();
            },
            handleDelete:function(id){
                this.$confirm('确定要删除当前用户吗?', '提示', {
                    confirmButtonText: '确定',
                    cancelButtonText: '取消',
                    type: 'warning'
                }).then(() => {
                    this.$http.delete(this.url,{
                        params:{
                            id
                        }
                    }).then(res=>{
                       if(res.data.code===200){
                           this.$message({
                              message:res.data.msg,
                              type:"success"
                           });
                           this.fetchData();
                       }else{
                           this.$message({
                               message:res.data.msg,
                               type:"error"
                           })
                       }
                    }).catch(()=>{
                        this.$message({
                            message:"未知错误",
                            type:"error"
                        });
                    });
                }).catch(() => {
                    this.$message({
                        type: 'info',
                        message: '已取消删除'
                    });
                });
            },
            handleEdit:function(id){
                this.$router.push({name:"useredit",params:{id}})
            }
        },
        watch:{
            page:function(){
                this.fetchData();
            }
        },
        mounted: function () {
            this.fetchData();
            //console.log(this.$store.state.active);
            this.$store.commit("changeActive","/userShow");
        }
    }
</script>

<style lang="scss" scoped>
    .block {
        width: 100%;
        height: 100px;
        display: flex;
        justify-content: center;
        align-items: center;
    }
</style>