<template>
    <div>
        <el-col :span="12">
            <el-form label-width="80px" :model="form" :rules="rules" ref="form">
                <el-form-item label="用户名">
                    <span>{{form.username}}</span>
                </el-form-item>
                <el-form-item label="用户头像">
                    <img :src="form.avatar" alt="" class="avatar">
                </el-form-item>
                <el-form-item label="商品图片">
                    <img :src="form.thumb" alt="" class="avatar">
                </el-form-item>
                <el-form-item label="商品名称">
                    <span>{{form.name_ch}}</span>
                    <span>{{form.name_en}}</span>
                </el-form-item>
                <el-form-item label="评论内容">
                    <span>{{form.content}}</span>
                </el-form-item>
                <el-form-item label="评论时间">
                    <span>{{form.time}}</span>
                </el-form-item>
                <el-form-item label="评论图片">
                    <span>{{form.pics}}</span>
                </el-form-item>
                <el-form-item label="回复" prop="reply">
                    <el-input type="textarea" v-model="form.reply"></el-input>
                </el-form-item>
                <el-form-item>
                    <el-button type="primary" @click="submit">提交</el-button>
                </el-form-item>
            </el-form>
        </el-col>
    </div>
</template>

<script>
    export default {
        name: "TypeAdd",
        data: () => ({
            form: {

            },
            rules:{
               reply:[{
                   required:true,message:"请输入回复",trigger:"blur"
               }]
            },
            url:"/api/comments/comments"
        }),
        methods:{
            submit:function(){
                this.$refs.form.validate((v)=>{
                    if(v){
                       this.$http.put(this.url,this.form).then((res)=>{
                           if(res.data.code===200){
                               this.$alert('修改成功', '', {
                                   confirmButtonText: '确定',
                                   callback: action => {
                                       this.$router.push({name:"commentsshow"});
                                   }
                               });
                           }else{
                              this.$message.error(res.data.msg)
                           }
                       }).catch(()=>{
                           this.$message.error("未知错误")
                       })
                    }
                })
            },
            fetchData:function(){
               this.$http.get(this.url,{
                   params:{
                       id:this.$route.params.id
                   }
               }).then((res)=>{
                   if(res.data.code===200){
                       this.$message.success(res.data.msg);
                       this.form=res.data.data;
                   }else{
                       this.$message.error(res.data.msg);
                   }
               }).catch(function(){
                  this.$message.error("未知错误");
               }.bind(this))
            }
        },
        mounted: function () {
            this.$store.commit("changeActive", "/commentsShow");
            this.fetchData();
        }
    }
</script>

<style lang="scss" scoped>
    .avatar-uploader-icon {
        font-size: 28px;
        color: #8c939d;
        width: 178px;
        height: 178px;
        line-height: 178px;
        text-align: center;
        border: 1px dashed #d9d9d9;
    }

    .avatar-uploader-icon:hover {
        border-color: #409EFF;
    }

    .avatar {
        width: 178px;
        height: 178px;
        display: block;
    }
</style>