<template>
    <div>
        <el-col :span="12">
            <el-form ref="form" :model="form" label-width="80px" :rules="rules">
                <el-form-item label="用户名" prop="username">
                    <el-input v-model="form.username" placeholder="请输入用户名"></el-input>
                </el-form-item>
                <el-form-item label="密码" prop="password">
                    <el-input v-model="form.password" placeholder="请输入密码" type="password"
                              :show-password="true"></el-input>
                </el-form-item>
                <el-form-item label="性别" prop="sex">
                    <el-radio v-model="form.sex" label="1">男</el-radio>
                    <el-radio v-model="form.sex" label="0">女</el-radio>
                </el-form-item>
                <el-form-item label="头像" prop="avatar">
                    <el-upload
                            class="avatar-uploader" action="/api/upload/upload"
                            :show-file-list="false" :on-success="handleAvatarSuccess"
                            :before-upload="beforeAvatarUpload"
                    >
                        <div slot="tip" class="el-upload__tip">只能上传jpg/png文件，且不超过500kb</div>
                        <img v-if="form.avatar" :src="form.avatar" class="avatar">
                        <i v-else class="el-icon-plus avatar-uploader-icon"></i>
                    </el-upload>
                    <el-input type="hidden" v-model="form.avatar"></el-input>
                </el-form-item>
                <el-form-item label="个性签名" prop="sign">
                    <el-input v-model="form.sign" type="textarea"></el-input>
                </el-form-item>
                <el-form-item>
                    <el-button type="primary" @click="submit">立即创建</el-button>
                </el-form-item>
            </el-form>
        </el-col>
    </div>
</template>
<script>
    export default {
        name: "UserAdd",
        data: () => {
            let passwordValid = (rules, val, callback) => {
                let reg = /^[0-9a-zA-Z]{6,}$/;
                if (reg.test(val)) {
                    callback();
                } else {
                    callback(new Error("密码必须由6位以上的字母或者数字组成"));
                }
            };
            return {
                form: {
                    username: '',
                    password: '',
                    sex: '',
                    sign:'',
                    avatar: ''
                },
                rules: {
                    username: [
                        {
                            required: true,
                            message: "必须填写用户名",
                            trigger: "blur"
                        }
                    ],
                    password: [
                        {
                            required: true,
                            message: "请输入密码",
                            trigger: "blur"
                        },
                        {
                            validator: passwordValid,
                            trigger: "blur"
                        }
                    ],
                    sex: [{
                        required: true,
                        message: "请选择性别",
                        trigger: "change"
                    }],
                    avatar:[{
                        required:true,
                        message:"请上传头像",
                        trigger:"blur"
                    }],
                    sign:[
                        {
                            required:true,
                            message:"请输入个性签名",
                            trigger:"blur"
                        }
                    ]
                }
            }
        },
        methods: {
            handleAvatarSuccess: function (r) {
                if (r !== "") {
                    this.$message({
                        message: "上传成功",
                        type: "success"
                    });
                    this.form.avatar = r;
                } else {
                    this.$message({
                        message: "上传失败",
                        type: "error"
                    });
                }

            },
            beforeAvatarUpload(file) {
                const isJPG = file.type === 'image/jpeg' || file.type === 'image/png';
                const isLt500Kb = file.size / 1024 / 1024 < 0.5;

                if (!isJPG) {
                    this.$message.error('上传头像图片只能是 JPG或者PNG 格式!');
                }
                if (!isLt500Kb) {
                    this.$message.error('上传头像图片大小不能超过 500kb!');
                }
                return isJPG && isLt500Kb;
            },
            submit: function () {
                this.$refs.form.validate((v) => {
                    if (v) {
                     this.$http.post("/api/users/users",this.form).then(r=>{
                            if(r.data.code===200){
                                this.$alert('添加成功','', {confirmButtonText: '确定',
                                    callback: () => {
                                    this.$router.push({name:"usershow"})
                                    }
                                });
                            }else{
                                this.$message.error(r.data.msg);
                            }
                        }).catch(()=>{
                            this.$message.error("未知错误");
                     })
                    }
                })
            },
        },
        mounted:function(){
            //console.log(this.$store.state.active);
            this.$store.commit("changeActive","/userAdd");
        }
    }
</script>
<style lang="scss" scoped>
    .avatar-uploader-icon {
        font-size: 28px;
        color: #8c939d;
        width: 178px;
        height: 178px;
        line-height: 178px;
        text-align: center;
        border: 1px dashed #d9d9d9;
    }

    .avatar-uploader-icon:hover {
        border-color: #409EFF;
    }

    .avatar {
        width: 178px;
        height: 178px;
        display: block;
    }
</style>