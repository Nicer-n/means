<template>
    <div class="main">
        <el-row class="row">
            <el-col :span="8" :offset="8" class="container">
               <el-form label-width="80px" :model="form" :rules="rules" ref="myform">
                   <el-form-item label="用户名" prop="name">
                       <el-input v-model="form.name"></el-input>
                   </el-form-item>
                   <el-form-item label="密码" prop="password">
                       <el-input v-model="form.password" type="password"></el-input>
                   </el-form-item>
                   <el-form-item label="验证码" prop="code">
                       <el-input v-model="form.code"></el-input>
                   </el-form-item>
                   <el-form-item>
                       <img :src="src" alt="" @click="refresh">
                   </el-form-item>
                   <el-form-item>
                       <el-button type="success" size="medium" @click="submit">登录</el-button>
                   </el-form-item>
               </el-form>
            </el-col>
        </el-row>
    </div>
</template>

<script>
    export default {
        name: "login",
        data: () => ({
            src:"/api/admin/captcha",
            form:{
               name:"",
               password:"",
               code:""
            },
            rules:{
               name:[{
                   required:true,
                   message:"请输入管理员姓名",
                   trigger:"blur"
               }],
               password:[{
                   required:true,
                   message:"请输入密码",
                   trigger:"blur"
               }],
               code:[{
                    required:true,
                    message:"请输入验证码",
                    trigger:"blur"
               },{
                   min:4,
                   max:4,
                   message:"验证码长度是四位",
                   trigger:"blur"
               }]
            }
        }),
        methods:{
            refresh:function(){
                this.src="/api/admin/captcha?t="+Date.now();
            },
            submit:function(){
              this.$refs.myform.validate((valid)=>{
                  if(valid){
                      this.$http.post("/api/admin/checkLogin",this.form).then(res=>{
                         if(res.data.code===200){
                             this.$message.success("登录成功");
                             sessionStorage.login=JSON.stringify({name:res.data.name,role:res.data.role,login:true});
                             sessionStorage.token=res.data.token;
                             location.reload();
                         }else{
                             this.$message.error(res.data.msg);
                         }
                      }).catch(()=>{
                          this.$message.error("登录失败");
                      })
                  }else{
                      return false;
                  }
              })
            }
        }

    }
</script>

<style lang="scss" scoped>
    .main {
        width: 100%;
        height: 100%;
        background: url("./assets/bg.jpg");
        display: flex;
        align-items: center;
    }

    .row {
        width: 100%;
        height: 350px;
    }
    .container{
        height:350px;
        background: rgba(255, 255, 255, 0.62);
        padding:30px;
    }
</style>