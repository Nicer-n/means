# 前后端分离 
## 前端
* 语言 HTML5 CSS3 JavaScript
* 开发框架 vue.js 组件化开发模式  响应式的数据绑定
* webpack 打包工具 vue.js  .vue .scss es6 =>html css js
* 构建工具 脚手架  @vue/cli 只是把我们要使用webpack需要配置的东西进行更高级的封装 让我直接专注于开发省去配置的麻烦
* 前端路由 可以根据地址(这里说的地址的改变只是一个假的改变，也就说这种改变只会生成历史记录，不会引起网页的跳转)的不同 渲染对应的组件   vue-router插件  router.js实现的
* 前端布局框架 组件库  ELEMENT-UI  
* 数据交互  ajax   axios将原生ajax封装后的一个插件 
* vue ui 界面化的项目管理软件      
## 后端
* 语言 PHP 
* 开发框架 ThinkPHP
* 数据库 MySQL 
* 数据库管理软件 phpMyAdmin/navicat for MySQL 

 