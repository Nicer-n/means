// vue.config.js
module.exports = {
    devServer: {
        proxy: {
            '/api': {
                //请求的地址
                target: 'http://www.i-cake.com',
                //是否跨域
                changeOrigin: true,
                //websocket配置
                ws: true,
                //路径重写规则  /api/users/users
            },
            '/uploads':{
                //请求的地址
                target: 'http://www.i-cake.com',
                //是否跨域
                changeOrigin: true,
            }
        }
    },
    publicPath:"./"
};