import Vue from 'vue'
import Vuex from 'vuex'
// import {ADDFN} from "./mutation_types.";
Vue.use(Vuex);

export default new Vuex.Store({
  state: {
    orderList:[] //所有订单
  },
  getters:{
    //所有订单
    orderList(state){
      return state.orderList;
    },
    /*购物车列表*/
    carList(state){
      return state.orderList.filter(v=>v.state===0);
    },
    /*待发货列表*/
    sendList(state){
      return state.orderList.filter(v=>v.state===1);
    },
    /*待收货列表*/
    getList(state){
      return state.orderList.filter(v=>v.state===2);
    },
    /*待评价列表*/
    commitList(state){
      return state.orderList.filter(v=>v.state===3);
    },
    /*退换货列表*/
    backList(state){
      return state.orderList.filter(v=>v.state===4);
    },
    //购物车商品种类
    carLength(state,getters){
      return getters.carList.length;
    },

    /*判断当前订单当中有没有某个商品*/
    hasSomeGoods(state,getters){
      return function (id) {
        let obj=getters.carList.find(function (obj) {
          if (obj.gid == id) {
            return true;
          }
        });
        if (obj){
          return obj;
        } else{
          return false
        }
      }
    },
    /*需要结算的订单*/
    payList(state){
      return state.orderList.filter(v=>v.checked);
    }
  },
  mutations: {
    add(state,payload){
      state.orderList.push(payload);
    },
    remove(state,payload){
      let index=state.orderList.findIndex((obj)=>{
        if (obj.gid===payload.id) {
          return true;
        }
      });
      state.orderList.splice(index,1);
    },
    concat(state,payload){
      //pagyload 从数据库中获取到的当前用户的购物车信息
      //orderList 当前用户向购物车中天价的信息
      payload=payload.filter(function (v) {
        //v 是数据库中当前用户的每一个订单
          let r=state.orderList.find(function (val) {
            //val vuex当前用户的每一个订单
            if(val.gid==v.gid && val.state==v.state){
              return true;
            }
          });
          if (r){
            //r为真值 说明有重复
            return false;
          } else{
            return true;
          }
      });
      state.orderList=[...state.orderList,...payload]
    }
  },
  actions: {

  }
})
