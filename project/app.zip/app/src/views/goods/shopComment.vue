<template>
    <div>
        <div class="content">
            <my-header></my-header>
            <!--顶部导航开始-->
            <div class="header dongContainer">
                <a href="detail.html">
                    <div class="choose">商品详情</div>
                </a>
                <a href="">
                    <div class="choose active">商品评论<span></span></div>
                </a>
            </div>
            <!--顶部导航结束-->
            <!--用户留言开始-->
            <div class="userSaw dongContainer">
                <ul class="userBox">
                    <li>
                        <div class="userImg">
                            <img src="../../assets/images/userHead1.png" alt="">
                        </div>
                        <div class="userMessage">
                            <h1>我家有只猫 <span class="iBox"><i class="iconfont icon-xingxing"></i><i class="iconfont icon-xingxing"></i><i class="iconfont icon-xingxing"></i><i class="iconfont icon-xingxing"></i><i class="iconfont icon-bankexingxing1"></i></span></h1>
                            <h2>发货速度很快，卖家服务态度相当不错！</h2>
                            <div class="userMessageImageBox">
                                <div class="imgBox"><img src="../../assets/images/userSayImg1.png" alt=""></div>
                                <div class="imgBox"><img src="../../assets/images/userSayImg2.png" alt=""></div>
                            </div>
                            <h3><i class="fontBeCircle"></i>紫色<span>2019-03-20 15:09:02发布</span></h3>
                        </div>
                    </li>
                    <li>
                        <div class="userImg">
                            <img src="../../assets/images/userHead2.png" alt="">
                        </div>
                        <div class="userMessage">
                            <h1>我家有只猫<span class="iBox"><i class="iconfont icon-xingxing"></i><i class="iconfont icon-xingxing"></i><i class="iconfont icon-xingxing"></i><i class="iconfont icon-xingxing"></i></span></h1>
                            <h2>网购很久，但是家具网购还是第一次买，和实
                                体店一样，物美价廉，省心购物。</h2>
                            <h2>追加：<span>追加：坐的很舒服，推荐给闺蜜了。</span></h2>
                            <h3><i class="fontBeCircle green"></i>绿色<span>2019-01-20 13:25:02发布</span></h3>
                        </div>
                    </li>
                    <li class="noneBorder">
                        <div class="userImg">
                            <img src="../../assets/images/userHead3.png" alt="">
                        </div>
                        <div class="userMessage">
                            <h1>我家有只猫<span class="iBox"><i class="iconfont icon-xingxing"></i><i class="iconfont icon-xingxing"></i><i class="iconfont icon-xingxing"></i><i class="iconfont icon-xingxing"></i></span> </h1>
                            <h2>网购很久，但是家具网购还是第一次买，和实
                                体店一样，物美价廉，省心购物。</h2>
                            <h2>追加：<span>追加：坐的很舒服，推荐给闺蜜了。</span></h2>
                            <h3><i class="fontBeCircle green"></i>绿色<span>2019-01-20 13:25:02发布</span></h3>
                        </div>
                    </li>
                </ul>
            </div>
            <div class="noMessage">
                <span></span>
                <i>暂无更多数据</i>
                <span></span>
            </div>
            <!--用户留言结束-->
        </div>

    </div>
</template>

<script>
    import Header from "@/components/Header";

    export default {
        name: "shopComment",
        data: () => ({}),
        components:{
            "my-header":Header
        }
    }
</script>

<style lang="scss" scoped>
    .content{
        width: 100%;
        height: auto;
        padding-top: 0.88rem;
    }
    .dongContainer{
        padding: 0 0.24rem;
    }
    a{
        color: #000;
    }
    *{
        font-family: "微软雅黑";
    }
    i{
        font-style: normal;
    }
    body{
        padding-top: 0.88rem;
    }
    /*顶部开始*/
    .header{
        width: 7.5rem;
        height: 0.8rem;
        border-bottom: 0.01rem solid #ffcb3f;
        border-top: 0.01rem solid #f2f2f2;
        font-size: 0.24rem;
        text-align: center;
        line-height: 0.75rem;
        display: flex;
        justify-content: space-around;
    }
    .choose{
        width: 1rem;
        height: 100%;
    }
    .choose span{
        display: block;
        width: 0.46rem;
        height: 0.03rem;
        background: #ffcb3f;
        margin: 0 auto;
    }
    .active{
        font-weight: bold;
        color: #ffcb3f;
    }
    /*顶部结束*/
    /*用户留言开始*/
    .userSaw{
        width: 100%;
        height: 10.5rem;
    }
    .userBox{
        width: 100%;
        height: 100%;
    }
    .userBox>li{
        width: 100%;
        height: 3.5rem;
        padding-top: 0.46rem;
        border-bottom: 0.01rem solid #d7d7d7;
        position: relative;
    }
    .noneBorder{
        border: none!important;
    }
    .noneBorder:after{
        content: '';
        background: none!important;
    }
    .userBox>li:after{
        content: "";
        width: 0.47rem;
        height: 0.02rem;
        background: #ffcb3f;
        position: absolute;
        bottom: 0;
        left: 0;
    }
    .userImg{
        width: 1.2rem;
        height: 1.2rem;
        float: left;
    }
    .userImg>img{
        width: 100%;
        height: 100%;
    }
    .userMessage{
        width: 5.25rem;
        margin-left: 0.28rem;
        float: left;
    }
    .iBox{
        display: inline-block;
        flex-direction: row;
        margin-left: 0.1rem;
    }
    .icon-xingxing{
        color: #ffcb3f!important;
    }
    .icon-bankexingxing1{
        color: #ffcb3f!important;
    }
    .userMessage>h1{
        font-size: 0.28rem;
        letter-spacing: 0.03rem;
        color: #333333;
        margin-bottom: 0.28rem;
        font-weight: normal;
    }
    .userMessage>h2{
        font-size: 0.24rem;
        line-height: 0.36rem;
        letter-spacing: 0.02rem;
        margin-bottom: 0.14rem;
        font-weight: normal;
    }
    .userMessage>h2>span{
        font-size: 0.18rem;
        font-weight: normal;
    }
    .userMessageImageBox{
        height: 1.32rem;
    }
    .imgBox{
        width: 2.02rem;
        height: 100%;
        float: left;
    }
    .imgBox>img{
        width: 100%;
        height: 100%;
    }
    .imgBox{
        margin-right: 0.14rem;
    }
    .userMessage>h3{
        font-size: 0.18rem;
        color: rgba(0,0,0,0.7);
        font-weight: normal;
        margin-top: 0.21rem;
    }
    .fontBeCircle{
        display: inline-block;
        width: 0.07rem;
        height: 0.07rem;
        border-radius: 50%;
        background: #d880d7;
        margin-right: 0.03rem;
        vertical-align: middle;
    }
    .userMessage>h3>span{
        margin-left: 0.79rem;
    }
    .green{
        background: #b5d548;
    }
    .userMessage>h1>i{
        margin-left: 0.15rem;
    }
    /*用户留言结束*/
    .noMessage{
        width: 100%;
        height: 0.19rem;
        text-align: center;
        line-height: 0.19rem;
        font-size: 0.18rem;
        color: rgba(0,0,0,0.7);
    }
    .noMessage>span{
        display: inline-block;
        width: 1.05rem;
        height: 0.02rem;
        background: #d7d7d7;
    }
    .noMessage>i{
        margin: 0 0.26rem;
    }
</style>