<template>
    <div id="body">
        <my-header>
            <a href="#" class="headerExit" @click="$router.go(-1)">
                <i class="iconfont icon-guanbi"></i>
            </a>
        </my-header>
        <div class="content">


            <!--头部以下收货地址标题-->
            <div class="newAddAdress">
                <div class="backImg">
                    <i class="iconfont icon-xiangzuo"></i>
                </div>
                <div class="newAddAdressTitle">收货地址</div>
            </div>
            <!--主要部分开始-->

            <!--<div class="box">-->
                <!--<div class="mainContent" style="margin-left: -1.84rem;overflow: scroll">-->
                    <!--<div class="mainContentBox">-->
                        <!--<div class="firstFloor">-->
                            <!--<span class="name">王清</span>-->
                            <!--<span class="phone">18735184627</span>-->
                            <!--<span class="address">公司</span>-->
                        <!--</div>-->
                        <!--<div class="secondFloor">-->
                            <!--山西省太原市小店区万柏林街道幸福里小区4号楼1204-->
                        <!--</div>-->
                        <!--<a href="" class="bianji">-->
                            <!--<i class="iconfont icon-edit"></i>-->
                        <!--</a>-->
                    <!--</div>-->
                    <!--<a href="" class="moRen">设为默认</a>-->
                    <!--<a href="" class="delect">删除</a>-->
                <!--</div>-->
            <!--</div>-->

            <div
                    :class="['box',{active:index===item.id}]"
                    v-for="item in addressList"
                    @click="index=item.id"
            >
                <div class="mainContent">
                    <div class="mainContentBox">
                        <div class="firstFloor">
                            <span class="name">{{item.name}}</span>
                            <span class="phone">{{item.phone}}</span>
                            <span class="address">{{item.type}}</span>
                        </div>
                        <div class="secondFloor">
                            {{item.province}}{{item.city}}{{item.area}}{{item.address}}
                        </div>
                        <a href="" class="bianji">
                            <i class="iconfont icon-edit"></i>
                        </a>
                    </div>
                    <a href="" class="moRen">设为默认</a>
                    <a href="" class="delect">删除</a>
                </div>
            </div>
            <div  class="btns" @click="chooes">设置为默认地址</div>
        </div>
    </div>
</template>

<script>
    import Header from "@/components/Header";
    export default {
        name: "Address",
        data: () => ({
            addressList:[],
            index:0,
        }),
        components:{
            "my-header":Header,
        },
        methods:{
            fetchUserAddress(){
                this.$http.get("/api/address/address",{
                    params:{
                        uid:localStorage.login,
                    }
                }).then(r=>{
                   if (r.data.code===200){
                       this.addressList=r.data.data;
                       this.addressList.forEach(v=>{
                           if (v.type){
                               switch (v.type) {
                                   case 1:v.type="住宅"; break;
                                   case 2:v.type="公司";break;
                                   case 3:v.type="学校";break;
                                   default:v.type="其他";
                               }
                           }
                       })
                   }else{
                       console.log("数据查询失败");
                   }
                }).catch(()=>{
                    console.log("说句获取失败");
                })
            },
            chooes(){
                if (this.index===0){
                    alert("请选择收获地址");
                    return
                }
                let address=this.addressList.find(v=>v.id===this.index);
                localStorage.address=JSON.stringify(address);
                this.$router.back();
            }
        },
        mounted(){
            // if (localStorage.address){
            //     this.address=JSON.parse(localStorage.address);
            //     localStorage.removeItem("address")
            // }else{
                this.fetchUserAddress();
            // }

        }
    }
</script>

<style lang="scss" scoped>
    /*#body{*/
        /*width: 100%;*/
        /*height: 100%;*/
        /*background: #f6f6f6;;*/
    /*}*/
    .content{
        padding-top: 0.88rem;

    }
    * {
        margin: 0;
        padding: 0;
        list-style: none;
    }

    a {
        text-decoration: none;
    }

    html {
        font-family: 微软雅黑;
    }

    /*头部下边第一块*/
    .newAddAdress {
        width: 100%;
        height: 0.8rem;
        background: white;
        padding: 0 0.24rem;
        box-sizing: border-box;
        display: flex;
        align-items: center;
        border-bottom: 0.01rem solid #d9d9d9;
        border-top: 0.01rem solid #d9d9d9;
    }

    .backImg {
        width: 0.18rem;
        height: 0.28rem;
        //background: #ff2b77;

    }
    .backImg i{
        float: left;
        display: block;
    }

    .newAddAdressTitle {
        font-size: 0.28rem;
        margin: 0 auto;
        color: #000000;
    }

    /*主要内容开始*/
    .box{
        width: 100%;
        height: 1.36rem;
        background: white;
        overflow: visible;
        margin: 0.02rem auto 0;
        position: relative;
        box-sizing: border-box;
        //border-bottom: 0.03rem solid #666666;
    }
    .box.active{
        background: #ffcb3f;
    }
    .mainContent {
        width: 7.02rem;
        height: 1.36rem;
        /*background: white;*/
        overflow: hidden;
        margin: 0 auto;
        //margin-left: - 1.84 rem;
        position: relative;
    }

    .mainContentBox {
        width: auto;
        height: 1.36rem;
        //background: #ff2b77;
        position: relative;
    }

    .firstFloor {
        height: 0.65rem;
        /*/ / background: #8943ff;*/
        position: absolute;
        top: 0.10rem;
    }

    .name {
        font-size: 0.3rem;
        color: black;
        float: left;
    }

    .phone {
        font-size: 0.28rem;
        color: black;
        float: left;
        margin-left: 0.48rem;
    }

    .address {
        width: 0.65rem;
        height: 0.39rem;
        text-align: center;
        line-height: 0.39rem;
        font-size: 0.22rem;
        color: #666666;
        float: left;
        margin-left: 0.18rem;
        background: #ffcb3f;
        border-radius: 0.07rem;
    }

    .secondFloor {
        height: 0.65rem;
        width: 6.20rem;
        /*background: #ff1d33;*/
        position: absolute;
        top: 0.7rem;
        font-size: 0.22rem;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
        color: #666666;
    }

    .bianji {
        width: 0.35rem;
        height: 0.35rem;
        //background: aqua;
        float: right;
        display: block;
        margin-top: 0.65rem;
        margin-right: 0.3rem;
        color: #666666;
    }
    .bianji i{
        width: 100%;
        height: auto;
        display: block;
    }
    .moRen {
        width: 1.15rem;
        height: 1.36rem;
        display: block;
        position: absolute;
        top: 0;
        right: -1.15rem;
        font-size: 0.22rem;
        /*background: #f4f4f4;*/
        text-align: center;
        border-left: 0.02rem solid #000000;
        line-height: 1.36rem;
        color: #666666;
    }
    .delect {
        width: 1.15rem;
        height: 1.36rem;
        text-align: center;
        display: block;
        position: absolute;
        top: 0;
        right: -2.3rem;
        font-size: 0.22rem;
        background: #ffcb3f;
        line-height: 1.36rem; color: #666666;
    }

    .btns {
        width: 6.39rem;
        height: 0.79rem;
        background: #ffcb3f;
        /*margin: 4.66rem auto 0;*/
        text-align: center;
        line-height: 0.79rem;
        border-radius: 0.1rem;
        display: block;color: white;
        font-size: 0.28rem;
        position: fixed;
        bottom: 0.4rem;
        left: 0;
        right:0;
        margin: 0 auto;

    }

</style>