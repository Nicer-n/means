<template>
    <div style="height: 100%;padding-top: 0.88rem">
        <my-header>
            <a href="#" class="headerExit" @click="$router.go(-1)">
                <i class="iconfont icon-guanbi"></i>
            </a>
        </my-header>
        <div class="content" ref="wrapper">
            <div class="inner">


            <!--标题开始-->
            <div class="payTitle">
                <div class="back">
                    <!--icon图标-->
                    <i class="iconfont icon-xiangzuo"></i>
                </div>
                <h3>我的订单</h3>
            </div>
            <!--标题结束-->
            <!--导航选项卡开始-->
            <div class="navBox">
                <ul>
                    <swiper :options="options" ref="mySwiper">
                        <swiper-slide>
                            <li :class="['item',{active:state===10}]" @click="state=10">全部</li>
                        </swiper-slide>
                        <swiper-slide>
                            <li :class="['item',{active:state==='0'}]" @click="state='0'">待付款</li>
                        </swiper-slide>
                        <swiper-slide>
                            <li :class="['item',{active:state==='1'}]" @click="state='1'">待发货</li>
                        </swiper-slide>
                        <swiper-slide>
                            <li :class="['item',{active:state==='2'}]" @click="state='2'">待收货</li>
                        </swiper-slide>
                        <swiper-slide>
                            <li :class="['item',{active:state==='3'}]" @click="state='3'">待评价</li>
                        </swiper-slide>
                        <swiper-slide>
                            <li :class="['item',{active:state==='4'}]" @click="state='4'">退款</li>
                        </swiper-slide>






                    </swiper>
                </ul>
            </div>
            <!--导航选项卡结束-->
            <!--订单内容开始-->
            <div class="orderItem">
                <ul class="CarList" v-if="state===10">
                    <li v-for="item in orderList">
                        <div class="goods">
                            <img :src="item.thumb" alt="">
                        </div>
                        <div class="goodsItem">
                            <p>{{item.name_en}}<span class="goodsName">{{item.name_ch}}</span></p>
                            <h3 class="goodsType">{{item.colors}}/{{item.kinds}}</h3>
                            <h3 class="date">2019-03-20</h3>
                        </div>
                        <div class="goodsNumber">
                            <h3 class="number">￥{{item.goods_price}}*{{item.number}}</h3>
                            <div class="goodsPrice">
                                <h3>{{item.price}} <span>RMB</span></h3>
                            </div>
                            <div class="status">
                                <div class="payBtn2">{{item.stateText}}</div>
                                <!--<h3 ></h3>-->
                                <!--{{item.stateText}}-->
                            </div>
                            <!--<div class="status">-->
                                <!--<div class="cancel">取消订单</div>-->
                                <!--<div class="payBtn">付款</div>-->
                            <!--</div>-->
                        </div>

                    </li>
                </ul>
                <ul class="CarList" v-if="state==='0'">
                    <li v-for="item in carList">
                        <div class="goods">
                            <img :src="item.thumb" alt="">
                        </div>
                        <div class="goodsItem">
                            <p>{{item.name_en}}<span class="goodsName">{{item.name_ch}}</span></p>
                            <h3 class="goodsType">{{item.colors}}/{{item.kinds}}</h3>
                            <h3 class="date">2019-03-20</h3>
                        </div>
                        <div class="goodsNumber">
                            <h3 class="number">￥{{item.goods_price}}*{{item.number}}</h3>
                            <div class="goodsPrice">
                                <h3>{{item.price}} <span>RMB</span></h3>
                            </div>
                        </div>
                        <div class="status">
                            <div class="cancel">取消订单</div>
                            <router-link class="payBtn" to="/Order">付款</router-link>
                        </div>
                    </li>
                </ul>
                <ul class="CarList" v-if="state==='1'">
                    <li v-for="item in sendList">
                        <div class="goods">
                            <img :src="item.thumb" alt="">
                        </div>
                        <div class="goodsItem">
                            <p>{{item.name_en}}<span class="goodsName">{{item.name_ch}}</span></p>
                            <h3 class="goodsType">{{item.colors}}/{{item.kinds}}</h3>
                            <h3 class="date">2019-03-20</h3>
                        </div>
                        <div class="goodsNumber">
                            <h3 class="number">￥{{item.goods_price}}*{{item.number}}</h3>
                            <div class="goodsPrice">
                                <h3>{{item.price}} <span>RMB</span></h3>
                            </div>
                        </div>
                        <div class="status">
                            <div class="cancel">取消订单</div>
                            <div class="payBtn1" >提醒发货</div>
                        </div>
                    </li>
                </ul>
                <ul class="CarList" v-if="state==='2'">
                    <li v-for="item in getList">
                        <div class="statusText">卖家已发货</div>
                        <div class="goods">
                            <img :src="item.thumb" alt="">
                        </div>
                        <div class="goodsItem">
                            <p>{{item.name_en}}<span class="goodsName">{{item.name_ch}}</span></p>
                            <h3 class="goodsType">{{item.colors}}/{{item.kinds}}</h3>
                            <h3 class="date">2019-03-20</h3>
                        </div>
                        <div class="goodsNumber">
                            <h3 class="number">￥{{item.goods_price}}*{{item.number}}</h3>
                            <div class="goodsPrice">
                                <h3>{{item.price}} <span>RMB</span></h3>
                            </div>
                        </div>
                        <div class="status">
                            <div class="cancel">查看物流</div>
                            <div class="payBtn1">确认收货</div>
                        </div>
                    </li>
                </ul>
                <ul class="CarList" v-if="state==='3'">
                    <li v-for="item in commitList">
                        <div class="goods">
                            <img :src="item.thumb" alt="">
                        </div>
                        <div class="goodsItem">
                            <p>{{item.name_en}}<span class="goodsName">{{item.name_ch}}</span></p>
                            <h3 class="goodsType">{{item.colors}}/{{item.kinds}}</h3>
                            <h3 class="date">2019-03-20</h3>
                        </div>
                        <div class="status">
                            <div class="payBtn1">我要评价</div>
                        </div>
                    </li>
                </ul>
                <ul class="CarList" v-if="state==='4'">
                    <li v-for="item in backList">
                        <div class="goods">
                            <img :src="item.thumb" alt="">
                        </div>
                        <div class="goodsItem">
                            <p>{{item.name_en}}<span class="goodsName">{{item.name_ch}}</span></p>
                            <h3 class="goodsType">{{item.colors}}/{{item.kinds}}</h3>
                            <h3 class="date">2019-03-20</h3>
                        </div>
                        <div class="goodsNumber">
                            <h3 class="number">￥{{item.goods_price}}*{{item.number}}</h3>
                            <div class="goodsPrice">
                                <h3>{{item.price}} <span>RMB</span></h3>
                            </div>
                            <div class="status">
                                <h3>{{item.stateText}}</h3>
                            </div>
                        </div>

                    </li>
                </ul>
            </div>
            <!--订单内容结束-->
                <my-goods :goods="this.goods"></my-goods>
            </div>
        </div>
        <my-footer hot="personal"></my-footer>
    </div>
</template>

<script>
    import Header from "@/components/Header";
    import Footer from "@/components/Footer";
    import Goods from "@/components/Goods";
    import 'swiper/dist/css/swiper.css'
    import {swiper, swiperSlide} from 'vue-awesome-swiper'
    import {mapMutations,mapGetters} from "vuex"
    import BScroll from 'better-scroll'
    export default {
        name: "OrderList",
        data: () => ({
            page:1,
            total:0,

            goods:[],
            state:10,
            options:{
                slidesPerView: 5,
                // freeMode:true,
            }
        }),
        computed:{
            ...mapGetters(["orderList","sendList","carList","getList","commitList","backList","carLength"]),
            swiper:function () {
                return this.$refs.mySwiper.swiper
            },
        },
        components:{
            "my-header":Header,
            "my-footer":Footer,
            "my-goods":Goods,
            swiper,
            swiperSlide
        },
        methods:{
          ...mapMutations(["concat"])  ,
            fetchGoodsData: function () {
                this.$http.get("/api/goods/goods", {
                    params: {
                        page: this.page,
                        pageSize: 4
                    }
                }).then(r => {
                    if (r.data.code === 200) {
                        this.goods = [...this.goods, ...r.data.data];
                        this.total = r.data.total;
                        if (!this.scroll) {
                            this.$nextTick(() => {
                                this.scroll = new BScroll(this.$refs.wrapper, {
                                    pullUpLoad: {
                                        thresholds: 0
                                    },
                                    click: true //允许触发点击效果
                                });
                                this.scroll.on("pullingUp", () => {
                                    if (this.page * 4 > this.total) {
                                        this.scroll.finishPullUp();
                                        return;
                                    }
                                    this.page++;
                                    this.fetchGoodsData();
                                    this.scroll.finishPullUp();
                                })
                            });
                        }
                    }
                }).catch()
            },
            fetchOrderList:function () {
                this.$http.get("/api/orders/orders",{
                    params:{
                        uid:localStorage.login
                    }
                }).then(r=>{
                    if (r.data.code){
                        let orderList=r.data.data;
                        orderList.forEach(v=>{
                            v.checked=false;
                        });
                        this.concat(orderList);
                    }else{
                        console.log("获取失败")
                    }
                }).catch(()=>{
                    console.log("获取失败")
                })
            },

        },
        // beforeRouteLeave(to,from,next){
        //     this.carList.forEach(v=>{
        //         if (to.name!=="order") {
        //             v.checked=false;
        //         }
        //         v.price=v.number*v.goods_price;
        //         delete v.id
        //     });
        //     this.$http.post("/api/orders/addOrder",{
        //         data:this.carList,
        //         uid:localStorage.login
        //     }).then(r=>{
        //         if (r.data.code===200){
        //             console.log("同步成功");
        //         } else{
        //             console.log("同步失败");
        //         }
        //     }).catch(()=>{
        //         console.log("提交失败")
        //     });
        //     next();
        // },
        mounted(){
            if ( this.$route.query.state){
                this.state=this.$route.query.state;
            }
            if (this.state==="4"){
                this.swiper.slideNext();
            }
            this.fetchOrderList();
            this.fetchGoodsData();
            this.orderList.forEach(v=>{
                switch (v.state) {
                    case 0:v.stateText="待付款";break;
                    case 1:v.stateText="待发货";break;
                    case 2:v.stateText="待收货";break;
                    case 3:v.stateText="待评价";break;
                    case 4:v.stateText="退款";break;
                }
            });
            // if (localStorage.goods){
            //     let obj=JSON.parse(localStorage.goods);
            //     obj.uid=localStorage.login;
            //     this.add(obj);
            //     localStorage.removeItem("goods");
            // }
        }
    }
</script>

<style lang="scss" scoped>
    .content{
        /*width: 100%;*/
        height: 100%;
        padding-top: 0.88rem;
        overflow: hidden;
        position: relative;
    }
    body{
        background: #fcfcfc;
        padding-top: 0.88rem;
    }
    /*标题开始*/
    .payTitle{
        width: 100%;
        height: 0.78rem;
        background: #fff;
        padding: 0 0.24rem;
        border-top: 1px solid #eeeeee;
        border-bottom: 1px solid #eeeeee;
        box-sizing: border-box;
    }
    .payTitle h3{
        font-size: 0.28rem;
        text-align: center;
        line-height: 0.78rem;
    }
    .payTitle .back{
        width: 0.24rem;
        height: 0.24rem;
        float: left;
        margin-top: 0.27rem;
    }
    .back i{
        float: left;
        text-align: center;
        line-height: 0.24rem;
        font-size: 0.24rem;
    }
    /*标题结束*/
    /*顶部选项卡开始*/
    .navBox{
        width: 100%;
        height: 0.78rem;
        /*padding: 0 0.22rem;*/
        background: #fff;
        border-bottom: 0.01rem solid #ffcb3f;
        /*box-sizing: border-box;*/
    }
    .navBox ul{
        width: 100%;
        height: 100%;
        /*display: flex;*/
        /*justify-content: space-between;*/
        /*justify-content: center;*/
    }
    .item{
        /*width: 2rem;*/
        /*width: auto;*/
        /*height: auto;*/
        position: relative;
        color: rgba(0, 0, 0, 0.7);
        font-size: 0.24rem;
        line-height: 0.78rem;
        text-align: center;
        /*float: left;*/
        /*margin-right: 2rem;*/
    }
    /*.navBox li a{*/
        /*display: block;*/
        /*color: rgba(0, 0, 0, 0.7);*/
        /*font-size: 0.24rem;*/
        /*line-height: 0.78rem;*/
    /*}*/
    .item.active {
        color: #ffcb3f;
        font-weight: bold;
    }
    .item.active:after{
        content: "";
        display: block;
        width: 0.5rem;
        height: 0.03rem;
        background-color: #ffcb3f;
        position: absolute;
        left: 0;
        right: 0;
        bottom: 0;
        margin: 0 auto;
    }
    /*顶部选项卡结束*/
    /*订单内容开始*/
    .orderItem{
        width: 7.02rem;
        height: auto;
        margin: 0 auto 0.5rem;
    }
    .CarList{
        width: 7.02rem;
        height:auto;
        margin: 0 auto;
    }
    .CarList li{
        width: 7.02rem;
        height: 2.76rem;
        background: #fff;
        box-shadow: 0 0.02rem 0.03rem 0
        rgba(0, 0, 0, 0.09);
        border-radius: 0.1rem;
        margin-top: 0.24rem;
        padding-top: 0.52rem;
        position: relative;
    }
    .checkBox{
        width: 0.24rem;
        height: 0.24rem;
        border-radius: 50%;
        border: 0.01rem solid #ffcb3f;
        position: absolute;
        left: 0;
        top: 50%;
        margin-top: -0.12rem;
    }
    .goods{
        width: 1.85rem;
        height: 1.3rem;
        margin-left: 0.2rem;
        float: left;
    }
    .goods img{
        width: 100%;
        height:100%;
        display:block;
    }
    .goodsItem{
        margin-left: 0.2rem;
        height: auto;
        float: left;
        margin-top: 0.1rem;
    }
    .goodsItem p{
        width: 3rem;
        font-size: 0.18rem;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
    }
    .goodsName{
        font-size: 0.24rem;
    }
    .goodsType{
        font-size: 0.18rem;
        margin-top: 0.08rem;
        font-weight: 400;
        color: rgba(0, 0, 0, 0.7);
    }
    .date{
        font-size: 0.18rem;
        color: rgba(0, 0, 0, 0.7);
        margin-top: 0.3rem;
        font-weight: 400;
    }
    .goodsNumber{
        float: right;
        margin-right: 0.24rem;
        margin-top: 0.1rem;
    }
    .number{
        font-size: 0.24rem;
        font-weight: 400;
    }
    .goodsPrice{
        margin-top: 0.65rem;
    }
    .goodsPrice h3{
        font-size: 0.26rem;
    }
    .goodsPrice h3 span{
        font-size: 0.18rem;
        font-weight: 400;
    }
    .status{
        width: 3rem;
        height: 0.45rem;
        font-size: 0.24rem;
        margin-top: 0.1rem;
        /*display: flex;*/
        /*justify-content: space-between;*/
        position: absolute;
        right: 0.3rem;
        bottom: 0.24rem;
    }
    .payBtn{
        width: 1.35rem;
        height: 0.45rem;
        background: #ffcb3f;
        color: #fff;
        text-align: center;
        line-height: 0.45rem;
        border-radius: 0.04rem;
        float: right;
    }
    .payBtn1{
        width: 1.35rem;
        height: 0.45rem;
        border:1px solid  #ffcb3f;
        color: #ffcb3f;
        text-align: center;
        line-height: 0.45rem;
        border-radius: 0.04rem;
        float: right;
    }
    .payBtn2{
        width: 1.35rem;
        height: 0.45rem;
        /*border:1px solid  #ffcb3f;*/
        color: #ffcb3f;
        text-align: center;
        line-height: 0.45rem;
        border-radius: 0.04rem;
        float: right;
        font-weight: bold;
    }
    .cancel{
        width: 1.35rem;
        height: 0.45rem;
        text-align: center;
        line-height: 0.45rem;
        color: #999999;
        float: left;
    }
    .statusText{
        font-size: 0.2rem;
        position: absolute;
        right: 0.29rem;
        top: 0.15rem;
        color: #ffcb3f;

    }
    /*订单内容结束*/
    /*推荐商品开始*/
    #recommendShop{
        padding-bottom: 1.5rem;
    }
    /*推荐商品结束*/
</style>