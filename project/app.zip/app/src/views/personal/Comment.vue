<template>
    <div>我的评论</div>
</template>

<script>
    export default {
        name: "Comment",
        data: () => ({}),

    }
</script>

<style lang="scss" scoped>

</style>