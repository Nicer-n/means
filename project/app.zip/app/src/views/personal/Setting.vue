<template>
    <div>
        <div class="content">
            <my-header></my-header>
            <!--内容标题-->
            <div id="title">
                <!--引入标题部分的icon图标  箭头朝左  颜色已加，直接在css第33行去掉背景色并添加字体大小即可-->
                <i class="iconfont icon-xiangzuo"></i>
                个人信息
            </div>

            <!--内容开始-->
            <div class="container info-box">
                <ul>
                    <li>个人信息
                        <a href="">
                            <!--用户信息部分的icon图标  箭头朝右  颜色已加，直接在css第63行去掉背景色并添加字体大小即可-->
                            <i class="iconfont icon-xiangyou"></i>
                        </a>
                    </li>
                    <li>我的实名认证
                        <a href="">
                            <!--用户信息部分的icon图标  箭头朝右  颜色已加，直接在css第63行去掉背景色并添加字体大小即可-->
                            <i class="iconfont icon-xiangyou"></i>
                        </a>
                    </li>
                    <li>我的收货地址
                        <a href="">
                            <!--用户信息部分的icon图标  箭头朝右  颜色已加，直接在css第63行去掉背景色并添加字体大小即可-->
                            <i class="iconfont icon-xiangyou"></i>
                        </a>
                    </li>
                    <li>我的二维码
                        <a href="">
                            <!--用户信息部分的icon图标  箭头朝右  颜色已加，直接在css第63行去掉背景色并添加字体大小即可-->
                            <i class="iconfont icon-xiangyou"></i>
                        </a>
                    </li>
                    <li>我的发票抬头
                        <a href="">
                            <!--用户信息部分的icon图标  箭头朝右  颜色已加，直接在css第63行去掉背景色并添加字体大小即可-->
                            <i class="iconfont icon-xiangyou"></i>
                        </a>
                    </li>
                    <li>清除缓存
                        <a href="">
                            <!--用户信息部分的icon图标  箭头朝右  颜色已加，直接在css第63行去掉背景色并添加字体大小即可-->
                            <i class="iconfont icon-xiangyou"></i>
                        </a>
                    </li>
                </ul>
            </div>
            <!--内容结束-->

            <!--退出账号开始-->
            <input type="button" value="退出当前账号" class="container">
            <!--退出账号结束-->
        </div>
    </div>
</template>

<script>
    import Header from "@/components/Header";
    export default {
        name: "Setting",
        data: () => ({}),
        components:{
            "my-header":Header,
        }
    }
</script>

<style lang="scss" scoped>
.content{
    padding-top: 0.88rem;
    height: auto;
}
/*背景颜色*/
body{
    background: #f7f7f7;
    padding-top: 0.88rem;
}
/*公共类*/
.container{
    width: 7.03rem;
}
/*头部开始*/

/*头部结束*/

/*内容标题*/
#title{
    width: 100%;
    height: 0.78rem;
    background: #fff;
    border-top: solid 0.01rem #eeeeee;
    border-bottom: solid 0.01rem #eeeeee;
    text-align:center;
    font-size: 0.28rem;
    line-height: 0.78rem;
    padding-left: 0.24rem;
}
#title>i{
    float: left;
    color: #000;
    position: absolute;
    left: 0.24rem;
}

/*内容开始*/
.info-box{
    height: 6.52rem;
    background: #fff;
    margin:0 auto;
    box-shadow: 0 0.02rem 0.03rem 0   rgba(0, 0, 0, 0.09);
    border-radius: 0.1rem;
    padding:0 0.3rem;
}
.info-box>ul{
    width: 100%;
    height: 100%;
}
.info-box>ul>li{
    width: 100%;
    height:0.89rem;
    line-height: 0.89rem;
    font-size: 0.26rem;
    color: #000;
    border-bottom: 0.02rem solid #f2f2f2;
}
.info-box>ul>li>a>i{
    float: right;
    color: #000;
}
/*内容结束*/

/*退出账号开始*/
input[type="button"]{
    display: block;
    height: 0.9rem;
    background: #fff;
    border: solid 0.01rem #f2f2f2;
    margin: 3.19rem auto 0;
    color: #e1184c;
    outline: none;
}
/*退出账号结束*/
/*没有底部*/
</style>