<template>
    <div style="padding-top: 1.5rem;height: 100%">
        <my-header></my-header>
        <!--内容标题-->
        <div id="title">
            <!--引入标题部分的icon图标  箭头朝左  颜色已加，直接在css第33行去掉背景色并添加字体大小即可-->
            <i class="iconfont icon-xiangzuo"></i>
            我的收藏
        </div>
        <div class="content" ref="wrapper">
            <div class="inner">


        <!--内容部分开始-->
        <div class="section">
            <ul class="container">
                <li v-for="item in collectGoods">
                    <!--点击整个商品详情的框进入商品详情页-->
                    <div class="shop-container">
                        <div class="goods">
                            <img :src="item.thumb" alt="">
                        </div>
                        <div class="goods-item">
                            <p>{{item.name_en}}}<span class="goods-name">{{item.name_ch}}</span></p>
                            <h3 class="goods-type">白色/单人座</h3>
                            <!--高度有点问题 css96行-->
                            <h3 class="date">2019-03-20</h3>
                        </div>
                        <div class="goods-price">
                            <!--<p class="goods-num">￥{{item.goods_price}}*2</p>-->
                            <p class="price-box"> <span class="price">{{item.price}}</span>RMB</p>
                        </div>
                        <span class="shop-extra-function">
                    <a href="#" class="find">取消收藏</a>
                    <a href="#" class="buy">加入购物车</a>
                </span>
                    </div>
                </li>
            </ul>
        </div>
        <!--内容部分结束-->

        <!--为你推荐开始-->
        <my-goods :goods="this.goods"></my-goods>
        <!--为你推荐结束-->

            </div>
        </div>
        <my-footer hot="personal"></my-footer>
    </div>
</template>

<script>
    import Header from "@/components/Header";
    import Footer from "@/components/Footer";
    import Goods from "@/components/Goods";
    import BScroll from 'better-scroll'
    export default {
        name: "MyCollect",
        data: () => ({
            goods:[],
            page:1,
            total:0,
            collectGoods:[],
            color:""
        }),
        components:{
            "my-header":Header,
            "my-footer":Footer,
            "my-goods":Goods
        },
        methods:{
            fetchGoodsData: function () {
                this.$http.get("/api/goods/goods", {
                    params: {
                        page: this.page,
                        pageSize: 4
                    }
                }).then(r => {
                    if (r.data.code === 200) {
                        this.goods = [...this.goods, ...r.data.data];
                        this.total = r.data.total;
                        if (!this.scroll) {
                            this.$nextTick(() => {
                                this.scroll = new BScroll(this.$refs.wrapper, {
                                    pullUpLoad: {
                                        thresholds: 0
                                    },
                                    click: true //允许触发点击效果
                                });
                                this.scroll.on("pullingUp", () => {
                                    if (this.page * 4 > this.total) {
                                        this.scroll.finishPullUp();
                                        return;
                                    }
                                    this.page++;
                                    this.fetchGoodsData();
                                    this.scroll.finishPullUp();
                                })
                            });
                        }
                    }
                }).catch()
            },
            fetchCollectData:function () {
                this.$http.get("/api/collect/collect",{
                    params:{
                        uid:localStorage.login
                    }
                }).then(r=>{
                    if (r.data.code===200){
                        this.collectGoods=r.data.data;
                    }
                }).catch(()=>{
                    console.log("获取失败");
                })
            }
        },
        mounted(){
            this.fetchGoodsData();
            this.fetchCollectData();
        }
    }
</script>

<style lang="scss" scoped>
    .content{
        height: 100%;
        overflow: hidden;
        background: #f6f6f6;
    }
    body{
        background: #f6f6f6;
        padding-top: 1.66rem;
    }
    /*公共类*/
    .container{
        width: 7.03rem;
    }

    /*内容标题*/
    #title{
        width: 100%;
        height: 0.78rem;
        background: #fff;
        border-top: solid 0.01rem #eeeeee;
        border-bottom: solid 0.01rem #eeeeee;
        text-align:center;
        font-size: 0.28rem;
        line-height: 0.78rem;
        padding: 0 0.24rem;
        position:fixed;
        top: 0.88rem;
        z-index: 999;
    }
    #title>i{
        position: absolute;
        left: 0.24rem;
        float: left;
        color: #000;
    }

    /*内容部分开始*/
    .section{
        width: 100%;
        height:auto;
        margin-bottom: 0.5rem;
    }
    .section>ul{
        height: auto;
        margin: 0 auto;
    }
    .section>ul>li{
        width: 100%;
        height: 3.06rem;
        padding-top: 0.3rem;
    }
    .section>ul>li>a{
        color: #000;
    }
    .shop-container{
        display: block;
        width: 100%;
        height: 100%;
        background: #fff;
        box-shadow: 0 0.01rem 0.21rem 0  rgba(0, 0, 0, 0.09);
        border-radius: 0.1rem;
        padding: 0.52rem 0.18rem 0.23rem 0.18rem;
    }
    .goods>img{
        width: 1.86rem;
        height: 1.31rem;
        float: left;
    }
    .goods-item{
        width: auto;
        height: auto;
        float: left;
        padding-top: 0.14rem;
        margin-left: 0.1rem;
        color: rgba(0,0,0,0.6);
    }
    .goods-item>p{
        font-family: Arial;
        font-size: 0.16rem;
        line-height: 0.18rem;
    }
    .goods-item>p>span{
        font-family: 微软雅黑;
        font-size: 0.22rem;
        color: #000;
    }
    .goods-item>h3{
        font-size: 0.16rem;
        margin-top: 0.09rem;
        font-weight: normal;
    }
    .goods-item>h3.date{
        margin-top: 0.37rem;
        font-size: 0.16rem;
    }
    .goods-price{
        width: 1.35rem;
        height: auto;
        float: right;
        padding-top: 0.07rem;
        text-align: right;
    }
    .goods-num{
        width: 100%;
        font-size: 0.24rem;
    }
    .price-box{
        width: 100%;
        font-size: 0.18rem;
        margin-top: 0.79rem;
        letter-spacing:0.03rem;
    }

    .price-box>span{
        font-size: 0.26rem;
        font-weight: bold;
    }
    .shop-extra-function{
        width: 100%;
        height: 0.44rem;
        float: left;
        margin-top: 0.11rem;
    }
    .shop-extra-function>a.find{
        display: block;
        color: #999;
        font-size: 0.24rem;
        line-height: 0.44rem;
        margin-left: 3.88rem;
        float: left;
    }
    .shop-extra-function>a.buy{
        display: block;
        float: right;
        width: 1.59rem;
        height: 0.44rem;
        border-radius: 0.04rem;
        border: solid 0.01rem #ffcb3f;
        font-size: 0.24rem;
        line-height: 0.44rem;
        color: #ffcb3f;
        text-align: center;
    }
    #space{
        width: 100%;
        height: 1.24rem;
    }
</style>