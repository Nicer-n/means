<template>
    <div>
        <div class="content">
            <my-header></my-header>
            <!--标题开始-->
            <div class="payTitle">
                <div class="back">
                    <!--icon图标-->
                    <i class="iconfont icon-xiangzuo"></i>
                </div>
                <h3>我的订单</h3>
            </div>
            <!--标题结束-->
            <!--导航选项卡开始-->
            <div class="navBox">
                <ul>
                    <li><a href="">全部</a></li>
                    <li><a href="">待付款</a></li>
                    <li class="active"><a href="">待发货</a></li>
                    <li><a href="">待收货</a></li>
                    <li><a href="">待评价</a></li>
                </ul>
            </div>
            <!--导航选项卡结束-->
            <!--订单内容开始-->
            <div class="orderItem">
                <ul class="CarList">
                    <li>
                        <div class="goods">
                            <img src="../../assets/images/browse1.png" alt="">
                        </div>
                        <div class="goodsItem">
                            <p>BOSC XISTERA<span class="goodsName">现代客厅沙发</span></p>
                            <h3 class="goodsType">绿色/单人座</h3>
                            <h3 class="date">2019-03-20</h3>
                        </div>
                        <div class="goodsNumber">
                            <h3 class="number">￥520*2</h3>
                            <div class="goodsPrice">
                                <h3>1040 <span>RMB</span></h3>
                            </div>
                        </div>
                        <div class="status">
                            <div class="cancel">取消订单</div>
                            <div class="payBtn">提醒发货</div>
                        </div>
                    </li>
                    <li>
                        <div class="goods">
                            <img src="../../assets/images/browse2.png" alt="">
                        </div>
                        <div class="goodsItem">
                            <p>BOSC XISTERA<span class="goodsName">现代客厅沙发</span></p>
                            <h3 class="goodsType">绿色/单人座</h3>
                            <h3 class="date">2019-03-20</h3>
                        </div>
                        <div class="goodsNumber">
                            <h3 class="number">￥520*1</h3>
                            <div class="goodsPrice">
                                <h3>520 <span>RMB</span></h3>
                            </div>
                        </div>
                        <div class="status">
                            <div class="cancel">取消订单</div>
                            <div class="payBtn">提醒发货</div>
                        </div>
                    </li>
                    <li>
                        <div class="goods">
                            <img src="../../assets/images/browse3.png" alt="">
                        </div>
                        <div class="goodsItem">
                            <p>BOSC XISTERA<span class="goodsName">现代客厅沙发</span></p>
                            <h3 class="goodsType">绿色/单人座</h3>
                            <h3 class="date">2019-03-20</h3>
                        </div>
                        <div class="goodsNumber">
                            <h3 class="number">￥520*1</h3>
                            <div class="goodsPrice">
                                <h3>520 <span>RMB</span></h3>
                            </div>
                        </div>
                        <div class="status">
                            <div class="cancel">取消订单</div>
                            <div class="payBtn">提醒发货</div>
                        </div>
                    </li>
                </ul>
            </div>
            <!--订单内容结束-->
            <my-goods></my-goods>
            <my-footer></my-footer>
        </div>
    </div>
</template>

<script>
    import Header from "@/components/Header";
    import Footer from "@/components/Footer";
    import Goods from "@/components/Goods";
    export default {
        name: "OrderToGoods",
        data: () => ({}),
        components:{
            "my-header":Header,
            "my-footer":Footer,
            "my-goods":Goods,
        }
    }
</script>

<style lang="scss" scoped>
    body{
        background: #fcfcfc;
        padding-top: 0.88rem;
    }
    /*标题开始*/
    .payTitle{
        width: 100%;
        height: 0.78rem;
        background: #fff;
        padding: 0 0.24rem;
        border-top: 1px solid #eeeeee;
        border-bottom: 1px solid #eeeeee;
    }
    .payTitle h3{
        font-size: 0.28rem;
        text-align: center;
        line-height: 0.78rem;
    }
    .payTitle .back{
        width: 0.24rem;
        height: 0.24rem;
        float: left;
        margin-top: 0.27rem;
    }
    .back i{
        float: left;
        text-align: center;
        line-height: 0.24rem;
        font-size: 0.24rem;
    }
    /*标题结束*/
    /*顶部选项卡开始*/
    .navBox{
        width: 100%;
        height: 0.78rem;
        padding: 0 0.44rem;
        background: #fff;
        border-bottom: 0.01rem solid #ffcb3f;
    }
    .navBox ul{
        width: 100%;
        height: 100%;
        display: flex;
        justify-content: space-between;
    }
    .navBox li{
        position: relative;
    }
    .navBox li a{
        display: block;
        color: rgba(0, 0, 0, 0.7);
        font-size: 0.24rem;
        line-height: 0.78rem;
    }
    .navBox li.active a{
        color: #ffcb3f;
        font-weight: bold;
    }
    .navBox li.active:after{
        content: "";
        display: block;
        width: 100%;
        height: 0.03rem;
        background-color: #ffcb3f;
        position: absolute;
        left: 0;
        right: 0;
        bottom: 0;
        margin: 0 auto;
    }
    /*顶部选项卡结束*/
    /*订单内容开始*/
    .orderItem{
        width: 7.02rem;
        height: auto;
        margin: 0 auto 0.5rem;
    }
    .CarList{
        width: 7.02rem;
        height:auto;
        margin: 0 auto;
    }
    .CarList li{
        width: 7.02rem;
        height: 2.76rem;
        background: #fff;
        box-shadow: 0 0.02rem 0.03rem 0
        rgba(0, 0, 0, 0.09);
        border-radius: 0.1rem;
        margin-top: 0.24rem;
        padding-top: 0.52rem;
        position: relative;
    }
    .checkBox{
        width: 0.24rem;
        height: 0.24rem;
        border-radius: 50%;
        border: 0.01rem solid #ffcb3f;
        position: absolute;
        left: 0;
        top: 50%;
        margin-top: -0.12rem;
    }
    .goods{
        width: 1.85rem;
        height: 1.3rem;
        margin-left: 0.2rem;
        float: left;
    }
    .goods img{
        width: 100%;
        height:100%;
        display:block;
    }
    .goodsItem{
        margin-left: 0.2rem;
        height: auto;
        float: left;
        margin-top: 0.1rem;
    }
    .goodsItem p{
        font-size: 0.18rem;
    }
    .goodsName{
        font-size: 0.24rem;
    }
    .goodsType{
        font-size: 0.18rem;
        margin-top: 0.08rem;
        font-weight: 400;
        color: rgba(0, 0, 0, 0.7);
    }
    .date{
        font-size: 0.18rem;
        color: rgba(0, 0, 0, 0.7);
        margin-top: 0.3rem;
        font-weight: 400;
    }
    .goodsNumber{
        float: right;
        /*margin-left: 0.7rem;*/
        margin-right: 0.24rem;
        margin-top: 0.1rem;
    }
    .number{
        font-size: 0.24rem;
        font-weight: 400;
    }
    .goodsPrice{
        margin-top: 0.65rem;
    }
    .goodsPrice h3{
        font-size: 0.26rem;
    }
    .goodsPrice h3 span{
        font-size: 0.18rem;
        font-weight: 400;
    }
    .status{
        width: 3rem;
        height: 0.45rem;
        font-size: 0.24rem;
        margin-top: 0.1rem;
        display: flex;
        justify-content: space-between;
        position: absolute;
        right: 0.3rem;
        bottom: 0.24rem;
    }
    .payBtn{
        width: 1.35rem;
        height: 0.45rem;
        border:1px solid  #ffcb3f;
        color: #ffcb3f;
        text-align: center;
        line-height: 0.45rem;
        border-radius: 0.04rem;
    }

    .cancel{
        width: 1.35rem;
        height: 0.45rem;
        text-align: center;
        line-height: 0.45rem;
        color: #999999;
    }
    /*订单内容结束*/
</style>