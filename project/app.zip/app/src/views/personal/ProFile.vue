<template>
    <div>修改资料</div>
</template>

<script>
    export default {
        name: "ProFile",
        data: () => ({})
    }
</script>

<style lang="scss" scoped>

</style>