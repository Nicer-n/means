<template>
    <div style="height: 100%;padding-top: 0.88rem">
        <my-header>
            <a href="#" class="headerExit" @click="$router.go(-1)">
                  <i class="iconfont icon-guanbi"></i>
              </a>
        </my-header>
        <div class="content" ref="wrapper">
            <div class="inner">
            <!--搜索框开始-->
            <div id="search">
                <div class="searchBox">
                    <img src="../../assets/images/search.png" alt="">
                    <input type="text" placeholder="布艺沙发" v-model="search">
                </div>
                <router-link class="text" :to="{name:'searchlist',query:{search}}">搜索</router-link>
            </div>
            <!--搜索框结束-->
            <!--历史搜索开始-->
            <div id="historySearch">
                <div class="smallTitle">
                    历史搜索
                    <div class="delete" @click="clearHistory">
                        清空记录
                        <a href="javascript:void(0)"><i class="iconfont icon-shanchu"></i></a>
                    </div>
                </div>
                <div class="searchItems">
                    <div class="searchItem" v-for="item in history" @click="jump(item)">
                        {{item}}
                    </div>
                    <!--<a href="##" class="searchItem">沙发椅</a>-->
                </div>
            </div>
            <!--历史搜索结束-->
            <!--热门搜索开始-->
            <div id="hotSearch">
                <div class="smallTitle">热门搜索</div>
                <div class="searchItems">
                    <a href="##" class="searchItem">布艺沙发</a>
                    <a href="##" class="searchItem">单人沙发</a>
                </div>
            </div>
            <!--热门搜索结束-->
            <my-goods :goods="this.goods"></my-goods>
            </div>
      </div>

    </div>
</template>

<script>
    import Header from "@/components/Header";
    import Goods from "@/components/Goods";
    import BScroll from 'better-scroll'
    export default {
        name: "Search",
        data: () => ({
            search:"",
            history:[],
            goods:[],
            page:1,
            total:1,
        }),
        components:{
            "my-header":Header,
            "my-goods":Goods
        },
       beforeRouteLeave(to,from,next){
            //indexOf
           if (to.name!=="searchlist"){
               next();
               return;
           }
           if (this.search===""){
                next("/Search");
               return;
           }
           let index=this.history.indexOf(this.search);
           if (index!==-1){
               this.history.splice(index,1);
           }
           this.history.unshift(this.search);
           if (this.history.length>10){
               this.history=this.history.slice(0,10);
               this.history.push("...");
           }
           localStorage.setItem("history",JSON.stringify(this.history));
            next();
       },
        methods:{
            clearHistory:function () {
                this.history=[];
                localStorage.removeItem("history");
            },
            jump:function (item) {
                this.search=item;
                this.$router.push({path:'/SearchList',query:{search:item}})
            },
            fetchGoodsData: function () {
                this.$http.get("/api/goods/goods", {
                    params: {
                        page: this.page,
                        pageSize: 8
                    }
                }).then(r => {
                    // console.log(r);
                    if (r.data.code === 200) {
                        this.goods = [...this.goods,...r.data.data];
                        console.log(this.goods);
                        this.total=r.data.total;
                        if (!this.scroll){
                            this.$nextTick(()=>{
                                this.scroll=new BScroll(this.$refs.wrapper,{
                                    pullUpLoad:{
                                        thresholds:-50
                                    },
                                    click:true ,//允许触发点击效果
                                    // preventDefault:false
                                });
                                this.total=r.data.total;
                                this.scroll.on("pullingUp",()=>{
                                    if (this.page*8>this.total){
                                        this.scroll.finishPullUp();
                                        // this.showmore=false;
                                        return;
                                    }
                                    this.page++;
                                    this.fetchGoodsData();
                                    this.scroll.finishPullUp();
                                });
                            })
                        }
                        else {
                            this.scroll.refresh();
                        }
                    }
                    else{
                        console.log("获取失败")
                    }
                }).catch(() => {
                    console.log("商品获取失败")
                })
            }
        },
        mounted:function () {
            this.fetchGoodsData();
            if (localStorage.history){
                this.history=JSON.parse(localStorage.history) //将字符串转换为数组
            }

        }
    }
</script>

<style lang="scss" scoped>
    .content{
        width: 100%;
        height: 100%;
        padding-top: 0.88rem;
        overflow: hidden;
        position: relative;
    }
    /*.inner{*/
        /*padding-top: 0.88rem;*/
        /*height: auto;*/
    /*}*/
    body{
        background: #f8f8f8;
        padding-top: 0.88rem;
        /*height: 100%;*/
    }
    /*搜索框开始*/
    #search{
        width: 100%;
        height: 0.8rem;
        padding: 0.1rem 0.24rem;
        background: #fff;
        border: solid 0.01rem #eeeeee;
        margin-bottom: 0.6rem;
    }
    .searchBox{
        width: 6.12rem;
        height: 0.6rem;
        border-radius: 0.3rem;
        border: solid 0.01rem rgba(217,217,217,0.7);
        opacity: 0.7;
        float: left;
        padding: 0.14rem 0;
    }
    .searchBox img{
        display: block;
        width: 0.24rem;
        height: 0.26rem;
        margin: 0 0.2rem;
        float: left;
    }
    .searchBox input{
        width: 4.82rem;
        outline: none;
        border: none;
        float: left;
    }
    #search .text{
        height: 0.6rem;
        line-height: 0.6rem;
        font-size: 0.24rem;
        letter-spacing: 0.012rem;
        color: #000000;
        float: right;
    }
    /*搜索框结束*/
    /*热门搜索开始*/
    #hotSearch{
        width: 100%;
        /*height: 1.24rem;*/
        height: auto;
        padding: 0 0.24rem;
        margin-bottom: 0.42rem;
        overflow: hidden;
    }
    .smallTitle{
        padding-left: 0.13rem;
        font-size: 0.3rem;
        letter-spacing: 0.015rem;
        color: #000000;
        position: relative;
        margin-bottom: 0.24rem;
    }
    .smallTitle::before{
        content: "";
        display: block;
        width: 0.03rem;
        height: 0.2rem;
        background: #ffcb3f;
        position: absolute;
        left: 0;
        top: 0.1rem;
    }
    .searchItems{
        width: 100%;
        /*height: 0.6rem;*/
        height: auto;
        padding-left: 0.24rem;
        overflow: hidden;
    }
    .searchItem{
        display: block;
        width: 1.5rem;
        /*height:0.6rem;*/
        height: auto;
        margin-right: 0.4rem;
        background-color: #efefef;
        border-radius: 0.3rem;
        font-size: 0.24rem;
        letter-spacing: 0.012rem;
        text-align: center;
        line-height: 0.6rem;
        color: #666666;
        float: left;
        margin-bottom: 0.2rem;

    }
    /*热门搜索结束*/
    /*历史搜索结束*/
    #historySearch{
        width: 100%;
        /*height: 1.24rem;*/
        height: auto;
        padding: 0 0.24rem;
        margin-bottom: 0.42rem;
        overflow: hidden;
    }
    .delete{
        float: right;
        font-size: 0.24rem;
        letter-spacing: 0.012rem;
        color: #000000;
        opacity: 0.7;
    }
    .delete .iconfont{
        font-size: 0.24rem;
        margin-left: 0.14rem;
    }
    /*历史搜索结束*/
</style>