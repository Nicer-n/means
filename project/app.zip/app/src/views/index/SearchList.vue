<template>
    <div style="height: 100%; padding-top: 2rem">
        <my-header>
            <a href="#" class="headerExit" @click="$router.go(-1)">
                <i class="iconfont icon-guanbi"></i>
            </a>
        </my-header>
        <!--搜索部分开始-->
        <div id="search">
            <div class="searchBox">
                <div class="searchBoxInput">
                    <div class="searchBoxInputIcon">
                        <img src="../../assets/images/searchActive.png" alt="">
                    </div><!--icon-->
                    <input type="text" id="searchInput" placeholder="搜索店内精品" :value="search" ref="input">
                </div>
                <div class="price"  @click="handlerSearch">搜索</div>
            </div>
        </div>
        <!--搜索部分结束-->
        <div class="wrapper" ref="wrapper" >
            <div class="inner">
                <my-goods :goods="this.goods" :showTitle="false"></my-goods>
            </div>
        </div>
    </div>
</template>

<script>
    import Header from "@/components/Header";
    import Goods from "@/components/Goods";
    import BScroll from 'better-scroll'
    export default {
        name: "SearchList",
        data: () => ({
            search:"",
            goods:[],
            page:1,
            total:0,
            history:[]
        }),
        components:{
            "my-header":Header,
            "my-goods":Goods,
        },
        methods:{
            fetchGoodsData:function () {
                this.$http.get("/api/goods/goods",{
                    params:{
                        name:this.search,
                        page:this.page,
                        pageSize:8
                    }
                }).then(r=>{
                    if (r.data.code === 200) {
                        console.log(r);
                        this.goods = [...this.goods, ...r.data.data];
                        this.total=r.data.total;
                        if (!this.scroll) {
                            this.$nextTick(()=>{
                                this.scroll=new  BScroll(this.$refs.wrapper,{
                                    pullUpLoad:{
                                        thresholds:-50
                                    },
                                    click:true //允许触发点击效果
                                });
                                this.scroll.on("pullingUp",()=>{
                                    this.page++;
                                    this.fetchGoodsData();
                                    this.scroll.finishPullUp();
                                })
                            });
                        }
                    }
                }).catch(()=>{
                    console.log("获取失败")
                })
            },
            handlerSearch:function () {
                this.search=this.$refs.input.value;
                if (this.search===""){
                    this.$router.back();
                    return;
                }
                let index=this.history.indexOf(this.search);
                if (index!==-1){
                    this.history.splice(index,1);
                }
                this.history.unshift(this.search);
                if (this.history.length>10){
                    this.history=this.history.slice(0,10);
                    this.history.push("...");
                }
                localStorage.setItem("history",JSON.stringify(this.history));
                this.goods=[];
                this.page=1;
                this.fetchGoodsData();
                // this.search="";

            }
         },
        mounted:function () {
            this.search = this.$route.query.search;
            this.fetchGoodsData();
            this.history=JSON.parse(localStorage.history)
        }
    }
</script>

<style lang="scss" scoped>
    .wrapper{
        height: 100%;
        overflow: hidden;
        padding-top: 0.88rem;
    }
    body{
        background-color:#f6f6f6;
    }
    /*搜索部分开始*/
    #search{
        width:100%;
        border:0.01rem solid #f2f2f2;
        background: #fff;
        position:fixed;
        top:0.88rem;
        left:0;
        z-index: 999;
        box-shadow:0 0.1rem 0.16rem rgba(0,0,0,0.04);
    }
    .searchBox{
        width:6.82rem;
        margin:0 auto;
        height:0.88rem;
        display: flex;
        justify-content: space-between;
        align-items: center;
    }
    .searchBoxInput{
        width:6.04rem;
        height:0.6rem;
        border-radius:0.3rem;
        border:0.01rem solid #d9d9d9;
        padding:0 0.2rem;
        display: flex;
        align-items: center;
    }
    .searchBoxInputIcon{
        width:0.24rem;
        height:0.25rem;
    }
    .searchBoxInputIcon>img{
        display: block;
        width:100%;
        height:100%;
    }
    #searchInput{
        border:none;
        color:rgba(0,0,0,0.7);
        padding:0 0.12rem;
    }
    #searchInput:focus{
        outline: none;
    }
    .price{
        display: block;
        font-size:0.24rem;
        color:#000;
        letter-spacing: 0.01rem;
        font-weight:400;
    }
    /*搜索部分结束*/
    .listPos{
        position:absolute;
        top:1.76rem;
        left:0;
        padding-top: 0.24rem;
    }
    .img-1{
        /*background-image:url("../../assets/images/listShowsafa1.png");*/
        background-position:center;
        background-size:5.01rem;
    }
    .img-2{
        background-image:url("../../assets/images/listShowsafa2.png");
        background-position: -1.24rem -1.2rem;
        background-size:5.01rem;
    }
    .img-3{
        background-image:url("../../assets/images/listShowsafa6.png");
        background-position:center;
        background-size:5.01rem;
    }
    .img-4{
        background-image:url("../../assets/images/listShowsafa5.png");
        background-position: -1.24rem -1.2rem;
        background-size:5.01rem;
    }
    .img-5{
        background-image:url("../../assets/images/listShowsafa7.png");
        background-position:center;
        background-size:5.01rem;
    }
    #recommendShop{
        width:100%;
    }
    /*推荐商品*/
    .recommendContainer{
        width:7.02rem;
        margin:0 auto;
        position:relative;
    }
    .recommendLine{
        width:0.03rem;
        height:0.21rem;
        position:absolute;
        background-color:#ffcb3f;
        left:0;
        top:0.1rem;
    }
    .recommendBox{
        width:6.82rem;
        margin:0 auto;
    }
    .recommendBox>h3{
        font-size:0.3rem;
        color:#000;
        letter-spacing:0.02rem;
        font-weight:400;
        margin-bottom:0.36rem;
    }
    .recommendList{
        width:100%;
        display: flex;
        flex-wrap:wrap;
        justify-content: space-between;
    }
    .recommendItem{
        width:3.24rem;
        height:5.08rem;
        margin-bottom:0.24rem;
        background: #fff;
    }
    .recommendItemTop{
        width:100%;
        height:3.05rem;
        margin-bottom:0.24rem;
    }
    .img1{
        background-image:url("../../assets/images/recommend5.png");
        background-position:center;
        background-repeat: no-repeat;
        background-size: 100%;
    }
    .img2{
        background-image:url("../../assets/images/recommend6.png");
        background-position:center;
        background-repeat: no-repeat;
        background-size: 100%;
    }
    .img3{
        background-image:url("../../assets/images/recommend7.png");
        background-position:center;
        background-repeat: no-repeat;
        background-size: 100%;
    }
    .img4{
        background-image:url("../../assets/images/recommend8.png");
        background-position:center;
        background-repeat: no-repeat;
        background-size: 100%;
    }
    .img5{
        background-image:url("../../assets/images/recommend1.png");
        background-position:center;
        background-repeat: no-repeat;
        background-size: 100%;
    }
    .img6{
        background-image:url("../../assets/images/recommend2.png");
        background-position:center;
        background-repeat: no-repeat;
        background-size: 100%;
    }
    .img7{
        background-image:url("../../assets/images/recommend3.png");
        background-position:center;
        background-repeat: no-repeat;
        background-size: 100%;
    }
    .img8{
        background-image:url("../../assets/images/recommend4.png");
        background-position:center;
        background-repeat: no-repeat;
        background-size: 100%;
    }
    .recommendItemBottom{
        width:2.82rem;
        height:1.58rem;
        margin:0 auto;
    }
    .recommendItemLine{
        width:0.36rem;
        height:0.01rem;
        background-color:#000;
        margin-bottom:0.1rem;
    }
    .recommendItemBottom>h4{
        font-size:0.18rem;
        font-weight:400;
    }
    .recommendItemBottom>h3{
        font-size:0.24rem;
        margin-bottom:0.46rem;
    }
    .recommendItemBottomFooter{
        width:100%;
        display: flex;
        justify-content: space-between;
        align-items: center;
    }
    .recommendItemBottomFooter>h3{
        font-size:0.23rem;
    }
    .recommendItemBottomFooter>h3>span{
        font-size:0.18rem;
        font-weight:400;
    }
    .recommendItemBottomFooterBuy{
        display: block;
        width:1.53rem;
        height:0.44rem;
        text-align:center;
        line-height:0.44rem;
        font-size:0.22rem;
        color:#fff;
        background-color: #ffcb3f;
        border-radius:0.04rem;
    }
    .recommendItemBottomFooterBuy .iconfont{
        font-size: 0.22rem;
        color: #fff;
    }

</style>