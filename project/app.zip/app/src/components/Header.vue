<template>
    <div>
        <!--头部开始-->
        <header id="header">
            <div class="container headerBox">
                <!--<a href="#" class="headerExit" @click="$router.go(-1)">
                    <i class="iconfont icon-guanbi"></i>
                </a>-->
                <slot>
                    <div class="headerExit"></div>
                </slot>
                <div class="headerLogo">
                    <img src="../assets/images/logo.png" alt="">
                </div>
                <a href="#" class="headerMore" @click="$router.push({name:'index'})">
                    <i class="iconfont icon-gengduo"></i>
                </a>
            </div>
        </header>
        <!--头部结束-->
    </div>
</template>

<script>
    export default {
        name: "Header",
        data: () => ({

        })
    }
</script>

<style lang="scss" scoped>
    #header{
        width:100%;
        background-color:#fff;
        position:fixed;
        left:0;
        top:0;
        z-index: 999;

    }
    .container{
        width:7.02rem;
        margin:0 auto ;
    }
    .headerBox{
        height:0.88rem;
        display: flex;
        justify-content: space-between;
        align-items: center;
    }
    .headerExit{
        display: block;
        width:0.28rem;
        height:0.3rem;
    }
    .headerExit>i{
        display: block;
        font-size:0.28rem;
        color: #000;
    }
    .headerLogo{
        width:0.92rem;
        height:0.3rem;
    }
    .headerLogo>img{
        display: block;
        width:100%;
        height:100%;
    }
    .headerMore{
        display: block;
        width:0.36rem;
        height:0.3rem;
    }
    .headerMore>i{
        display: block;
        font-size:0.36rem;
        color: #000;
    }
</style>