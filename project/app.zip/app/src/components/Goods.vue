<template>
    <div>
        <!--推荐商品开始-->
        <section id="recommendShop">
            <div class="recommendContainer">
                <div class="recommendLine" v-if="showTitle"></div>
                <div class="recommendBox">
                    <h3 v-if="showTitle">推荐商品</h3>
                        <ul class="recommendList">
                            <goods-item
                                v-for="item in goods"
                                :item="item"
                                :key="item.id"

                        >
                        </goods-item>
                        </ul>
                </div>
            </div>
        </section>
        <!--推荐商品结束-->
    </div>
</template>

<script>
    import GoodsItem from "@/components/GoodsItem";

    export default {
        name: "Goods",
        data: () => ({
            // page: "",
            // total: "",
            // goods: [],
        }),
        props:{
            goods:{
                type:Array,
                required:true
            },
            showTitle:{
                default:true
            }
        },
        components: {
            "goods-item": GoodsItem
        },
        methods: {

        },
        mounted: function () {
            // this.fetchGoodsData();
        }
    }
</script>

<style lang="scss" scoped>

    #recommendShop {
        width: 100%;
    }

    .recommendContainer {
        width: 7.02rem;
        margin: 0 auto;
        position: relative;
    }

    .recommendLine {
        width: 0.03rem;
        height: 0.21rem;
        position: absolute;
        background-color: #ffcb3f;
        left: 0;
        top: 0.1rem;
    }

    .recommendBox {
        width: 6.82rem;
        margin: 0 auto;
    }

    .recommendBox > h3 {
        font-size: 0.3rem;
        color: #000;
        letter-spacing: 0.02rem;
        font-weight: 400;
        margin-bottom: 0.36rem;
    }

    .recommendList {
        width: 100%;
        height: auto;
        display: flex;
        flex-wrap: wrap;
        justify-content: space-between;
    }

    .recommendItem {
        width: 3.24rem;
        height: 5.08rem;
        margin-bottom: 0.24rem;
        background: #fff;
    }

    .recommendItemTop {
        width: 100%;
        height: 3.05rem;
        margin-bottom: 0.24rem;
    }

    .img1 {
        background-image: url("../assets/images/recommend5.png");
        background-position: center;
        background-repeat: no-repeat;
        background-size: 100%;
    }

    .img2 {
        background-image: url("../assets/images/recommend6.png");
        background-position: center;
        background-repeat: no-repeat;
        background-size: 100%;
    }

    .img3 {
        background-image: url("../assets/images/recommend7.png");
        background-position: center;
        background-repeat: no-repeat;
        background-size: 100%;
    }

    .img4 {
        background-image: url("../assets/images/recommend8.png");
        background-position: center;
        background-repeat: no-repeat;
        background-size: 100%;
    }

    .img5 {
        background-image: url("../assets/images/recommend1.png");
        background-position: center;
        background-repeat: no-repeat;
        background-size: 100%;
    }

    .img6 {
        background-image: url("../assets/images/recommend2.png");
        background-position: center;
        background-repeat: no-repeat;
        background-size: 100%;
    }

    .img7 {
        background-image: url("../assets/images/recommend3.png");
        background-position: center;
        background-repeat: no-repeat;
        background-size: 100%;
    }

    .img8 {
        background-image: url("../assets/images/recommend4.png");
        background-position: center;
        background-repeat: no-repeat;
        background-size: 100%;
    }

    .recommendItemBottom {
        width: 2.82rem;
        height: 1.58rem;
        margin: 0 auto;
    }

    .recommendItemLine {
        width: 0.36rem;
        height: 0.01rem;
        background-color: #000;
        margin-bottom: 0.1rem;
    }

    .recommendItemBottom > h4 {
        font-size: 0.18rem;
        font-weight: 400;
    }

    .recommendItemBottom > h3 {
        font-size: 0.24rem;
        margin-bottom: 0.46rem;
    }

    .recommendItemBottomFooter {
        width: 100%;
        display: flex;
        justify-content: space-between;
        align-items: center;
    }

    .recommendItemBottomFooter > h3 {
        font-size: 0.23rem;
    }

    .recommendItemBottomFooter > h3 > span {
        font-size: 0.18rem;
        font-weight: 400;
    }

    .recommendItemBottomFooterBuy {
        display: block;
        width: 1.53rem;
        height: 0.44rem;
        text-align: center;
        line-height: 0.44rem;
        font-size: 0.22rem;
        color: #fff;
        background-color: #ffcb3f;
        border-radius: 0.04rem;
    }

    .recommendItemBottomFooterBuy .iconfont {
        font-size: 0.22rem;
        color: #fff;
    }
</style>