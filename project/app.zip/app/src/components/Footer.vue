<template>
    <!--底部开始-->
    <footer id="footer">
        <div class="footerContainer">
            <ul class="footerList">
                <li>
                    <router-link to="/Index">
                        <img src="../assets/images/icon-index-active.png" alt="" v-if="hot==='index'">
                        <img  src="../assets/images/icon-index.png" alt="" v-else>
                        <p :class="['footerDesc',{active:hot==='index'}]">首页</p>
                    </router-link>
                </li>
                <li>
                    <router-link to="/Category">
                        <img src="../assets/images/icon-classify-active.png" alt="" v-if="hot==='category'">
                        <img src="../assets/images/icon-classify.png" alt="" v-else>
                        <p :class="['footerDesc',{active:hot==='category'}]">分类</p>
                    </router-link>
                </li>
                <li>
                    <router-link to="/ShopCar">
                        <img src="../assets/images/icon-cart-active.png" alt="" v-if="hot==='shopcar'">
                        <img src="../assets/images/icon-cart.png" alt="" v-else>
                        <p :class="['footerDesc',{active:hot==='shopcar'}]">购物车</p>
                    </router-link>
                </li>
                <li>
                    <router-link to="/Personal">
                        <img src="../assets/images/icon-user-active.png" alt="" v-if="hot==='personal'">
                        <img src="../assets/images/icon-user.png" alt="" v-else>
                        <p :class="['footerDesc',{active:hot==='personal'}]">我的</p>
                    </router-link>
                </li>
            </ul>
        </div>
    </footer>
    <!--底部结束-->
</template>

<script>
    export default {
        name: "Footer",
        data: () => ({

        }),
        props:{
            hot:{
                type:String,
                required:true
            }
        }
    }
</script>

<style lang="scss" scoped>
    #footer{
        width:100%;
        border-top:0.01rem solid #bfbfbf;
        position:fixed;
        bottom:0;
        left:0;
        background-color:#fafafa;
        z-index: 999;
    }
    .footerContainer{
        width:6.1rem;
        height:0.98rem;
        margin:0 auto;
        display: flex;
        align-items: center;

    }
    .footerList{
        width:100%;
        display: flex;
        justify-content: space-between;
        padding: 0.15rem 0;
    }
    .footerList>li{
        width: auto;
        height: 100%;
    }
    .footerList>li>a{
        display: flex;
        flex-direction: column;
        justify-content: space-between;
        align-items:center;
        width:100%;
        height:0.71rem;
    }
    .footerList>li>a>img{
        height: 0.4rem;
        width: auto;
    }
    .footerList>li>a>p.active{
        color: #ffcb3f;
        font-weight: bold;
    }
    .footerDesc{
        font-size:0.2rem;
        height: 0.16rem;
        line-height: 0.16rem;
        letter-spacing: 0.01rem;
        color:#000;
    }
</style>