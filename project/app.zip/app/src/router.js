import Vue from 'vue'
import Router from 'vue-router'
import Index from "@/views/index/Index";
import Search from "@/views/index/Search";
import SearchList from "@/views/index/SearchList";

import Category from "@/views/goods/Category";
import Address from "@/views/goods/Address";
import Content from "@/views/goods/Content";
import Order from "@/views/goods/Order";
import Pay from "@/views/goods/Pay";
import PayResult from "@/views/goods/PayResult";
import ShopCar from "@/views/goods/ShopCar";
import ShopComment from "@/views/goods/shopComment";


import Login from "@/views/personal/Login";
import Personal from "@/views/personal/Personal";
import MyAddress from "@/views/personal/Address";
import OrderList from "@/views/personal/OrderList";
import Paths from "@/views/personal/Paths";
import AddressAdd from "@/views/personal/AddressAdd";
import OrderToPay from "@/views/personal/OrderToPay";
import OrderToGoods from "@/views/personal/OrderToGoods";
import OrderToReceiveGoods from "@/views/personal/OrderToReceiveGoods";
import OrderToComment from "@/views/personal/OrderToComment";
import Setting from "@/views/personal/Setting";
import Sign from "@/views/personal/Sign";
import MyCollect from "@/views/personal/MyCollect";

Vue.use(Router);

export default new Router({
    routes: [
        {
            path:"/",
            redirect:"/Index"
        },
        /*index模块*/
        {
            path: "/Index",
            name: "index",
            component: Index
        },
        {
            path: "/Search",
            name: "search",
            component: Search
        },
        {
            path: "/SearchList",
            name: "searchlist",
            component: SearchList
        },
        /*personal模块*/
        {
            path: "/Login",
            name: "login",
            component: Login
        },
        {
            path: "/Sign",
            name: "sign",
            component: Sign
        },
        {
            path: "/Personal",
            name: "personal",
            component: Personal
        },
        {
            path: "/MyAddress",
            name: "myaddress",
            component: MyAddress
        },
        {
            path: "/OrderList",
            name: "orderlist",
            component: OrderList
        },
        {
            path: "/Paths",
            name: "paths",
            component: Paths
        },
        {
            path: "/AddressAdd",
            name: "addressadd",
            component: AddressAdd
        },
        {
            path: "/OrderToPay",
            name: "ordertopay",
            component: OrderToPay
        },
        {
            path: "/OrderToGoods",
            name: "ordertogoods",
            component: OrderToGoods
        },
        {
            path: "/OrderToReceiveGoods",
            name: "toreceivegoods",
            component: OrderToReceiveGoods
        },
        {
            path: "/OrderToComment",
            name: "ordertocomment",
            component: OrderToComment
        },
        {
            path: "/Setting",
            name: "setting",
            component: Setting
        },
        {
            path: "/MyCollect",
            name: "mycollect",
            component: MyCollect
        },
        /*goods模块*/
        {
            path: "/Category",
            name: "category",
            component: Category
        },
        {
            path: "/Address",
            name: "address",
            component: Address
        },
        {
            path: "/Content",
            name: "content",
            component: Content
        },
        {
            path: "/Order",
            name: "order",
            component: Order
        },
        {
            path: "/Pay",
            name: "pay",
            component: Pay
        },
        {
            path: "/PayResult",
            name: "payresult",
            component: PayResult
        },
        {
            path: "/ShopCar",
            name: "shopcar",
            component: ShopCar
        },
        {
            path: "/ShopComment",
            name: "shopcomment",
            component: ShopComment
        },

    ]
})
