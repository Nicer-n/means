<?php
/**
 * Created by PhpStorm.
 * User: 小可爱！
 * Date: 2019/5/9
 * Time: 10:43
 */

namespace app\index\controller;


use app\model\ExeOrderModel;
use app\model\GoodsModel;
use app\model\OrderModel;
use app\model\TypeModel;
use app\model\UsersModel;
use think\Controller;
use think\Session;

class Index extends Controller
{
    function index(){
        $data=GoodsModel::order("id",'desc')->limit(0,8)->select();
        return view("index",["newGoods"=>$data,"hot"=>"index"]);
    }
    function category($tid=''){
        $data=TypeModel::all();
        $search=input('get.search');
        $where=[];
        if ($tid!==""){
            $where["tid"]=$tid;
        }
        if (isset($search)){
            $where['name_ch']=['like',"%$search%"];
        }
        $goodsData=GoodsModel::where($where)->paginate(8,false,['fragment'=>'goods']);
        $total=GoodsModel::where($where)->count();
        return view("category",
            [
                "hot"=>"category","Category"=>$data,"goods"=>$goodsData,"total"=>$total
            ]);
    }
    function show($id){
        $goods=GoodsModel::getById($id);
        $pics=$goods->pics;
        $colors=$goods->colors;
        $picsArr=explode(";",$pics);
        $colorsArr=explode(",",$colors);
        return view("show",['hot'=>'category',"goods"=>$goods,"pics"=>$picsArr,"colors"=>$colorsArr]);
    }
    function shopCar(){
        $r=Session::get("login");
        if (!isset($r)){
            return redirect('/index/index/login',301);
        }
        $data=input("get.");
        $data["uid"]=$r;
//        dump($data);
//        return;
        $model=new ExeOrderModel();
        $model->allowField(true)->save($data);
        $order=OrderModel::order("id","desc")->paginate(5);
        return view("shopcar",['hot'=>"category","order"=>$order]);
    }
    function login(){
        return view("login");
    }
    function checkLogin(){
        $data=input("post.");
        $r=UsersModel::getByPhone($data["username"]);
        if ($r){
            if ($r->password===md5($data['password'])){
                Session::set("login",$r->id);
                 $this->success("登陆成功","/index");
            }else{
                $this->error("密码错误","login");
            }
        }else{
            $this->error("用户不存在","login");
        }
    }
}