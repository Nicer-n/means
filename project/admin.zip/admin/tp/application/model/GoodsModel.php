<?php
/**
 * Created by PhpStorm.
 * User: 小可爱！
 * Date: 2019/4/19
 * Time: 10:50
 */

namespace app\model;


use think\Model;

class GoodsModel extends Model
{
    public $table="goods_view";
}