<?php
/**
 * Created by PhpStorm.
 * User: 小可爱！
 * Date: 2019/4/21
 * Time: 18:03
 */

namespace app\model;


use think\Model;

class ExeAddressModel extends Model
{
    public  $table="address";
}