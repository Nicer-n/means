<?php
/**
 * Created by PhpStorm.
 * User: 小可爱！
 * Date: 2019/4/20
 * Time: 15:58
 */

namespace app\model;


use think\Model;

class CommentModel extends Model
{
    public  $table="comment_view";
}