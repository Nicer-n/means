<?php
/**
 * Created by PhpStorm.
 * User: 小可爱！
 * Date: 2019/4/16
 * Time: 16:15
 */

namespace app\model;


use think\Model;

class UsersModel extends Model
{
    public $table="users";
}