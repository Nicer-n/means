<?php
/**
 * Created by PhpStorm.
 * User: 小可爱！
 * Date: 2019/5/6
 * Time: 16:27
 */

namespace app\model;


use think\Model;

class ExeOrderModel extends Model
{
    public $table="orders";
}