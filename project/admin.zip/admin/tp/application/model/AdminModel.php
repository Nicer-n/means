<?php
/**
 * Created by PhpStorm.
 * User: 小可爱！
 * Date: 2019/4/23
 * Time: 9:56
 */

namespace app\model;


use think\Model;

class AdminModel extends Model
{
    public $table="admin";
}