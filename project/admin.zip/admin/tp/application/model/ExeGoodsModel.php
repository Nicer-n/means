<?php
/**
 * Created by PhpStorm.
 * User: 小可爱！
 * Date: 2019/4/19
 * Time: 16:25
 */

namespace app\model;


use think\Model;

class ExeGoodsModel extends Model
{
    public  $table="goods";
}