<?php
/**
 * Created by PhpStorm.
 * User: 小可爱！
 * Date: 2019/4/20
 * Time: 14:06
 */

namespace app\model;


use think\Model;

class AddressModel extends Model
{
    public $table="address_view";
}