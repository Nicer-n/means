<?php
/**
 * Created by PhpStorm.
 * User: 小可爱！
 * Date: 2019/4/21
 * Time: 18:09
 */

namespace app\model;


use think\Model;

class ExeCommentModel extends Model
{
    public $table="comments";
}