<?php
/**
 * Created by PhpStorm.
 * User: 小可爱！
 * Date: 2019/4/18
 * Time: 15:57
 */

namespace app\api\controller;


use app\model\TypeModel as Model;
use think\controller\Rest;

class Type extends Rest
{
    function type()
    {
        if ($this->method !== "get") {
            $r = check();
            if ($r !== true) {
                return $r;
            }
        }
        switch ($this->method) {
            case "get":
                return $this->get();
            case "post":
                return $this->post();
            case "delete":
                return $this->delete();
            case "put":
                return $this->put();
        }
    }

    private function get()
    {
        $page = input("get.page");
        $pageSize = input("get.pageSize");
        $search = input("get.search");

        $id = input("get.id");

        if (isset($page) && isset($pageSize)) {

            if ($search === "") {
                $where = [];
            } else {
                $where = ['category' => ["like", "%$search%"]];
            }
            $start = ($page - 1) * $pageSize;
            $data = Model::where($where)->order("sort", "ASC")->limit($start, $pageSize)->select();
            $total = Model::where($where)->count();
            if ($data) {
                return json(["msg" => "获取成功", "code" => 200, "data" => $data, "total" => $total]);
            } else {
                return json(["msg" => "获取失败", "code" => 404]);
            }
        } else if ($id) {
            $r = Model::get($id);
            if ($r) {
                return json(["data" => $r, "msg" => "获取成功", "code" => 200]);
            } else {
                return json(["msg" => "获取失败", "code" => 404]);
            }
        } else {
            $data = Model::all();
            if ($data) {
                return json(["msg" => "获取成功", "code" => 200, "data" => $data]);
            } else {
                return json(["msg" => "获取成功", "code" => 404]);
            }
        }
    }

    private function post()
    {
        $data = input("post.");
        $model = new Model();
        $r = $model->allowField(true)->save($data);
        if ($r) {
            return json(["msg" => "添加成功", "code" => 200]);
        } else {
            return json(["msg" => "添加失败", "code" => 404]);
        }
    }

    private function delete()
    {
        $id = input("get.id");
        $r = Model::destroy($id);
        if ($r) {
            return json(["msg" => "删除成功", "code" => 200]);
        } else {
            return json(["msg" => "删除失败", "code" => 404]);
        }

    }

    private function put()
    {
        $data = input("put.");
        $model = new Model();
        $r = $model->allowField(true)->isUpdate(true)->save($data);
        if ($r) {
            return json(["msg" => "修改成功", "code" => 200]);
        } else {
            return json(["msg" => "修改失败", "code" => 404]);
        }
    }
}