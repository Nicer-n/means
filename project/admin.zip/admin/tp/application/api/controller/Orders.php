<?php
/**
 * Created by PhpStorm.
 * User: 小可爱！
 * Date: 2019/5/6
 * Time: 15:26
 */

namespace app\api\controller;


use app\model\ExeOrderModel as ExeModel;
use app\model\OrderModel as Model;
use think\controller\Rest;
use think\Exception;

class Orders extends Rest
{
    function orders(){
        $uid=input("get.uid");
        $r=Model::where("uid",$uid)->select();
//        $r=Model::where("uid",$uid)->where("state",0)->select();
        if ($r||count($r)===0){
            return json(["msg"=>"获取成功","code"=>200,"data"=>$r]);
        }else{
            return json(["msg"=>"获取失败","code"=>404]);
        }

    }
    function addOrder(){
        //多个操作需要同时完成  事务
        $data=input("post.");
        $model=new ExeModel();
        $db=$model->db(false);
        $db->startTrans();
        try{
            $model->where("uid",$data["uid"])->where("state",0)->delete();
            $model->allowField(true)->saveAll($data["data"]);
            //如果操作成功 直接提交
            $db->commit();
            return json(["msg"=>"添加成功","code"=>200]);

        }catch (Exception $e){
            //如果有任何异常 则回滚 数据表回滚到当前这一系列操作之前的状态
            $db->rollback();
            return json(["msg"=>"添加失败","code"=>404]);
        }
    }
    function Pay(){
        $data=input("post.");
        $orders=$data["data"];
        $uid=$orders[0]['uid'];
        $gidArr=array_map(function ($v){
            return $v["gid"];
        },$orders);
        $model=new ExeModel();
        $db=$model->db(false);
        $db->startTrans();
        try{
            $model
                ->where("uid",$uid)
                ->where("gid","in",$gidArr)
                ->where("state",0)
                ->delete();
            $r=$model->allowField(true)->saveAll($orders);
            $db->commit();
            if ($r){
                return json(["msg"=>"提交订单成功","code"=>200]);
            }else{
                return json(["msg"=>"提交订单失败","code"=>404]);
            }

        }catch (Exception $e){
            $db->rollback();
        }

    }
}