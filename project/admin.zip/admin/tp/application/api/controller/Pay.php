<?php
/**
 * Created by PhpStorm.
 * User: 小可爱！
 * Date: 2019/5/7
 * Time: 17:27
 */

namespace app\api\controller;


class Pay
{
    function  pay(){
        //接入支付接口 返回支付结果
        return json(["msg"=>"支付成功","code"=>200]);
    }
}