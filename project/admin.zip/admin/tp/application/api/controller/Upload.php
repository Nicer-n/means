<?php
/**
 * Created by PhpStorm.
 * User: 小可爱！
 * Date: 2019/4/17
 * Time: 15:24
 */

namespace app\api\controller;


use think\Request;

class Upload
{
    function upload(Request $request){
        // 获取表单上传文件 例如上传了001.jpg
        $file = $request->file('file');
        if (empty($file)){
            return "";
        }
        // 移动到框架应用根目录/public/uploads/ 目录下
        if($file){
            $info = $file->move(ROOT_PATH . 'public' . DS . 'uploads');
            if($info){
                $path=str_replace("\\","/", '/uploads/'.$info->getSaveName());
                return $path;
            }else{
                return "";
            }
        }
    }
}