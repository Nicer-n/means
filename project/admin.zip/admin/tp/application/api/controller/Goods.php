<?php
/**
 * Created by PhpStorm.
 * User: 小可爱！
 * Date: 2019/4/19
 * Time: 10:51
 */

namespace app\api\controller;

use app\model\ExeGoodsModel as ExeModel;
use app\model\GoodsModel as Model;
use think\controller\Rest;
use think\JWT;

class Goods extends Rest
{
    function goods(){
        if ($this->method!=="get"){
            $r=check();
            if ($r!==true){
                return $r;
            }
        }

        switch ($this->method) {
            case "get":
                return $this->get();
            case "post":
                return $this->post();
            case "put":
                return $this->put();
            case "delete":
                return $this->delete();
        }
    }
    private function get(){
        $page = input("get.page") ? input("get.page") : 1;
        $pageSize = input("get.pageSize") ? input("get.pageSize") : 5;

        $name=input('get.name');
        $type=input('get.type');
        $low=input('get.low');
        $high=input('get.high');
        $state=input("get.state");
        $id = input("get.id");
        if (!isset($id)) {
            $where=[];
            if (isset($name)){
                $where["name_ch"]=["like","%$name%"];
            }
            if (isset($type)){
                $where["tid"]=$type;
            }
            if (isset($low)&&isset($high)){
                $where["price"]=["between",[$low,$high]];
            }
            if (isset($state)){
                $where["state"]=$state;
            }
            $start = ($page - 1) * $pageSize;
            $data = Model::where($where)->order("id","desc")->limit($start, $pageSize)->select();
            $total = Model::where($where)->count();
            if ($data||$total===0) {
                return json(["msg" => "获取成功", "code" => 200, "data" => $data, "total" => $total]);
            }
        }else{
            $model=new  Model();
            $r=$model->getById($id);
            if ($r){
                return json(["data"=>$r,"msg"=>"获取成功","code"=>200]);
            }
            else{
                return json(["msg"=>"获取失败","code"=>404]);
            }
        }
    }
    private function delete(){
        $id = input("get.id");
        $r = ExeModel::destroy($id);
        if ($r) {
            return json(['msg' => "删除成功", 'code' => 200]);
        } else {
            return json(['msg' => "删除失败", 'code' => 404]);
        }
    }
    private function put(){
        $data=input("put.");
        $model=new ExeModel();
        if (isset($data["name_ch"]) && isset($data["name_en"])) {
            $r1 = $model->where(["name_ch" => $data["name_ch"], "id" => ["<>", $data["id"]]])->find();
            $r2 = $model->where(["name_en" => $data["name_en"], "id" => ["<>", $data["id"]]]) -> find();
            if ($r1 || $r2) {
                return json(["msg" => "商品名字重复，请修改", "code" => 404]);
            }
        }
        $r=$model->allowField(true)->isUpdate(true)->save($data);
        if ($r){
            return json(["msg"=>"修改成功","code"=>200]);
        }else{
            return json(["msg"=>"修改失败","code"=>404]);
        }
    }
    private function  post(){
        $data=input("post.");
        $data["time"]=time();
        $r=Model::whereOr("name_ch",$data["name_ch"])->whereOr("name_en",$data["name_en"])->find();
        if ($r){
            return json(["msg"=>"商品名称重复","code"=>404]);
        }
        $model=new ExeModel();
        $r1=$model->allowField(true)->save($data);
        if ($r1){
            return json(["msg"=>"添加成功","code"=>200]);
        }else{
            return json(["msg"=>"添加失败","code"=>404]);
        }
    }
}