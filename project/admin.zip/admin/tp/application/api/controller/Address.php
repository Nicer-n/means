<?php
/**
 * Created by PhpStorm.
 * User: 小可爱！
 * Date: 2019/4/20
 * Time: 14:06
 */

namespace app\api\controller;


use app\model\AddressModel as Model;

use app\model\ExeAddressModel as ExeModel;
use app\model\ExeAddressModel;
use think\controller\Rest;

class Address extends Rest
{
    function address()
    {
        $r=check();
        if ($r!==true){
            return $r;
        }
        switch ($this->method) {
            case "get":
                return $this->get();
            case "post":
                return $this->post();
            case "put":
                return $this->put();
            case "delete":
                return $this->delete();
        }
    }
    private function get()
    {
        $uid=input("get.uid");
        $is_default=input("get.is_default");
        if (isset($uid)){
            if (isset($is_default)){
                $res=ExeModel::where("uid",$uid)->where("is_default",$is_default)->find();
            }else{
                $res=ExeModel::where("uid",$uid)->select();
            }

            if ($res||empty($res)){
                return json(["data" => $res, "code" => 200, "msg" => "获取成功"]);
            }else{
                return json(["code" => 404, "msg" => "获取失败"]);
            }
        }






        $page = input("get.page") ? input("get.page") : 1;
        $pageSize = input("get.pageSize") ? input("get.pageSize") : 5;
        $search = input("get.search");

        $id = input("get.id");
        if (!isset($id)) {
            if ($search !== "") {
                $where = ["name" => ["like", "%$search%"]];
            } else {
                $where = [];
            }
            $start = ($page - 1) * $pageSize;
            $data = Model::where($where)->limit($start, $pageSize)->select();
            $total = Model::where($where)->count();
            return json(["data" => $data, "code" => 200, "msg" => "获取成功", "total" => $total]);
        } else {
            $r = Model::get($id);
            if ($r) {
                return json(["data" => $r, "code" => 200, "msg" => "获取成功"]);
            } else {
                return json(["code" => 404, "msg" => "获取失败"]);
            }
        }
    }
    private function delete(){
        $id = input("get.id");
        $r=ExeModel::destroy($id);
        if ($r) {
            return json(['msg' => "删除成功", 'code' => 200]);
        } else {
            return json(['msg' => "删除失败", 'code' => 404]);
        }
    }
    private function  put(){
        $data=input("put.");
        $model=new ExeModel();
        $r=$model->allowField(true)->isUpdate(true)->save($data);
        if ($r){
            return json(["msg"=>"修改成功","code"=>200]);
        }else{
            return json(["msg"=>"修改失败","code"=>404]);
        }
    }
}