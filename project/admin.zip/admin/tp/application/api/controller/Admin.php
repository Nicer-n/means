<?php
/**
 * Created by PhpStorm.
 * User: 小可爱！
 * Date: 2019/4/22
 * Time: 17:55
 */

namespace app\api\controller;


use app\model\AdminModel as Model;
use think\captcha\Captcha;
use think\controller\Rest;
use think\JWT;
use think\response\Json;

class Admin extends Rest
{
    function captcha()
    {
//        return json(["img"=>captcha_img()]);
        $captcha = new Captcha();
        $captcha->length = 4;
        $captcha->imageW = 200;
        $captcha->imageH = 50;
        return $captcha->entry();
    }
    function checkLogin()
    {
        $data = input("post.");
        $code = input("post.code");
        $name = input("post.name");
        $captcha = new Captcha();
        if ($captcha->check($code)) {
            $r = Model::getByName($name);
            if ($r) {
                if ($r->state!==1){
                    return json(['msg' => "暂无登录权限", "code" => 404]);
                }
                if ($r["password"] === md5($data["password"])) {
                    $payLoad=[
                        "name"=>$name,
                        "role"=>$r->role
                    ];
                    $key=config("key");
                    $token=JWT::getToken($payLoad,$key);
                    return json(['msg' => "登陆成功", "code" => 200,"name"=>$name,"role"=>$r["role"],"token"=>$token]);
                } else {
                    return json(['msg' => "密码错误", "code" => 404]);
                }
            } else {
                return json(['msg' => "用户名不存在", "code" => 404]);
            }
        } else {
            return json(["msg" => "验证码错误", "code" => 404]);
        }
    }
    function admin(){
        $r=check();
        if ($r!==true){
            return $r;
        }
        switch ($this->method) {
            case "get":
                return $this->get();
            case "post":
                return $this->post();
            case "put":
                return $this->put();
            case "delete":
                return $this->delete();
        }
    }
    function changePass(){
        $data=input('put.');
        if (empty($data)){
            return json(["msg"=>"请提交验证数据","code"=>404]);
        }

        if (!isset($data["password"])){
            return json(["msg"=>"请提交原始密码","code"=>404]);
        }
        if (!isset($data["newPass"])){
            return json(["msg"=>"请提交新密码","code"=>404]);
        }
        $r=Model::where(["name"=>$data["name"],"password"=>md5($data["password"])])->find();
        if (isset($r)){
//            $res=Model::update(["password"=>md5($data["newPass"]),"id"=>$r->id]);
            $r->password=md5($data["newPass"]);
            $res=$r->isUpdate(true)->save();
            if ($res){
                return json(["msg"=>"修改成功","code"=>200]);
            }else{
                return json(["msg"=>"修改失败","code"=>404]);
            }
        }else{
            return json(["msg"=>"原是密码错误","code"=>404]);
        }
//        $data = input("post.");
//        $name=input("post.name");
//        $originData = Model::where(["name"=>$name])->find();
//        if (md5($data["password"]) !== $originData["password"]) {
//            return json(['msg' => "原始密码错误", 'code' => 404]);
//        }
//            $originData["password"] = md5($data["newPass"]);
//            $r = $originData->allowField(true)->save();
//            if ($r) {
//                return json(['msg' => "修改成功", 'code' => 200]);
//            } else {
//                return json(['msg' => "修改失败", 'code' => 404]);
//            }


    }
    private function get(){
        $page = input("get.page") ? input("get.page") : 1;
        $pageSize = input("get.pageSize") ? input("get.pageSize") : 5;
        $search = input("get.search");
        $id = input("get.id");
        $name=input("get.name");
        $start = ($page - 1) * $pageSize;
        if (!isset($id)) {
            if ($search !== "") {
                $data = Model::where("name",["<>",$name],["like","%$search%"],"and")->limit($start, $pageSize)->select();
                $total = Model::where("name",["<>",$name],["like","%$search%"],"and")->count();
            } else {
                $data = Model::where("name","<>",$name)->limit($start, $pageSize)->select();
                $total = Model::where("name","<>",$name)->count();

            }
//            $data = Model::where($where)->limit($start, $pageSize)->select();
//            $total = Model::where($where)->count();
            if ($data||$total===0){
                return json(["data" => $data, "code" => 200, "msg" => "获取成功", "total" => $total]);
            }else{
                return json([ "code" => 404, "msg" => "获取失败"]);
            }

        } else {
            $r=Model::getById($id);
            if ($r){
                return json(["data"=>$r,"code"=>200,"msg"=>"获取成功"]);
            }else{
                return json(["code"=>404,"msg"=>"获取失败"]);
            }
        }
    }

    private function post(){
        $data = input("post.");
        $model = new Model();
        $r1 = $model->where("name", "=", $data["name"])->find();
        if ($r1) {
            return json(['msg' => "该用户名已存在", 'code' => 404]);
        }

        $data['password'] = md5($data["password"]);

        $r = $model->allowField(true)->save($data);
        if ($r) {
            return json(['msg' => "添加成功", 'code' => 200]);
        } else {
            return json(['msg' => "添加失败", 'code' => 404]);
        }
    }

    private function put(){
        $data=input("put.");
        $model=new Model();
        $r=$model->allowField(true)->isUpdate(true)->save($data);
        if ($r){
            return json(["msg"=>"修改成功","code"=>200]);
        }else{
            return json(["msg"=>"修改失败","code"=>404]);
        }
    }

    private function delete(){
        $id = input("get.id");
        $r = Model::destroy($id);
        if ($r) {
            return json(['msg' => "删除成功", 'code' => 200]);
        } else {
            return json(['msg' => "删除失败", 'code' => 404]);
        }

    }
}