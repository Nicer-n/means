<?php
/**
 * Created by PhpStorm.
 * User: 小可爱！
 * Date: 2019/4/20
 * Time: 15:59
 */

namespace app\api\controller;


use app\model\CommentModel as Model;
use app\model\ExeCommentModel as ExeModel;
use think\controller\Rest;

class Comment extends Rest
{
    function comment()
    {
        $r=check();
        if ($r!==true){
            return $r;
        }
        switch ($this->method) {
            case "get":
                return $this->get();
            case "delete":
                return $this->delete();
            case "put":
                return $this->put();
        }
    }
    private function get()
    {
        $page = input("get.page") ? input("get.page") : 1;
        $pageSize = input("get.pageSize") ? input("get.pageSize") : 5;
        $id = input("get.id");

        $name=input('get.name');
        $type=input('get.type');
        if (!isset($id)) {
            $where = [];
            if (isset($name)){
                $where["name_ch"]=["like","%$name%"];
            }
            if (isset($type)){
                $where["tid"]=$type;
            }
            $start = ($page - 1) * $pageSize;
            $data = Model::where($where)->limit($start, $pageSize)->select();
            $total = Model::where($where)->count();
            if ($data||$total===0) {
                return json(['data' => $data, "msg" => "获取成功", "code" => 200, "total" => $total]);
            }
        }else{
            $r1=Model::getById($id);
            if ($r1){
                return json(["msg" => "获取成功", "code" => 200,"data"=>$r1]);
            }else{
                return json(["msg" => "获取失败", "code" => 404]);
            }
        }

    }
    private function delete(){
        $id=input("get.id");
        $r=ExeModel::destroy($id);
        if ($r) {
            return json(['msg' => "删除成功", 'code' => 200]);
        } else {
            return json(['msg' => "删除失败", 'code' => 404]);
        }

    }
    private function put(){
        $data=input("put.");
        $model=new ExeModel();
        $r=$model->allowField(true)->isUpdate(true)->save($data);
        if ($r){
            return json(["msg"=>"回复失败","code"=>200]);
        }else{
            return json(["msg"=>"回复失败","code"=>404]);
        }
    }
}