<?php
/**
 * Created by PhpStorm.
 * User: 小可爱！
 * Date: 2019/5/8
 * Time: 16:12
 */

namespace app\api\controller;


use app\model\CollectModel as Model;
use app\model\ExeGoodsModel;
use app\model\GoodsModel;
use think\controller\Rest;

class Collect   extends  Rest
{
    function collect(){
//        $r=check();
//        if ($r!==true){
//            return $r;
//        }
        switch ($this->method) {
            case "get":
                return $this->get();
            case "post":
                return $this->post();
            case "put":
                return $this->put();
            case "delete":
                return $this->delete();
        }
    }
    private function get(){
        $uid=input("get.uid");
        $gid=input("get.gid");
        if (isset($uid)&&isset($gid)){
           $r=Model::where(["uid"=>$uid,"gid"=>$gid])->find();
           if ($r){
               return json(["msg"=>"已搜藏","code"=>200]);
           }else{
               return json(["msg"=>"未搜藏","code"=>404]);
           }
        }else{
            $r1=Model::where("uid",$uid)->column("gid");
            $data=ExeGoodsModel::where("id","in",$r1)->select();
            if ($data){
                return json(['msg'=>"获取成功","code"=>200,'data'=>$data]);
            }else{
                return json(['msg'=>"获取失败","code"=>400]);
            }
        }
    }
    private function delete(){
        $uid=input("get.uid");
        $gid=input("get.gid");
        if (isset($uid)&&isset($gid)){
            $r=Model::where(["uid"=>$uid,"gid"=>$gid])->delete();
            if ($r){
                return json(["msg"=>"删除成功","code"=>200]);
            }else{
                return json(["msg"=>"删除失败","code"=>404]);
            }
        }
    }
    private function post(){
        $data=input("post.");
        $model=new Model();
        $r=$model->allowField(true)->save($data);
        if ($r){
            return json(["msg"=>"收藏成功","code"=>200]);
        }else{
            return json(["msg"=>"收藏失败","code"=>404]);
        }
    }
}