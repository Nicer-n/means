/*轮播图开始*/
{
    let inner = $(".bannerBox");
    let now = 1;
    function move() {
        // inner.css("transition","all 1s");
        now++;
        if (now < 4) {
            $(".bannerPage").filter(".active").removeClass("active").end().eq(now - 1).addClass("active");
            inner.css("marginLeft", (now * -100) + "%");
        } else if (now === 4) {
            // inner.css("transition","none");
            // now=1;
            inner.css("marginLeft", (now * -100) + "%");
            $(".bannerPage").filter(".active").removeClass("active").end().eq(0).addClass("active");
        }
        inner.css("transition", "all 1s");
    }

    let t = setInterval(move, 3000);
    $("#banner").hover(function () {
        clearInterval(t);
    }, function () {
        t = setInterval(move, 3000);
    });
    $(".bannerPage").each(function (index) {
        $(this).click(function () {
            now = index + 1;
            $(this).siblings().removeClass("active").end().addClass("active");
            inner.css("marginLeft", ((now) * -100) + "%");
        });
    });
    inner.on("transitionend", function () {
        if (now === 4) {
            inner.css("transition", "none");
            now = 1;
            inner.css("marginLeft", "-100%");
        }
    });
}
/*轮播图结束*/
/*返回顶部*/
$(".toTop").toTop();
/*返回顶部结束*/
/*懒加载开始*/
$(function() {
    $("img.lazy").lazyload({effect: "fadeIn"});
});
/*懒加载结束*/
/*新品首发开始*/
{
    let l = 1228;
    window.onresize = function () {
        if (window.innerWidth < 1200) {
            l = 921;
        } else {
            l = 1228;
        }
    };
    console.log(window.innerWidth);
    newCons = $(".newProductCons");
    $(".right").click(function () {
        newCons.css("transition", "all 2s");
        newCons.css("margin-left", -l+"px");
    });
    $(".left").click(function () {
        newCons.css("transition", "all 2s");
        newCons.css("margin-left", 0);
    });
}
/*新品首发结束*/