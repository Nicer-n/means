<?php if (!defined('THINK_PATH')) exit(); /*a:3:{s:67:"D:\uek\admin\tp\public/../application/index\view\index\shopcar.html";i:1557479190;s:57:"D:\uek\admin\tp\application\index\view\common\header.html";i:1557477279;s:57:"D:\uek\admin\tp\application\index\view\common\footer.html";i:1557373369;}*/ ?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>购物车</title>

    <link rel="stylesheet" href="/static/css/header.css">
    <link rel="stylesheet" href="/static/css/footer.css">
    <!--<link rel="stylesheet" href="/static/css/index.css">-->
    <link rel="stylesheet" href="/static/css/carShopping.css">

</head>
<body>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
</head>
<body>
<!-- 导航开始 -->
<div id="header">
    <div class="container headerBox">
        <div class="headerSearch">
            <div class="inputSearch">
                <input type="text" placeholder="请输入您想要的商品">
                <div class="icon"></div><!-- icon引入-->
            </div>
            <div class="inputLogin">
                <div class="icon"></div><!-- icon引入-->
                <div class="loginRegister">
                    <?php if(\think\Session::get('login')): ?>
                    <a href=""><p class="active">个人中心</p></a>
                    <?php else: ?>
                    <a href="<?php echo url('/index/index/login'); ?>"><p class="active">登录</p></a>
                    <a href=""><p style="margin-right:0;">注册</p></a>
                    <?php endif; ?>
                </div>

            </div>
        </div>
        <a href="#" class="headerLogo">
            <img src="/static/img/vicor.png" alt="">
        </a>
        <ul class="nav">
            <li>
                <a href="<?php echo url('/'); ?>" class="<?php if($hot==='index'): ?>active <?php endif; ?>">首页
                    <div class="<?php if($hot==='index'): ?>line <?php endif; ?>"></div>
                </a>
            </li>
            <li>
                <a href="<?php echo url('/index/index/category'); ?>" class="<?php if($hot==='category'): ?>active <?php endif; ?>">
                 产品分类
                     <div class=" <?php if($hot==='category'): ?>line <?php endif; ?>"></div>
                </a>
            </li>
            <li><a href="#">案例展示</a></li>
            <li><a href="#">品牌故事</a></li>
            <li class="listLast"><a href="#">设计团队</a></li>
        </ul>
    </div>
</div>
<!--  导航结束-->
</body>
</html>
<!--导航链开始-->
<div class="navList">
    <ul>
        <li><a href=""><span class="indexNav">首页</span></a></li>
        <li><a href=""><span>&gt;</span></a></li>
        <li><a href=""><span class="carNav">购物车</span></a></li>
    </ul>
</div>
<!--导航链结束-->
<!--购买流程导航开始-->
<div class="processBox">
    <div class="processNav">
        <div class="carLogo">
            <img src="/static/img/carShopping-logo.png" alt="">
        </div>
        <div class="proNavItem">
            <ul>
                <li class="active">
                    <a href="">购物车</a>
                    <div class="status">
                        <p>进行中</p>
                    </div>
                </li>
                <li><a href="">填写订单</a>
                </li>
                <li><a href="">选择支付方式</a></li>
                <li><a href="">交易成功</a></li>
            </ul>
        </div>
    </div>
</div>
<!--购买流程导航结束-->
<!--主体内容开始-->
<div class="content">
    <div class="contentNav">
        <ul>
            <li><h3>全选</h3></li>
            <li><h3>商品描述</h3></li>
            <li><h3>单价</h3></li>
            <li><h3>数量</h3></li>
            <li><h3>总价</h3></li>
            <li class="last-child"><h3>操作</h3></li>
        </ul>
    </div>
    <div class="contentBody">

        <ul class="contentItem">
            <?php if(is_array($order) || $order instanceof \think\Collection || $order instanceof \think\Paginator): $i = 0; $__LIST__ = $order;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$v): $mod = ($i % 2 );++$i;?>
              <li class="active">
                <div class="chooseBox">
                    <div class="check"></div>
                </div>
                <div class="GoodsBox">
                    <img src="<?php echo $v['thumb']; ?>" alt="">
                </div>
                <div class="GoodDesc">
                    <div class="bosc-xistera">
                        <p><span><?php echo $v['name_en']; ?></span><br><?php echo $v['name_ch']; ?></p>
                    </div>
                    <div class="goods-model">
                        <h3><?php echo $v['colors']; ?>/<?php echo $v['kinds']; ?></h3>
                    </div>
                </div>
                <div class="GoodPrice">
                    <h3><?php echo $v['goods_price']; ?><span>RMB</span></h3>
                </div>
                <div class="GoodsNumber">
                    <div class="reduce btn">
                        <span>-</span>
                    </div>
                    <div class="count">
                        <span><?php echo $v['number']; ?></span>
                    </div>
                    <div class="add btn">
                        <span>+</span>
                    </div>

                </div>
                <div class="GoodTotalPrice">
                    <h3>1040<span>RMB</span></h3>
                </div>
                <div class="GoodsAction">
                    <div class="delete">
                        <i>&#xe60e;</i>
                    </div>
                    <div class="collection">
                        <i>&#xe600;</i>
                    </div>
                </div>
            </li>
            <?php endforeach; endif; else: echo "" ;endif; ?>
        </ul>
        <div class="contentAction">
            <div class="chooseAllBox">
                <div class="chooseAll">
                    <div class="checkAll"></div>
                </div>
                <h3>全选</h3>
            </div>
            <div class="someDeleteBox">
                <i>&#xe60e;</i>
                <h3>批量删除</h3>
            </div>
            <div class="void">
                <i>&#xe60e;</i>
                <h3>清空失效</h3>
            </div>
        </div>
        <div class="SettlementBox">
            <div class="countDesc">
                <p>共计<span>2</span>件商品</p>
            </div>
            <div class="SettlementBtn">
                去结算
            </div>
            <div class="totalPrice">
                <p>合计&nbsp;</p>
                <h3 class="price">1040<span>RMB</span></h3>
            </div>

        </div>
    </div>
    <div class="pagesBox">
        <div class="pages">
            <div class="prev">
                <i>&#xe90d;</i>
            </div>
            <a href=""><span>1</span></a>
            <a href=""><span>2</span></a>
            <a href=""><span>3</span></a>
            <a href=""><span>4</span></a>
            <a href=""><span>5</span></a>
            <a href="" class="more"><span>......</span></a>
            <a href=""><span>18</span></a>
            <a href=""><span>19</span></a>
            <div class="next">
                <i>&#xe601;</i>
            </div>
            <span class="tiaozhuan">跳转到</span>
            <div class="inputPage">
                <input type="text">
            </div>
            <span class="ye">页</span>
            <div class="go">
                go
            </div>
        </div>

    </div>
</div>
<!--主体内容结束-->
<!--为你推荐开始-->
<div class="newProduct">
    <div class="newProductBox container">
        <div class="topTitle">
            <div class="titleBox">
                <div class="topLine"></div>
                <div class="longLine"></div>
                <div class="text">NEW PRODUCT</div>
                <div class="title">
                    <span class="black">为你</span>&nbsp;
                    <span class="bold">推荐</span>
                </div>
                <div class="bottomLine"></div>
            </div>
        </div>
        <ul class="newProductCons">
            <li class="newProductCon">
                <img src="/static/img/newProduct1.png" alt="">
                <div class="newProductText">
                    <div class="blackLine"></div>
                    <p class="en">VERFO LAB</p>
                    <p class="ch">现代简约时尚布艺沙发</p>
                    <div>
                        <span class="num">800</span>
                        <span class="RMB">RMB</span>
                    </div>
                    <a href="#" class="clickBuy">
                        <i class="iconfont">&#xe660;</i>
                        点击购买
                    </a>
                </div>
            </li>
            <li class="newProductCon">
                <img src="/static/img/newProduct2.png" alt="">
                <div class="newProductText">
                    <div class="blackLine"></div>
                    <p class="en">VERFO LAB</p>
                    <p class="ch">现代简约时尚布艺沙发</p>
                    <div>
                        <span class="num">800</span>
                        <span class="RMB">RMB</span>
                    </div>
                    <a href="#" class="clickBuy">
                        <i class="iconfont">&#xe660;</i>
                        点击购买
                    </a>
                </div>
            </li>
            <li class="newProductCon">
                <img src="/static/img/newProduct3.png" alt="">
                <div class="newProductText">
                    <div class="blackLine"></div>
                    <p class="en">VERFO LAB</p>
                    <p class="ch">现代简约时尚布艺沙发</p>
                    <div>
                        <span class="num">800</span>
                        <span class="RMB">RMB</span>
                    </div>
                    <a href="#" class="clickBuy">
                        <i class="iconfont">&#xe660;</i>
                        点击购买
                    </a>
                </div>
            </li>
            <li class="newProductCon lastChild">
                <img src="/static/img/newProduct4.png" alt="">
                <div class="newProductText">
                    <div class="blackLine"></div>
                    <p class="en">VERFO LAB</p>
                    <p class="ch">现代简约时尚布艺沙发</p>
                    <div>
                        <span class="num">800</span>
                        <span class="RMB">RMB</span>
                    </div>
                    <a href="#" class="clickBuy">
                        <i class="iconfont">&#xe660;</i>
                        点击购买
                    </a>
                </div>
            </li>
        </ul>
        <div class="buttonBox">
            <a href="##" class="button left">
                <i class="iconfont"></i>
            </a>
            <a href="##" class="button right">
                <i class="iconfont"></i>
            </a>
        </div>
    </div>
</div>
<!--为你推荐结束-->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
</head>
<body>
<!-- 底部开始 -->
<div id="footer">
    <div class="footerAfter"></div>
    <div class="footBox container">
        <div class="footBoxAfter"></div>
        <div class="erweima">
            <img src="/static/img/erweima.png" alt="">
            <p>扫码关注我们</p>
        </div>
        <div class="all">
            <p class="title">全部商品</p>
            <ul class="list">
                <li class="listItem">
                    <a href="##">沙发</a>
                </li>
                <li class="listItem">
                    <a href="##">床</a>
                </li>
                <li class="listItem">
                    <a href="##">椅子</a>
                </li>
            </ul>
        </div>
        <div class="new">
            <p class="title">新品发布</p>
            <ul class="list">
                <li class="listItem">
                    <a href="##">物流配送</a>
                </li>
                <li class="listItem">
                    <a href="##">免运费政策</a>
                </li>
                <li class="listItem">
                    <a href="##">物流配送服务</a>
                </li>
                <li class="listItem">
                    <a href="##">签收验货</a>
                </li>
                <li class="listItem">
                    <a href="##">物流查询</a>
                </li>
            </ul>
        </div>
        <div class="afterSale">
            <p class="title">售后服务</p>
            <ul class="list">
                <li class="listItem">
                    <a href="##">退换货政策</a>
                </li>
                <li class="listItem">
                    <a href="##">贵就赔</a>
                </li>
                <li class="listItem">
                    <a href="##">维修/安装</a>
                </li>
                <li class="listItem">
                    <a href="##">订单修改</a>
                </li>
                <li class="listItem">
                    <a href="##">退换货申请</a>
                </li>
                <li class="listItem">
                    <a href="##">我的发票</a>
                </li>
            </ul>
        </div>
        <div class="about">
            <p class="title">关于我们</p>
            <ul class="list">
                <li class="listItemAbout">客服热线：400-320-0031</li>
                <li class="listItemAbout">客服邮箱：867321000@qq.com</li>
                <li class="listItemAbout">地址：山西省太原市小店区VICRO总部</li>
            </ul>
        </div>
    </div>
    <p class="copy">Copyright &copy;2018 www.guazi.com All Rights Reserved  |  京ICP备15053955号 ICP证151071号</p>
</div>
<!-- 底部结束 -->
</body>
</html>
</body>
</html>