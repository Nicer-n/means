<?php if (!defined('THINK_PATH')) exit(); /*a:3:{s:68:"D:\uek\admin\tp\public/../application/index\view\index\category.html";i:1557451982;s:57:"D:\uek\admin\tp\application\index\view\common\header.html";i:1557477279;s:57:"D:\uek\admin\tp\application\index\view\common\footer.html";i:1557373369;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width">
    <title>列表展示</title>
    <link rel="stylesheet" href="/static/css/header.css">
    <link rel="stylesheet" href="/static/css/listShow.css">
    <link rel="stylesheet" href="/static/css/footer.css">
    <link rel="stylesheet" href="/static/css/swiper.min.css">
</head>
<body>
<!-- 导航开始 -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
</head>
<body>
<!-- 导航开始 -->
<div id="header">
    <div class="container headerBox">
        <div class="headerSearch">
            <div class="inputSearch">
                <input type="text" placeholder="请输入您想要的商品">
                <div class="icon"></div><!-- icon引入-->
            </div>
            <div class="inputLogin">
                <div class="icon"></div><!-- icon引入-->
                <div class="loginRegister">
                    <?php if(\think\Session::get('login')): ?>
                    <a href=""><p class="active">个人中心</p></a>
                    <?php else: ?>
                    <a href="<?php echo url('/index/index/login'); ?>"><p class="active">登录</p></a>
                    <a href=""><p style="margin-right:0;">注册</p></a>
                    <?php endif; ?>
                </div>

            </div>
        </div>
        <a href="#" class="headerLogo">
            <img src="/static/img/vicor.png" alt="">
        </a>
        <ul class="nav">
            <li>
                <a href="<?php echo url('/'); ?>" class="<?php if($hot==='index'): ?>active <?php endif; ?>">首页
                    <div class="<?php if($hot==='index'): ?>line <?php endif; ?>"></div>
                </a>
            </li>
            <li>
                <a href="<?php echo url('/index/index/category'); ?>" class="<?php if($hot==='category'): ?>active <?php endif; ?>">
                 产品分类
                     <div class=" <?php if($hot==='category'): ?>line <?php endif; ?>"></div>
                </a>
            </li>
            <li><a href="#">案例展示</a></li>
            <li><a href="#">品牌故事</a></li>
            <li class="listLast"><a href="#">设计团队</a></li>
        </ul>
    </div>
</div>
<!--  导航结束-->
</body>
</html>
<!--  导航结束-->
<!-- 轮播图开始 -->
<div id="banner">
    <div class="bannerImgBox">
        <ul class="imgBox">
            <li><img src="/static/img/banner2.png" alt=""></li>
            <li><img src="/static/img/lisShowtbg.jpg" alt=""></li>
            <li><img src="/static/img/banner1.png" alt=""></li>
            <li><img src="/static/img/banner2.png" alt=""></li>
            <li><img src="/static/img/lisShowtbg.jpg" alt=""></li>
        </ul>
    </div>
    <div class="container bannerBox">
        <h1><span>T</span>HE CH<span>A</span>IR<br/>DE<span>S</span>IGN</h1>
        <p>告别繁琐多余的浮夸</p>
        <a href="#" class="more">MORE</a>
        <img src="/static/img/listShowsafablue.png" alt="">
        <p class="index">首页><span class="product">产品分类</span></p>
        <ul class="dotBox">
            <li class="active" style="margin-left:0;"></li>
            <li></li>
            <li></li>
        </ul>
    </div>
</div>
<!-- 轮播图结束 -->
<!-- 产品分类开始 -->
<div class="section">
    <div class="container">
        <div class="newProductTitle">
            <div class="titleTopLineY"></div>
            <div class="titleTopLineC"></div>
            <p>NEW PRODUCT</p>
            <h3>产品 <span>分类</span></h3>
        </div>
        <div class="lineB"></div>
        <div class="lotsImg">
            <div class="swiper-container">
                <div class="swiper-wrapper">
                    <?php if(is_array($Category) || $Category instanceof \think\Collection || $Category instanceof \think\Paginator): $i = 0; $__LIST__ = $Category;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$v): $mod = ($i % 2 );++$i;?>
                        <div class="swiper-slide">
                            <a href="<?php echo url('/index/index/category',['tid'=>$v['id']]); ?>#goods">
                                <div class="twoList">
                                <div class="imgs">
                                    <div class="img bottomImg">
                                        <div class="cover"></div>
                                        <img src="<?php echo $v['thumb']; ?>" alt="">
                                    </div>
                                    <div class="img topImg">
                                        <img src="<?php echo $v['thumb']; ?>" alt="">
                                    </div>
                                </div>
                                <h5><?php echo $v['category']; ?></h5>
                                <span>REAL VIEW</span>
                            </div>
                            </a>
                        </div>
                    <?php endforeach; endif; else: echo "" ;endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- 产品分类结束 -->
<!-- 商品详情开始 -->
<a name="goods"></a>
<div class="section">
    <div class="container sectionBox">
        <div class="newProductTitle">
            <div class="titleTopLineY"></div>
            <div class="titleTopLineC"></div>
            <p>COMMODITY DETAILS</p>
            <h3>商品 <span>详情</span></h3>
        </div>
        <div class="lineB"></div>
        <div class="setInputSearch">
            <form action="<?php echo url('/index/index/category'); ?>#goods" method="get" name="myform" autocomplete="off">
                <input type="text" placeholder="桌椅/休闲风" name="search" required>
                <div class="icon" onclick="document.myform.submit()"></div>
            </form>
        </div>
        <!--<ul class="sectionBoxList">-->
            <!--<li class="sectionBoxItem">-->
                <!--<p>类型</p>-->
                <!--<div class="sectionBoxItemBox">-->
                    <!--<a href="#" class="margin-left-68">沙发</a>-->
                    <!--<a href="#">床</a>-->
                    <!--<a href="#" class="active">桌椅</a>-->
                    <!--<a href="#">茶几</a>-->
                    <!--<a href="#">床头柜</a>-->
                <!--</div>-->
            <!--</li>-->
            <!--<li class="sectionBoxItem">-->
                <!--<p>空间</p>-->
                <!--<div class="sectionBoxItemBox">-->
                    <!--<a href="#" class="margin-left-68">卧室</a>-->
                    <!--<a href="#">客厅</a>-->
                    <!--<a href="#">餐厅</a>-->
                    <!--<a href="#">儿童房</a>-->
                    <!--<a href="#">其他</a>-->
                <!--</div>-->
            <!--</li>-->
            <!--<li class="sectionBoxItem">-->
                <!--<p>颜色</p>-->
                <!--<div class="sectionBoxItemBox">-->
                    <!--<a href="#" style="border-color:#dcdcdc;" class="circle margin-left-66"></a>-->
                    <!--<a href="#" style="border-color:#9bc8d3;" class="circle"></a>-->
                    <!--<a href="#" style="border-color:#dc8cd3;" class="circle"></a>-->
                    <!--<a href="#" style="border-color:#ffcb3f;" class="circle"></a>-->
                    <!--<a href="#" style="border-color:#ff7a32;" class="circle"></a>-->
                    <!--<a href="#" style="border-color:#bee898;" class="circle"></a>-->
                    <!--<a href="#" style="border-color:#ae7861;" class="circle"></a>-->
                <!--</div>-->
            <!--</li>-->
            <!--<li class="sectionBoxItem">-->
                <!--<p>风格</p>-->
                <!--<div class="sectionBoxItemBox" style="border:none;">-->
                    <!--<a href="#" class="margin-left-68 active">休闲风</a>-->
                    <!--<a href="#">欧式风</a>-->
                    <!--<a href="#">现代风</a>-->
                    <!--<a href="#">美式风</a>-->
                    <!--<a href="#">复古风</a>-->
                <!--</div>-->
            <!--</li>-->
        <!--</ul>-->
        <p class="searchTitle">共搜到<span><?php echo $total; ?></span>条符合条件的商品</p>
        <ul class="contentListBox">
            <?php if(is_array($goods) || $goods instanceof \think\Collection || $goods instanceof \think\Paginator): $i = 0; $__LIST__ = $goods;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$v): $mod = ($i % 2 );++$i;?>
                <li class="contentItem">
                <div class="contentHeader" style="background: url('<?php echo $v['thumb']; ?>');background-size: cover;background-position: center"></div>
                <div class="contentFooter">
                    <div class="line"></div>
                    <p><?php echo $v['name_en']; ?></p>
                    <h2><?php echo $v['name_ch']; ?></h2>
                    <h3><?php echo $v['price']; ?><span>RMB</span></h3>
                    <a href="<?php echo url('/index/index/show',['id'=>$v['id']]); ?>" class="nowBuy active">立即购买</a>
                </div>
            </li>
            <?php endforeach; endif; else: echo "" ;endif; ?>
        </ul>
        <div class="pagerContentBox">
            <!--<div class="bigBox prev">《</div>-->
            <ul class="pagerBox">
                <?php echo $goods->render(); ?>
                <!--<li>1</li>-->
                <!--<li>2</li>-->
                <!--<li class="active">3</li>-->
                <!--<li>4</li>-->
                <!--<li>5</li>-->
                <!--<span style="float:left;">.....</span>-->
                <!--<li class="margin-left-8">18</li>-->
                <!--<li class="margin-right-0">19</li>-->
            </ul>
            <!--<div class="bigBox next">》</div>-->
            <div class="goBox">
                <span>跳转到&nbsp;</span>
                <input type="text" class="bigBox">
                <span>&nbsp;页</span>
                <div class="bigBox go">GO</div>
            </div>

        </div>
    </div>
</div>
<!-- 商品详情结束 -->
<!--为您推荐开始-->
<div class="section">
    <div class="container">
        <div class="newProductTitle">
            <div class="titleTopLineY"></div>
            <div class="titleTopLineC"></div>
            <p>NEW PRODUCT</p>
            <h3>为您 <span>推荐</span></h3>
        </div>
        <div class="lineB"></div>
        <ul class="contentListBox margin-top-87">
            <li class="contentItem">
                <div class="contentHeader recommendBg1"></div>
                <div class="contentFooter">
                    <div class="line"></div>
                    <p>VERFO LAB</p>
                    <h2>现代简约时尚布艺沙发</h2>
                    <h3>800<span>RMB</span></h3>
                    <a href="#" class="nowBuy active">立即购买</a>
                </div>
            </li>
            <li class="contentItem">
                <div class="contentHeader recommendBg2"></div>
                <div class="contentFooter">
                    <div class="line"></div>
                    <p>VERFO LAB</p>
                    <h2>现代简约时尚布艺沙发</h2>
                    <h3>800<span>RMB</span></h3>
                    <a href="#" class="nowBuy">立即购买</a>
                </div>
            </li>
            <li class="contentItem">
                <div class="contentHeader recommendBg3"></div>
                <div class="contentFooter">
                    <div class="line"></div>
                    <p>VERFO LAB</p>
                    <h2>现代简约时尚布艺沙发</h2>
                    <h3>800<span>RMB</span></h3>
                    <a href="#" class="nowBuy">立即购买</a>
                </div>
            </li>
            <li class="contentItem margin-right-0">
                <div class="contentHeader recommendBg4"></div>
                <div class="contentFooter">
                    <div class="line"></div>
                    <p>VERFO LAB</p>
                    <h2>现代简约时尚布艺沙发</h2>
                    <h3>800<span>RMB</span></h3>
                    <a href="#" class="nowBuy">立即购买</a>
                </div>
            </li>
        </ul>
    </div>
</div>
<!--为您推荐结束-->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
</head>
<body>
<!-- 底部开始 -->
<div id="footer">
    <div class="footerAfter"></div>
    <div class="footBox container">
        <div class="footBoxAfter"></div>
        <div class="erweima">
            <img src="/static/img/erweima.png" alt="">
            <p>扫码关注我们</p>
        </div>
        <div class="all">
            <p class="title">全部商品</p>
            <ul class="list">
                <li class="listItem">
                    <a href="##">沙发</a>
                </li>
                <li class="listItem">
                    <a href="##">床</a>
                </li>
                <li class="listItem">
                    <a href="##">椅子</a>
                </li>
            </ul>
        </div>
        <div class="new">
            <p class="title">新品发布</p>
            <ul class="list">
                <li class="listItem">
                    <a href="##">物流配送</a>
                </li>
                <li class="listItem">
                    <a href="##">免运费政策</a>
                </li>
                <li class="listItem">
                    <a href="##">物流配送服务</a>
                </li>
                <li class="listItem">
                    <a href="##">签收验货</a>
                </li>
                <li class="listItem">
                    <a href="##">物流查询</a>
                </li>
            </ul>
        </div>
        <div class="afterSale">
            <p class="title">售后服务</p>
            <ul class="list">
                <li class="listItem">
                    <a href="##">退换货政策</a>
                </li>
                <li class="listItem">
                    <a href="##">贵就赔</a>
                </li>
                <li class="listItem">
                    <a href="##">维修/安装</a>
                </li>
                <li class="listItem">
                    <a href="##">订单修改</a>
                </li>
                <li class="listItem">
                    <a href="##">退换货申请</a>
                </li>
                <li class="listItem">
                    <a href="##">我的发票</a>
                </li>
            </ul>
        </div>
        <div class="about">
            <p class="title">关于我们</p>
            <ul class="list">
                <li class="listItemAbout">客服热线：400-320-0031</li>
                <li class="listItemAbout">客服邮箱：867321000@qq.com</li>
                <li class="listItemAbout">地址：山西省太原市小店区VICRO总部</li>
            </ul>
        </div>
    </div>
    <p class="copy">Copyright &copy;2018 www.guazi.com All Rights Reserved  |  京ICP备15053955号 ICP证151071号</p>
</div>
<!-- 底部结束 -->
</body>
</html>
<script src="/static/js/swiper.min.js"></script>
<script>
    var swiper=new Swiper(".swiper-container",{
        slidesPerView:3
    });
</script>
</body>
</html>