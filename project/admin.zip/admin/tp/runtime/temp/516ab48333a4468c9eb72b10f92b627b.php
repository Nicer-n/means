<?php if (!defined('THINK_PATH')) exit(); /*a:3:{s:64:"D:\uek\admin\tp\public/../application/index\view\index\show.html";i:1557481943;s:57:"D:\uek\admin\tp\application\index\view\common\header.html";i:1557477279;s:57:"D:\uek\admin\tp\application\index\view\common\footer.html";i:1557373369;}*/ ?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=ie8">
    <title>商品详情</title>
    <link rel="stylesheet" href="/static/css/header.css">
    <link rel="stylesheet" href="/static/css/goodsDetail.css">
    <!--<link rel="stylesheet" href="https://at.alicdn.com/t/font_1092264_cawi5a8ic37.css">-->
</head>
<body>
<!--导航开始-->
<div class="mask">
   <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
</head>
<body>
<!-- 导航开始 -->
<div id="header">
    <div class="container headerBox">
        <div class="headerSearch">
            <div class="inputSearch">
                <input type="text" placeholder="请输入您想要的商品">
                <div class="icon"></div><!-- icon引入-->
            </div>
            <div class="inputLogin">
                <div class="icon"></div><!-- icon引入-->
                <div class="loginRegister">
                    <?php if(\think\Session::get('login')): ?>
                    <a href=""><p class="active">个人中心</p></a>
                    <?php else: ?>
                    <a href="<?php echo url('/index/index/login'); ?>"><p class="active">登录</p></a>
                    <a href=""><p style="margin-right:0;">注册</p></a>
                    <?php endif; ?>
                </div>

            </div>
        </div>
        <a href="#" class="headerLogo">
            <img src="/static/img/vicor.png" alt="">
        </a>
        <ul class="nav">
            <li>
                <a href="<?php echo url('/'); ?>" class="<?php if($hot==='index'): ?>active <?php endif; ?>">首页
                    <div class="<?php if($hot==='index'): ?>line <?php endif; ?>"></div>
                </a>
            </li>
            <li>
                <a href="<?php echo url('/index/index/category'); ?>" class="<?php if($hot==='category'): ?>active <?php endif; ?>">
                 产品分类
                     <div class=" <?php if($hot==='category'): ?>line <?php endif; ?>"></div>
                </a>
            </li>
            <li><a href="#">案例展示</a></li>
            <li><a href="#">品牌故事</a></li>
            <li class="listLast"><a href="#">设计团队</a></li>
        </ul>
    </div>
</div>
<!--  导航结束-->
</body>
</html>
</div>
<!--导航结束-->
<!--商品购买开始-->
<div class="goodsDetail container">
    <h6>首页>产品分类><span class="difCol">商品详情</span></h6>
    <div class="goodsBox">
        <div class="goodsDetImgs">
            <div class="imgBig">
                <img src="<?php echo $pics[0]; ?>" alt="">
                <div class="maskImg"></div>
            </div>
            <div class="imgSmalls">
                <?php if(is_array($pics) || $pics instanceof \think\Collection || $pics instanceof \think\Paginator): $i = 0; $__LIST__ = $pics;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$v): $mod = ($i % 2 );++$i;?>
                <div class="imgSmallsList">
                    <img src="<?php echo $v; ?>" alt="">
                </div>
                <?php endforeach; endif; else: echo "" ;endif; ?>
                <!--<div class="imgSmallsList">-->
                    <!--<img src="/static/img/goodsDetailSafeMain3.png" alt="">-->
                <!--</div>-->
                <!--<div class="imgSmallsList border">-->
                    <!--<img src="/static/img/goodsDetailSafeMain4.png" alt="">-->
                <!--</div>-->
                <!--<div class="imgSmallsList">-->
                    <!--<img src="/static/img/goodsDetailSafeMain5.png" alt="">-->
                <!--</div>-->
                <!--<div class="imgSmallsList noMargin">-->
                    <!--<img src="/static/img/goodsDetailSafeMain6.png" alt="">-->
                <!--</div>-->
            </div>
        </div>
        <div class="goodsDescription">
            <h2><?php echo $goods['name_en']; ?><br>
               <?php echo $goods['name_ch']; ?></h2>
            <div class="aLine"></div>
            <h3>种类<span><?php echo $goods['kinds']; ?></span></h3>
            <div class="highter">
                <span>颜色</span>
                &nbsp;
                <?php if(is_array($colors) || $colors instanceof \think\Collection || $colors instanceof \think\Paginator): $i = 0; $__LIST__ = $colors;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$v): $mod = ($i % 2 );++$i;?>
                <label>
                   <input type="radio" name="colors" value="<?php echo $v; ?>" data-checked="<?php echo $colors[0]; ?>" ref="color" v-model="color"> <?php echo $v; ?>
                </label>
                <?php endforeach; endif; else: echo "" ;endif; ?>
                <!--<span class="allCol1">-->
                    <!--<span class="circle">-->
                        <!--<span class="circle2"></span>-->
                    <!--</span>-->
                <!--</span>-->
                <!--<span class="allCol2"></span>-->
                <!--<span class="allCol2 allCol3"></span>-->
                <!--<span class="allCol2 allCol4"></span>-->
            </div>
            <h3>风格<span><?php echo $goods['style']; ?></span></h3>
            <h3>规格<span><?php echo $goods['size_des']; ?></span></h3>
            <h3>配送<span><?php echo $goods['area']; ?> 至 山西太原 家装物流 免运费</span></h3>
            <div class="aLine"></div>
            <h1><?php echo $goods['price']; ?><span>RMB</span></h1>
            <div class="wantSome">
                <span @click="dec">-</span>
                <!--<span v-model="number">1</span>-->
                <span>{{this.number}}</span>
                <span @click="add">+</span>
            </div>
            <div class="doSome">
                <span class="byNow" >立即购买</span>
                <span class="giInCar" @click="buy" id="<?php echo $goods['id']; ?>"  data-price="<?php echo $goods['price']; ?>">加入购物车</span>
            </div>
            <div class="doOther">
                <span><i class="iconfont ">&#xe650;</i>加入心愿单</span>    <!--换icon-->
                <span><i>&#xe650;</i>分享</span>          <!--换icon-->
                <span><i>&#xe650;</i>收藏</span>          <!--换icon-->
            </div>
        </div>
        <div class="showImage">
            <img src="<?php echo $pics[0]; ?>" alt="">
        </div>
        <div class="box"></div>
        <div class="no"></div>
    </div>
</div>
<script src="/static/js/vue.js"></script>
<script>
    new Vue({
        el:".goodsDescription",
        data:{
            number:1,
            color:""

        },
        methods:{
            add:function () {
                this.number++;
            },
            dec:function () {
                this.number--;
                if (this.number<1){
                    this.number=1;
                }
            },
            buy:function (e) {
                // location.assign("/index/index/order");
                location.href='/index/index/shopcar?number='+this.number+"&colors="+this.color+"&gid="+e.target.id+"&price="+e.target.getAttribute("data-price")*this.number;
            }
        },
        mounted:function () {
           this.color=this.$refs.color.getAttribute("data-checked");
        }
    });
</script>
<!--商品购买结束-->
<!--浏览过的商品开始-->
<div class="haveSaw container">
    <div class="aLine"></div>
    <h3>您已经<span>浏览</span>过的商品</h3>
    <ul class="haveSawImg container">
        <li><img src="/static/img/goodsDetailSaw1.png" alt=""></li>
        <li><img src="/static/img/goodsDetailSaw2.png" alt=""></li>
        <li><img src="/static/img/goodsDetailSaw3.png" alt=""></li>
        <li><img src="/static/img/goodsDetailSaw4.png" alt=""></li>
    </ul>
    <div class="haveSawButton">
        <span><i></i></span>                        <!--少icon-->
        <span class="toNext"><i></i></span>         <!--少icon-->
    </div>
    <div class="no"></div>
</div>
<!--浏览过的商品结束-->
<!--商品详情开始-->
<div class="sixImg container">
    <div class="topTitle">
        <div class="titleBox">
            <div class="topLine"></div>
            <div class="longLine"></div>
            <div class="text">COMMODITY DETAILS</div>
            <div class="title">
                <span class="black">商品</span>&nbsp;
                <span class="bold">详情</span>
            </div>
            <div class="bottomLine"></div>
        </div>
    </div>
    <div class="lotsImg">
        <div class="twoList">
            <div class="imgs">
                <div class="img bottomImg">
                    <div class="cover"></div>
                    <img src="/static/img/goodsDetailRealViewDetail.png" alt="">
                </div>
                <div class="img topImg">
                    <img src="/static/img/goodsDetailRealView.png" alt="">
                </div>
            </div>
            <h5>实景图</h5>
            <span>REAL VIEW</span>
        </div>
        <div class="twoList middle">
            <div class="imgs">
                <div class="img bottomImg">
                    <div class="cover"></div>
                    <img src="/static/img/goodsDetailScenarioDetail.png" alt="">
                </div>
                <div class="img topImg">
                    <img src="/static/img/goodsDetailScenario.png" alt="">
                </div>
            </div>
            <h5>场景图</h5>
            <span>SCENARIO</span>
        </div>
        <div class="twoList">
            <div class="imgs">
                <div class="img bottomImg">
                    <div class="cover"></div>
                    <img src="/static/img/goodsDetailSafeDetail2.png" alt="">
                </div>
                <div class="img topImg">
                    <img src="/static/img/goodsDetailSafeDetail1.png" alt="">
                </div>
            </div>
            <h5>场景图</h5>
            <span>REAL VIEW</span>
        </div>
    </div>
</div>
<!--商品详情结束-->
<!--商品尺寸开始-->
<div class="goodsSize container">
    <div class="topTitle">
        <div class="titleBox">
            <div class="topLine"></div>
            <div class="longLine"></div>
            <div class="text">PRODUCT SIZE</div>
            <div class="title">
                <span class="black">商品</span>&nbsp;
                <span class="bold">尺寸</span>
            </div>
            <div class="bottomLine"></div>
        </div>
    </div>

    <div class="goodsSizeImgBox">
        <div class="strongBack">
            <div class="nei">
                坚固椅背
            </div>
            <div class="alineToSafe"></div>
        </div>
        <div class="goodSizeImg">
            <div class="sizeImg">
                <img src="/static/img/goodsDetailProductSize.png" alt="">
            </div>
            <div class="strongBack">
                <div class="nei">
                    柔软坐垫
                </div>
                <div class="alineToSafe2"></div>
            </div>
            <div class="topSize"></div>
            <span class="topSizeFon">1000MM</span>
            <div class="bottomSize"></div>
            <span class="bottomSizeFon">600MM</span>
            <div class="leftSize"></div>
            <span class="leftSizeFon">1600MM</span>
        </div>
    </div>
</div>
<!--商品尺寸结束-->
<!--商品参数开始-->
<div class="topTitle">
    <div class="titleBox">
        <div class="topLine"></div>
        <div class="longLine"></div>
        <div class="text">COMMODITY PARAMETERS</div>
        <div class="title">
            <span class="black">商品</span>&nbsp;
            <span class="bold">参数</span>
        </div>
        <div class="bottomLine"></div>
    </div>
</div>
<div class="goodsNumber">
    <div class="cover"></div>
    <div class="trueMessage">
        <ul>
            <li class="li1">
                <span>商品品牌：<?php echo $goods['brand']; ?></span>
                <span>商品编号：<?php echo $goods['number']; ?>	</span>
                <span>色系：<?php echo $goods['colors']; ?></span>
            </li>
            <li class="li2">
                <span>商品材质：<?php echo $goods['material']; ?></span>
                <span>商品体积：0.72 M³</span>
                <span>产地： <?php echo $goods['area']; ?></span>
            </li>
            <li class="li3">
                <span>商品清单：单人座+4*抱</span>
                <span>风格：<?php echo $goods['style']; ?></span>
                <span>是否跨境货源：否</span>
            </li>
        </ul>
    </div>
</div>
<!--商品参数结束-->
<!--服务保障开始-->
<div class="service container">
    <div class="topTitle">
        <div class="titleBox">
            <div class="topLine"></div>
            <div class="longLine"></div>
            <div class="text">SERVICE GUARANTEE</div>
            <div class="title">
                <span class="black">服务</span>&nbsp;
                <span class="bold">保障</span>
            </div>
            <div class="bottomLine"></div>
        </div>
    </div>
    <ul class="tellMessage">
        <li class="leftLine">
            <div class="strongBack2">
                <div class="nei3">
                    1
                </div>
            </div>
            <span>优质选材</span>
        </li>
        <li>
            <div class="strongBack2">
                <div class="nei3">
                    2
                </div>
            </div>
            <span>科技生产</span>
        </li>
        <li>
            <div class="strongBack2">
                <div class="nei3">
                    3
                </div>
            </div>
            <span>精湛工艺</span>
        </li>
        <li class="marginRight">
            <div class="strongBack2">
                <div class="nei3">
                    4
                </div>
            </div>
            <span>贴心包装</span>
        </li>
        <div class="no"></div>
    </ul>
</div>
<!--服务保障开始-->
<!--用户评价开始-->
<div class="userSay container">
    <div class="topTitle">
        <div class="titleBox">
            <div class="topLine"></div>
            <div class="longLine"></div>
            <div class="text">USER EVALUATION</div>
            <div class="title">
                <span class="black">用户</span>&nbsp;
                <span class="bold">评价</span>
            </div>
            <div class="bottomLine"></div>
        </div>
    </div>
    <ul class="userList">
        <li>
            <div class="userHead">
                <img src="/static/img/goodsDetailUser1.png" alt="">
            </div>
            <div class="userContBox">
                <h4>我家有只猫<span><i class="iconfont">&#xe650;</i>
                                    <i class="iconfont">&#xe650;</i>
                                    <i class="iconfont">&#xe650;</i>
                                    <i class="iconfont">&#xe650;</i>
                                    <i class="iconfont">&#xe650;</i>
                </span></h4>
                <div class="userSayWord">
                    发货速度很快，卖家服务态度相当不错！
                </div>
                <div class="userImgs">
                    <img src="/static/img/goodsDetailUserImg1.png" alt="">
                    <img src="/static/img/goodsDetailUserImg2.png" alt="">
                </div>
                <div class="userSayTime">
                    <span><i></i>紫色</span>
                    <span class="leftMargin">2019-03-20 15:09:02发布</span>
                </div>
            </div>
            <div class="no"></div>
        </li>
        <li>
            <div class="userHead">
                <img src="/static/img/goodsDetailUser2.png" alt="">
            </div>
            <div class="userContBox">
                <h4>我家有只猫<span><i class="iconfont">&#xe650;</i>
                                    <i class="iconfont">&#xe650;</i>
                                    <i class="iconfont">&#xe650;</i>
                                    <i class="iconfont">&#xe650;</i>
                                    <i class="iconfont">&#xe650;</i>
                </span></h4>
                <div class="userSayWord">
                    网购很久，但是家具网购还是第一次买，和实体店一样，物美价廉，省心购物。
                </div>
                <div class="userSayWord">
                    追加：坐的很舒服，推荐给闺蜜了。
                </div>

                <div class="userSayTime">
                    <span><i class="green"></i>绿色</span>
                    <span class="leftMargin">2019-03-20 15:09:02发布</span>
                </div>
            </div>
            <div class="no"></div>
        </li>
        <li id="someNo">
            <div class="userHead">
                <img src="/static/img/goodsDetailUser3.png" alt="">
            </div>
            <div class="userContBox">
                <h4>我家有只猫<span><i class="iconfont">&#xe650;</i>
                                    <i class="iconfont">&#xe650;</i>
                                    <i class="iconfont">&#xe650;</i>
                                    <i class="iconfont">&#xe650;</i>
                                    <i class="iconfont">&#xe650;</i>
                </span></h4>
                <div class="userSayWord">
                    网购很久，但是家具网购还是第一次买，和实体店一样，物美价廉，省心购物。
                </div>
                <div class="userSayWord">
                    追加：坐的很舒服，推荐给闺蜜了。
                </div>

                <div class="userSayTime">
                    <span><i class="green"></i>绿色</span>
                    <span class="leftMargin">2019-03-20 15:09:02发布</span>
                </div>
            </div>
            <div class="no"></div>
        </li>
    </ul>
    <div class="toOtherPage">
        <span class="big prev">&lt;</span><!--上一个 少icon-->
        <span class="small">1</span>
        <span class="small">2</span>
        <span class="small active1">3</span>
        <span class="small">4</span>
        <span class="small">5</span>
        <span>.......</span>
        <span class="small">18</span>
        <span class="small">19</span>
        <span class="big next">&gt;</span><!--下一个 少icon-->
        <span>跳转到:</span>
        <span class="big"><input type="text" min="1" max="19"></span>
        <span>页</span>
        <span class="big">GO</span>
        <div class="no"></div>
    </div>
</div>
<!--用户评价结束-->
<!--为您推荐开始-->
<div class="newProduct container">
    <div class="newProductBox container">
        <div class="topTitle">
            <div class="titleBox">
                <div class="topLine"></div>
                <div class="longLine"></div>
                <div class="text">COMMEND</div>
                <div class="title">
                    <span class="black">为您</span>&nbsp;
                    <span class="bold">推荐</span>
                </div>
                <div class="bottomLine"></div>
            </div>
        </div>
        <ul class="container">
            <li>
                <div class="tuijianImg">
                    <img src="/static/img/newProduct1.png" alt="">
                </div>
                <div class="newProductText">
                    <div class="blackLine"></div>
                    <p class="en">VERFO LAB</p>
                    <p class="ch">现代简约时尚布艺沙发</p>
                    <div>
                        <span class="num">800</span>
                        <span class="RMB">RMB</span>
                    </div>
                    <a href="##" class="clickBuy">
                        <i class="iconfont"></i>           <!--少icon-->
                        点击购买
                    </a>
                </div>
            </li>
            <li>
                <div class="tuijianImg">
                    <img src="/static/img/newProduct2.png" alt="">
                </div>
                <div class="newProductText">
                    <div class="blackLine"></div>
                    <p class="en">VERFO LAB</p>
                    <p class="ch">现代简约时尚布艺沙发</p>
                    <div>
                        <span class="num">800</span>
                        <span class="RMB">RMB</span>
                    </div>
                    <a href="##" class="clickBuy">
                        <i class="iconfont"></i>    <!--少icon-->
                        点击购买
                    </a>
                </div>
            </li>
            <li>
                <div class="tuijianImg">
                    <img src="/static/img/newProduct3.png" alt="">
                </div>
                <div class="newProductText">
                    <div class="blackLine"></div>
                    <p class="en">VERFO LAB</p>
                    <p class="ch">现代简约时尚布艺沙发</p>
                    <div>
                        <span class="num">800</span>
                        <span class="RMB">RMB</span>
                    </div>
                    <a href="##" class="clickBuy">
                        <i class="iconfont"></i>    <!--少icon-->
                        点击购买
                    </a>
                </div>
            </li>
            <li class="noMargin">
                <div class="tuijianImg">
                    <img src="/static/img/newProduct4.png" alt="">
                </div>
                <div class="newProductText">
                    <div class="blackLine"></div>
                    <p class="en">VERFO LAB</p>
                    <p class="ch">现代简约时尚布艺沙发</p>
                    <div>
                        <span class="num">800</span>
                        <span class="RMB">RMB</span>
                    </div>
                    <a href="##" class="clickBuy">
                        <i class="iconfont"></i>     <!--少icon-->
                        点击购买
                    </a>
                </div>
            </li>
        </ul>
    </div>
</div>
<!--为您推荐结束-->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
</head>
<body>
<!-- 底部开始 -->
<div id="footer">
    <div class="footerAfter"></div>
    <div class="footBox container">
        <div class="footBoxAfter"></div>
        <div class="erweima">
            <img src="/static/img/erweima.png" alt="">
            <p>扫码关注我们</p>
        </div>
        <div class="all">
            <p class="title">全部商品</p>
            <ul class="list">
                <li class="listItem">
                    <a href="##">沙发</a>
                </li>
                <li class="listItem">
                    <a href="##">床</a>
                </li>
                <li class="listItem">
                    <a href="##">椅子</a>
                </li>
            </ul>
        </div>
        <div class="new">
            <p class="title">新品发布</p>
            <ul class="list">
                <li class="listItem">
                    <a href="##">物流配送</a>
                </li>
                <li class="listItem">
                    <a href="##">免运费政策</a>
                </li>
                <li class="listItem">
                    <a href="##">物流配送服务</a>
                </li>
                <li class="listItem">
                    <a href="##">签收验货</a>
                </li>
                <li class="listItem">
                    <a href="##">物流查询</a>
                </li>
            </ul>
        </div>
        <div class="afterSale">
            <p class="title">售后服务</p>
            <ul class="list">
                <li class="listItem">
                    <a href="##">退换货政策</a>
                </li>
                <li class="listItem">
                    <a href="##">贵就赔</a>
                </li>
                <li class="listItem">
                    <a href="##">维修/安装</a>
                </li>
                <li class="listItem">
                    <a href="##">订单修改</a>
                </li>
                <li class="listItem">
                    <a href="##">退换货申请</a>
                </li>
                <li class="listItem">
                    <a href="##">我的发票</a>
                </li>
            </ul>
        </div>
        <div class="about">
            <p class="title">关于我们</p>
            <ul class="list">
                <li class="listItemAbout">客服热线：400-320-0031</li>
                <li class="listItemAbout">客服邮箱：867321000@qq.com</li>
                <li class="listItemAbout">地址：山西省太原市小店区VICRO总部</li>
            </ul>
        </div>
    </div>
    <p class="copy">Copyright &copy;2018 www.guazi.com All Rights Reserved  |  京ICP备15053955号 ICP证151071号</p>
</div>
<!-- 底部结束 -->
</body>
</html>
<script>
    var thumbBox=document.querySelectorAll(".imgSmalls .imgSmallsList");
    var thumbs=document.querySelectorAll(".imgSmalls .imgSmallsList img");
    var imgBig=document.querySelector('.imgBig img');
    var show=document.querySelector(".showImage img");
    var detail=document.querySelector(".box");
    var mask=document.querySelector(".maskImg");
    var showBox=document.querySelector(".showImage");
    thumbs.forEach(function (img) {
        img.onclick=function () {
            imgBig.src=this.src;
            show.src=this.src;
        }
    });
    // thumbBox.forEach(function (e) {
    //     e.onclick=function () {
    //         e.classList.add("border");
    //     }
    // })
    detail.onmouseenter=function () {
        mask.style.display="block";
        showBox.style.display="block"
    };
    detail.onmouseleave=function () {
        mask.style.display="none";
        showBox.style.display="none"
    };
    detail.onmousemove=function (e) {
        let ox=e.offsetX;
        let oy=e.offsetY;
        let leftn=ox-200;
        let topn=oy-200;
        if (leftn<=0){
            leftn=0;
        }
        if (topn<=0){
            topn=0;
        }
        if (leftn>368){
            leftn=368;
        }
        if (topn>218){
            topn=218
        }
        mask.style.left=leftn+"px";
        mask.style.top=topn+"px";
        show.style.marginLeft=-leftn*2+"px";
        show.style.marginTop=-topn*2+"px";
    }

</script>
</body>
</html>