<?php if (!defined('THINK_PATH')) exit(); /*a:3:{s:65:"D:\uek\admin\tp\public/../application/index\view\index\index.html";i:1557394758;s:57:"D:\uek\admin\tp\application\index\view\common\header.html";i:1557477279;s:57:"D:\uek\admin\tp\application\index\view\common\footer.html";i:1557373369;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width">
    <title>首页</title>
    <link rel="stylesheet" href="/static/css/header.css">
    <link rel="stylesheet" href="/static/css/index.css">
    <link rel="stylesheet" href="/static/css/footer.css">
    <link rel="stylesheet" href="/static/css/animate.css">

</head>
<body>
<!--首页轮播图开始-->
<div id="banner">
    <!--  导航结束-->-
    <ul class="bannerBox">
        <li class="bannerImg bannerImg1"></li>
        <li class="bannerImg bannerImg2"></li>
        <li class="bannerImg bannerImg3"></li>
        <li class="bannerImg bannerImg4"></li>
        <li class="bannerImg bannerImg5"></li>
    </ul>
    <div class="mask">
        <!-- 导航开始 -->
        <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
</head>
<body>
<!-- 导航开始 -->
<div id="header">
    <div class="container headerBox">
        <div class="headerSearch">
            <div class="inputSearch">
                <input type="text" placeholder="请输入您想要的商品">
                <div class="icon"></div><!-- icon引入-->
            </div>
            <div class="inputLogin">
                <div class="icon"></div><!-- icon引入-->
                <div class="loginRegister">
                    <?php if(\think\Session::get('login')): ?>
                    <a href=""><p class="active">个人中心</p></a>
                    <?php else: ?>
                    <a href="<?php echo url('/index/index/login'); ?>"><p class="active">登录</p></a>
                    <a href=""><p style="margin-right:0;">注册</p></a>
                    <?php endif; ?>
                </div>

            </div>
        </div>
        <a href="#" class="headerLogo">
            <img src="/static/img/vicor.png" alt="">
        </a>
        <ul class="nav">
            <li>
                <a href="<?php echo url('/'); ?>" class="<?php if($hot==='index'): ?>active <?php endif; ?>">首页
                    <div class="<?php if($hot==='index'): ?>line <?php endif; ?>"></div>
                </a>
            </li>
            <li>
                <a href="<?php echo url('/index/index/category'); ?>" class="<?php if($hot==='category'): ?>active <?php endif; ?>">
                 产品分类
                     <div class=" <?php if($hot==='category'): ?>line <?php endif; ?>"></div>
                </a>
            </li>
            <li><a href="#">案例展示</a></li>
            <li><a href="#">品牌故事</a></li>
            <li class="listLast"><a href="#">设计团队</a></li>
        </ul>
    </div>
</div>
<!--  导航结束-->
</body>
</html>
        <hr>
        <div class="inner">
            <div class="title">IN LIVINGROOM</div>
            <div class="sale">SALE OFF TO 50%</div>
            <div class="lamp">LAMP LIGHTING FURNITURE</div>
            <a href="##" class="more">查看更多</a>
        </div>
        <div class="bannerPages">
            <div class="bannerPage active"></div>
            <div class="bannerPage" style="margin: 0 30px"></div>
            <div class="bannerPage"></div>
        </div>
    </div>
</div>
<!--首页轮播图结束-->
<!--新品首发开始-->
<div class="newProduct">
    <div class="newProductBox container">
        <div class="topTitle">
            <div class="titleBox">
                <div class="topLine"></div>
                <div class="longLine"></div>
                <div class="text">NEW PRODUCT</div>
                <div class="title">
                    <span class="black">新品</span>&nbsp;
                    <span class="bold">首发</span>
                </div>
                <div class="bottomLine"></div>
            </div>
        </div>
        <ul class="newProductCons">
            <?php if(is_array($newGoods) || $newGoods instanceof \think\Collection || $newGoods instanceof \think\Paginator): $i = 0; $__LIST__ = $newGoods;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$v): $mod = ($i % 2 );++$i;?>
            <li class="newProductCon">
                <img src="<?php echo $v['thumb']; ?>" alt="" class="lazy">
                <div class="newProductText">
                    <div class="blackLine"></div>
                    <p class="en"><?php echo $v['name_en']; ?></p>
                    <p class="ch"><?php echo $v['name_ch']; ?></p>
                    <div>
                        <span class="num"><?php echo $v['price']; ?></span>
                        <span class="RMB">RMB</span>
                    </div>
                    <a href="##" class="clickBuy">
                        <i class="iconfont">&#xe660;</i>
                        点击购买
                    </a>
                </div>
            </li>
            <?php endforeach; endif; else: echo "" ;endif; ?>
        </ul>
        <div class="buttonBox">
            <a href="##" class="button left">
                <i class="iconfont"></i>
            </a>
            <a href="##" class="button right">
                <i class="iconfont"></i>
            </a>
        </div>
    </div>
</div>
<!--新品首发结束-->
<!--热销产品开始-->
<div class="hotProduct">
    <div class="topTitle">
        <div class="titleBox">
            <div class="topLine"></div>
            <div class="longLine"></div>
            <div class="text">HOT PRODUCT</div>
            <div class="title">
                <span class="black">热销</span>&nbsp;
                <span class="bold">产品</span>
            </div>
            <div class="bottomLine"></div>
        </div>
    </div>
    <div class="hpBox">
        <div class="hpImg"></div>
        <div class="mask">
            <div class="container" id="hotProductBox">
                <div class="hotProductContent">
                    <img data-original="/static/img/hotProduct1.png" alt="" class="contentImg lazy">
                    <div class="priceBox">
                        <p class="title">舒适棉麻 布艺沙发</p>
                        <p class="introduce">告别繁琐多余的浮夸 保留实用主义的本质</p>
                        <div class="numRmb">
                            <span class="num">4450</span>
                            <span class="RMB">RMB</span>
                        </div>
                        <p class="buyNow">BUY NOW</p>
                        <div class="dots">
                            <div class="dot one"></div>
                            <div class="dot two"></div>
                            <div class="dot three"></div>
                        </div>
                    </div>
                </div>
                <div class="hotProductContents">
                    <div class="contentBox">
                        <div class="content">
                            <p class="title">FENDI CASA TUDOR</p>
                            <p class="introduce">现代简约客厅沙发</p>
                            <div class="imgBox imgBox2"></div>
                            <div class="price">
                                <span class="num">520</span>
                                <span class="RMB">RMB</span>
                            </div>
                            <div class="dots">
                                <div class="dot c1"></div>
                                <div class="dot c2"></div>
                                <div class="dot c3"></div>
                            </div>
                        </div>
                    </div>
                    <div class="contentBox secondChild">
                        <div class="content">
                            <p class="title">FENDI CASA TUDOR</p>
                            <p class="introduce">现代简约客厅沙发</p>
                            <div class="imgBox imgBox3"></div>
                            <div class="price">
                                <span class="num">520</span>
                                <span class="RMB">RMB</span>
                            </div>
                            <div class="dots">
                                <div class="dot c1"></div>
                                <div class="dot c2"></div>
                                <div class="dot c3"></div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="hotProductContents" style="margin-right: 0">
                    <div class="contentBox">
                        <div class="content">
                            <p class="title">FENDI CASA TUDOR</p>
                            <p class="introduce">现代简约客厅沙发</p>
                            <div class="imgBox imgBox4"></div>
                            <div class="price">
                                <span class="num">520</span>
                                <span class="RMB">RMB</span>
                            </div>
                            <div class="dots">
                                <div class="dot c1"></div>
                                <div class="dot c2"></div>
                                <div class="dot c3"></div>
                            </div>
                        </div>
                    </div>
                    <div class="contentBox secondChild">
                        <div class="content">
                            <p class="title">FENDI CASA TUDOR</p>
                            <p class="introduce">现代简约客厅沙发</p>
                            <div class="imgBox imgBox5"></div>
                            <div class="price">
                                <span class="num">520</span>
                                <span class="RMB">RMB</span>
                            </div>
                            <div class="dots">
                                <div class="dot c1"></div>
                                <div class="dot c2"></div>
                                <div class="dot c3"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!--热销产品结束-->
<!--案例展示开始-->
<div class="brandStory">
    <div class="brandStoryBox container">
        <div class="topTitle">
            <div class="titleBox">
                <div class="topLine"></div>
                <div class="longLine"></div>
                <div class="text">BRAND STORY</div>
                <div class="title">
                    <span class="black">案例</span>&nbsp;
                    <span class="bold">展示</span>
                </div>
                <div class="bottomLine"></div>
            </div>
        </div>
        <ul class="brandStoryCons">
            <li class="brandStoryCon">
                <img data-original="/static/img/brandStory1.png" alt="" class="lazy">
                <div class="shade">
                    <img data-original="/static/img/action.png" alt="" class="lazy">
                </div>
            </li>
            <li class="brandStoryCon">
                <p class="title">About the<br>chair designer.</p>
                <p class="article">透气性与柔和感并存，像三月的威风，也像五月的<br>
                    阳光，像恋人的热吻，也像傍晚归时的路灯。<br>
                    棉麻的柔软触感，让不大的客厅更加具有安全感，陷阱沙发的温柔里，追剧<br>
                    的日子变得幸福异常。</p>
                <a href="##" class="more">了解更多</a>
            </li>
            <li class="brandStoryCon">
                <p class="title">About the<br>chair designer.</p>
                <p class="article">透气性与柔和感并存，像三月的威风，也像五月的<br>
                    阳光，像恋人的热吻，也像傍晚归时的路灯。<br>
                    棉麻的柔软触感，让不大的客厅更加具有安全感，陷阱沙发的温柔里，追剧<br>
                    的日子变得幸福异常。</p>
                <a href="##" class="more">了解更多</a>
            </li>
            <li class="brandStoryCon">
                <img data-original="/static/img/brandStory2.png" alt="" class="lazy">
                <div class="shade">
                    <img data-original="/static/img/action.png" alt="" class="animated lazy" >
                </div></li>
        </ul>
    </div>
</div>
<!--案例展示结束-->
<!--品牌故事开始-->
<div class="commodityDetails">
    <div class="topTitle">
        <div class="titleBox">
            <div class="topLine"></div>
            <div class="longLine"></div>
            <div class="text">COMMODITY DETAILS</div>
            <div class="title">
                <span class="black">品牌</span>&nbsp;
                <span class="bold">故事</span>
            </div>
            <div class="bottomLine"></div>
        </div>
    </div>
    <div class="cdBox">
        <div class="cdImg"></div>
        <div class="mask">
            <div class="bgText">
                <div class="title">VICOR</div>
                <div class="line"></div>
                <div class="love">因为顾家，所以爱家</div>
                <div class="article">34年沙发制造工艺，保证每一张沙发都拥有出色品质，真材实料，
                    现代设计，让你的家更迷人温馨。</div>
                <div class="down"></div>														<!--引icon-->
            </div>
        </div>
    </div>
</div>
<!--品牌故事结束-->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
</head>
<body>
<!-- 底部开始 -->
<div id="footer">
    <div class="footerAfter"></div>
    <div class="footBox container">
        <div class="footBoxAfter"></div>
        <div class="erweima">
            <img src="/static/img/erweima.png" alt="">
            <p>扫码关注我们</p>
        </div>
        <div class="all">
            <p class="title">全部商品</p>
            <ul class="list">
                <li class="listItem">
                    <a href="##">沙发</a>
                </li>
                <li class="listItem">
                    <a href="##">床</a>
                </li>
                <li class="listItem">
                    <a href="##">椅子</a>
                </li>
            </ul>
        </div>
        <div class="new">
            <p class="title">新品发布</p>
            <ul class="list">
                <li class="listItem">
                    <a href="##">物流配送</a>
                </li>
                <li class="listItem">
                    <a href="##">免运费政策</a>
                </li>
                <li class="listItem">
                    <a href="##">物流配送服务</a>
                </li>
                <li class="listItem">
                    <a href="##">签收验货</a>
                </li>
                <li class="listItem">
                    <a href="##">物流查询</a>
                </li>
            </ul>
        </div>
        <div class="afterSale">
            <p class="title">售后服务</p>
            <ul class="list">
                <li class="listItem">
                    <a href="##">退换货政策</a>
                </li>
                <li class="listItem">
                    <a href="##">贵就赔</a>
                </li>
                <li class="listItem">
                    <a href="##">维修/安装</a>
                </li>
                <li class="listItem">
                    <a href="##">订单修改</a>
                </li>
                <li class="listItem">
                    <a href="##">退换货申请</a>
                </li>
                <li class="listItem">
                    <a href="##">我的发票</a>
                </li>
            </ul>
        </div>
        <div class="about">
            <p class="title">关于我们</p>
            <ul class="list">
                <li class="listItemAbout">客服热线：400-320-0031</li>
                <li class="listItemAbout">客服邮箱：867321000@qq.com</li>
                <li class="listItemAbout">地址：山西省太原市小店区VICRO总部</li>
            </ul>
        </div>
    </div>
    <p class="copy">Copyright &copy;2018 www.guazi.com All Rights Reserved  |  京ICP备15053955号 ICP证151071号</p>
</div>
<!-- 底部结束 -->
</body>
</html>
<div class="toTop"><i class="iconfont">&#xe609;</i></div>
<script src="/static/js/jQuery.js"></script>
<script src="/static/js/jquery.lazyload.js"></script>
<script src="/static/js/jquery.toTop.js"></script>
<script src="/static/js/index.js"></script>
</body>
</html>