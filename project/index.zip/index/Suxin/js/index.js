//内容左右进入
{
    let nav = document.querySelector(".sx-header");
    let font = document.querySelectorAll(".sx-list>li>a");
    let languageBox = document.querySelector(".language");
    let languageitems = document.querySelectorAll(".language-list>li");
    let languagetitle = document.querySelector(".language-center-title");
    let studiobox = document.querySelector(".studio");
    let studiotitle = document.querySelector(".studio>h3");
    let studiotext = document.querySelector(".studio-text");
    let flower = document.querySelector(".flower");
    let totop = document.querySelector(".totop");
    console.log(studiotext);
    window.onscroll = function () {
        //导航栏背景，字体
        let st = document.documentElement.scrollTop;
        font.forEach(function (ele) {
            if (st > 0) {
                ele.style.cssText = "color:#000";
                nav.classList.add("aaa");
            } else {
                nav.classList.remove("aaa");
                ele.style.cssText = "color:#fff";
            }
        });
        let target3 = flower.offsetTop - window.innerHeight;
        //回到顶部
        if (st > target3) {
            totop.style.display = "block";
        }
        else {
            totop.style.display="none";
        }
        // 素馨花语动画
        let target = languageBox.offsetTop - window.innerHeight;
        if (st > target) {
            languagetitle.classList.add("fadeInDown");
        }
        for (let i = 0; i < languageitems.length; i++) {
            let shuping = languageitems[i].offsetTop - window.innerHeight;
            // console.log(languageitems[i].offsetTop);
            if (st > shuping) {
                if (i % 2 !== 0) {
                    languageitems[i].classList.add("bounceInRight");
                } else {
                    languageitems[i].classList.add("bounceInLeft");
                }
            }
        }
        //素馨工作室
        let target2 = studiobox.offsetTop - window.innerHeight;
        if (st > target2) {
            studiotitle.classList.add("fadeInDown");
            studiotext.classList.add("fadeInUp");
        }

    };
}
//轮播图
{

    let inner = document.querySelector(".inner");
    let banner = document.querySelector(".banner");
    let prev = document.querySelector(".bd-left");
    let next = document.querySelector(".bd-right");
    let now = 1;

    function move() {
        inner.style.transition = "all 0.8s";
        now++;
        inner.style.marginLeft = now * -100 + "vw";
    }

    let st = setInterval(move, 2000);
    inner.addEventListener("transitionend", function () {
        flag = true;
        if (now === 3) {
            inner.style.transition = "none";
            inner.style.marginLeft = "-100vw";
            now = 1;
        }
        if (now === 0) {
            inner.style.transition = "none";
            inner.style.marginLeft = "-200vw";
            now = 2;
        }
    });
    banner.onmouseenter = function () {
        // inner.style.transition="none";
        clearInterval(st);
    };
    banner.onmouseleave = function () {
        clearInterval(st);
        st = setInterval(move, 2000);
    };
    window.onblur = function () {
        clearInterval(st);
    };
    window.onfocus = function () {
        clearInterval(st);
        st = setInterval(move, 2000);
    };
    let flag = true;
    next.onclick = function () {
        if (flag) {
            flag = false;
            move();
        }
    };
    prev.onclick = function () {
        if (flag) {
            flag = false;
            now -= 2;
            move();
        }


    }
}
{
    //内容轮播
    let inner = document.querySelector(".content-img-list");
    let box = document.querySelector(".flower-content");
    let next = document.querySelector(".btn-right");
    let prev = document.querySelector(".btn-left")
    console.log(inner);
    let now = 3;

    function items() {
        inner.style.transition = "all 0.8s";
        now++;
        inner.style.marginLeft = -now * 340 + "px";
    }

    let st = setInterval(items, 3000);
    box.onmouseenter = function () {
        clearInterval(st);
    };
    box.onmouseleave = function () {
        clearInterval(st);
        st = setInterval(items, 3000);
    };
    window.addEventListener("focus", function () {
        clearInterval(st);
        st = setInterval(items, 3000);
    });
    window.addEventListener("blur", function () {
        clearInterval(st);
    });
    inner.addEventListener("transitionend", function () {
        flag = true;
        if (now === 8) {
            inner.style.transition = "none";
            inner.style.marginLeft = "-1020px";
            now = 3;
        }
        if (now === 0) {
            inner.style.transition = "none";
            inner.style.marginLeft = "-1700px";
            now = 5;
        }
    });/*812465173*/
    let flag = true;
    next.onclick = function () {
        if (flag) {
            flag = false;
            items();
        }
    };
    prev.onclick = function () {
        if (flag) {
            flag = false;
            now -= 2;
            items();
        }
    }
}
//回到顶部
{
    let totop = document.querySelector(".totop");
    totop.onclick = function () {
        let l = document.documentElement.scrollTop;
        let s = l * 25 / 1000;
        let st = setInterval(function () {
            l -= s;
            if (l <= 0) {
                l = 0;
                clearInterval(st);
            }
            document.documentElement.scrollTop = l;
        }, 25);
    }
}