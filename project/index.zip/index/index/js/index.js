//轮播图
{
    var inner = $(".banner");
    console.log(inner);
    var now = 1;

    function banner() {
        now++;
        inner.css("transition", "all 0.8s");
        inner.css("marginLeft", now * -100 + "vw");
    }

    var st = setInterval(banner, 2000);
    inner.on("transitionend", function () {
        if (now === 3) {
            inner.css("transition", "none");
            inner.css("marginLeft", -100 + "vw");
            now = 1;
        }
    });
    $(".bannerBox").hover(function () {
        clearInterval(st);
    }, function () {
        st = setInterval(banner, 2000);
    });
    $(window).on("blur", ".banner",function () {
    clearInterval(st);
});
    $(window).on("focus",".banner", function () {
        clearInterval(st);
        st = setInterval(banner, 2000);
    });

}

//手风琴效果
{
    $(".remList>ul>li").hover(function () {
        $(this).siblings().removeClass("active");
        $(this).addClass("active");
    });
}
//限时折扣
{
    $(".flashGoods>ul>li")
        .hover(function () {
            $(this).css("transition", "all 0.8s");
            $(this).addClass("active")
        }, function () {
            $(this).removeClass("active");
        })
}
//效果展示 图片飞入
{
    $(window).scroll(function () {
        var st = $(document).scrollTop();
        console.log(st);
        var target = $(".showImages").offset().top - $(window).innerHeight();
        if (st > target) {
            $(".showImgs").addClass("bounceInUp")
            $(".showImg1").addClass("bounceInLeft");
            $(".showImg5").addClass("bounceInRight");

        }
    })
}
//返回顶部
{
    $(window).scroll(function () {
        var st = $(document).scrollTop();
        var target = $(".newBox").offset().top - $(window).innerHeight();
        if (st > target) {
            $(".totop").css("display", "block");
        }else{
            $(".totop").css("display", "none");
        }
    });
    let totop=document.querySelector(".totop");
    console.log(totop);
    totop.onclick=function () {
        let l=document.documentElement.scrollTop;
        let s=l*25/1000;
        let st=setInterval(function () {
            l-=s;
            if (l<=0){
                l=0;
                clearInterval(st);
            }
            document.documentElement.scrollTop=l;
        },25);
    }


}