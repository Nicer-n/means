//轮播图
{
    let bannerimgs = document.querySelectorAll("#imgBox>li");
let bannerpages = document.querySelectorAll("#banner-pageBox>li");
let len = bannerpages.length;
let now = 0;
let flag = false; //判断鼠标是否点击
let flag2 = true;
let banner = document.querySelector("#banner");
// console.log(bannerpages);
bannerpages.forEach(function (ele, index) {
    ele.onclick = function () {
        flag = true;
        now = index;
        for (let i = 0; i < len; i++) {
            bannerimgs[i].classList.remove("active");
            bannerpages[i].classList.remove("active");
        }
        ele.classList.add("active");
        bannerimgs[index].classList.add("active")
    }
});
let prev = document.querySelector("#prev");
let next = document.querySelector("#next");
console.log(next);

function move() {
    now++;
    if (now === len) {
        now = 0;
    }
    if (now === -1) {
        now = len - 1;
    }
    for (let i = 0; i < len; i++) {
        bannerpages[i].classList.remove("active");
        bannerimgs[i].classList.remove("active");
    }
    bannerimgs[now].classList.add("active");
    bannerpages[now].classList.add("active");
}

next.onclick = function () {
    if (flag2) {
        flag2 = false;
        flag = true;
        move();
    }

};
prev.onclick = function () {
    if (flag2) {
        flag2 = false;
        now -= 2;
        flag = true;
        move();
    }

};
let st = setInterval(move, 3000);
banner.onmouseenter = function () {
    clearInterval(st);
};
banner.onmouseleave = function () {
    if (flag) {
        return;
    }
    st = setInterval(move, 3000);
};
bannerimgs.forEach(function (ele) {
    ele.addEventListener("transitionend", function () {
        flag2 = true;
    })
});
}
//内容中的图书轮播
{
    function content(parent) {
        let item = parent.querySelector(".itemBox");
        let contentpages = parent.querySelectorAll(".content-pageBox>li");
        let rightbtn = parent.querySelector(".rightArrow");
        let leftbtn = parent.querySelector(".leftArrow");

        // console.log(leftbtn);
        let len = contentpages.length;
        let now = 0;
        contentpages.forEach(function (ele, index) {
            ele.onclick = function () {
                now = index;
                for (let i = 0; i < len; i++) {
                    contentpages[i].classList.remove("active2")
                }
                item.style.marginLeft = -296 * index + "px";
                this.classList.add("active2");
            }
        });
        rightbtn.onclick = function () {
            now++;
            if (now === len) {
                now = len - 1;
            }
            for (let i = 0; i < len; i++) {
                contentpages[i].classList.remove("active2");
            }
            item.style.marginLeft = -296 * now + "px";
            contentpages[now].classList.add("active2");
        }
        leftbtn.onclick = function () {
            now--;
            if (now === -1) {
                now = 0;
            }
            for (let i = 0; i < len; i++) {
                contentpages[i].classList.remove("active2");
            }
            contentpages[now].classList.add("active2");
            item.style.marginLeft = -296 * now + "px";
        }
    }

    let contentBox = document.querySelectorAll(".contentBox");
    contentBox.forEach(function (ele) {
        content(ele);
    });
}
//侧边导航栏
{
    let bar = document.querySelector(".aside>li:first-child");
    let erm = document.querySelector(".erm-box");
    // console.log(bar);
    bar.onmouseenter = function () {
        erm.style.display = "block";
    };
    bar.onmouseleave = function () {
        erm.style.display = "none";
    };
}
//导航栏购物车
{
    let car=document.querySelector("#car");
    let carItem=document.querySelector(".car-item");
    // console.log(carItem);
    car.onmouseenter=function () {
        carItem.style.display="block";
    }
    car.onmouseleave=function () {
        carItem.style.display="none";
    }
}
//导航栏下载APP下拉
{
    let download=document.querySelector(".download");
    let  downErm=document.querySelector(".down-erm");
    // console.log(downErm);
    download.onmouseenter=function () {
        downErm.style.display="block";
    };
    download.onmouseleave=function () {
        downErm.style.display="none";
    }
}
//按需加载
let container=document.querySelectorAll(".images");
console.log(container);
container.forEach(function (ele) {
    if(ele.offsetTop<window.innerHeight){
        let imgs=ele.querySelectorAll("img");
        imgs.forEach(function (img) {
            img.src=img.getAttribute("data-src");
        });
    }
});
let totop=document.querySelector(".totop");
window.onscroll=function(){
        let st=document.documentElement.scrollTop;
        let bigBox=document.querySelector(".big-box");
        let tar=bigBox.offsetTop-window.innerHeight;
        if (st>tar){
            totop.style.opacity="1";
        }
        else{
            totop.style.opacity="0";
        }
        container.forEach(function (ele) {
            if (st>ele.offsetTop-window.innerHeight){
                let imgs=ele.querySelectorAll("img");
                imgs.forEach(function (img) {
                    img.src=img.getAttribute("data-src");
                });
            }
        });
    };
//回到顶部
{
    
    let totop=document.querySelector(".totop");
    let bigBox=document.querySelector(".big-box");
    console.log(totop);
    totop.onclick=function () {
        let l=document.documentElement.scrollTop;
        let s=l*25/1000;
        let st=setInterval(function () {
            l-=s;
            if (l<=0){
                l=0;
                clearInterval(st);
            }
            document.documentElement.scrollTop=l;
        },25);
    }
}
//导航栏下拉
{
    let nav=document.querySelector(".search-list");
    let ItemDetail=document.querySelector(".item-detail");
    nav.onmouseenter=function(){
        ItemDetail.style.height="229px";
    };
    nav.onmouseleave=function(){
        ItemDetail.style.height="0";
    };
    let navItems=document.querySelectorAll(".search-item");
    let goodItems=document.querySelectorAll(".goodBox-list");
    // console.log(goodItems);
    navItems.forEach(function (ele,index) {
        ele.onmouseenter=function () {
            for (let i=0;i<goodItems.length;i++){
                goodItems[i].style.display="none";
            }
            goodItems[index].style.display="block";
        }
    });
}