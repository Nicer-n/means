<template>
    <div class="main">
        <el-row class="row">
            <el-col class="container" :span="10" :offset="7">
                <h1 align="center" class="title">VICOR后台管理系统</h1>
                <el-form :model="form" ref="form" label-width="80px" :rules="rules">
                    <el-form-item label="用户名" prop="name">
                        <el-input v-model="form.name" auto-complete="off" placeholder="请输入用户名"></el-input>
                    </el-form-item>
                    <el-form-item label="密码" prop="password">
                        <el-input type="password" v-model="form.password" auto-complete="off"
                                  placeholder="请输入密码"></el-input>
                    </el-form-item>
                    <el-form-item label="验证码" prop="code">
                        <el-input v-model="form.code" placeholder="请输入验证码"></el-input>

                    </el-form-item>
                    <el-form-item>
                        <img :src="src" alt="" @click="refresh">
                    </el-form-item>
                    <el-form-item>
                        <el-button type="success" @click="onSubmit">登录</el-button>
                        <el-button @click="resetForm('form')">重置</el-button>
                    </el-form-item>
                </el-form>
            </el-col>
        </el-row>
    </div>
</template>

<script>
    export default {
        name: "login",
        data: () => {
            let passwordValid = (rules, val, callback) => {
                if (val === "") {
                    callback();
                    return;
                }
                let reg = /^[0-9a-zA-Z]{6,}$/;
                if (reg.test(val)) {
                    callback();
                } else {
                    callback(new Error("密码必须由六位以上的的字母或者数字组成"))
                }
            };
            return {
                form: {
                    name: '',
                    password: '',
                    code: ''
                },
                rules: {
                    name: [{
                        required: true,
                        message: "请输入用户名",
                        trigger: "blur"
                    }],
                    password: [{
                        // validator:passwordValid,
                        required: true,
                        message: "请输入密码",
                        trigger: "blur"
                    }],
                    code: [
                        {
                            required: true,
                            message: "请输入验证码",
                            trigger: "blur"
                        },
                        {
                            min: 4,
                            max: 4,
                            message: "长度是四位",
                            trigger: "blur"

                        }
                    ]
                },
                src: "/api/admin/captcha",
            }
        },
        methods: {
            resetForm(formName) {
                this.$refs[formName].resetFields();
            },
            onSubmit: function () {
                this.$refs.form.validate(v => {
                    if (v) {
                        this.$http.post("/api/admin/checkLogin", this.form).then(r => {
                            if (r.data.code===200) {
                                console.log(r);
                                this.$message.success(r.data.msg);
                                sessionStorage.login=JSON.stringify(
                                    {
                                        name:r.data.name,
                                        role:r.data.role,
                                        login:true,
                                        token:r.data.token
                                    });
                                sessionStorage.token=r.data.token;
                                location.reload();
                            } else {
                                this.$message.error(r.data.msg);
                                this.src = "/api/admin/captcha?n=" + Date.now();
                            }
                        }).catch(() => {
                            this.$message.error("未知错误")
                        })
                    } else{
                        return false;
                    }
                })
            },
            refresh: function () {
                this.src = "/api/admin/captcha?n=" + Date.now();
            }
        },
    }
</script>

<style lang="scss" scoped>
    h1{
        color: #ffcb3f;
    }
    .main {
        width: 100%;
        height: 100%;
        background-image: url("assets/bg.jpg") ;
        background-size: 100%;
        display: flex;
        align-items: center;
    }

    .row {
        width: 100%;
        height: 450px;
    }

    .container {
        height: 450px;
        background: rgba(255, 255, 255, 0.73);
        padding: 30px;
        border-radius: 20px;
    }

    .title {
        margin-bottom: 30px;
    }
</style>