<template>
    <div>
        <el-table
                :data="tableData"
                style="width: 100%">
            <el-table-column
                    label="管理员"
                    prop="name">
            </el-table-column>
            <el-table-column
                    label="权限"
                    prop="role">
                <template slot-scope="scope">
                    {{scope.row.role===1?"超级管理员":"普通管理员"}}
                </template>
            </el-table-column>
            <el-table-column
                    label="激活状态"
            >
                <template slot-scope="scope">
                    <el-switch
                            v-model="scope.row.state"
                            active-color="#13ce66"
                            inactive-color="#ff4949"
                            :active-value="1"
                            :inactive-value="0"
                            @change="changeState(scope.row.id,scope.row.state)"
                    >
                    </el-switch>
                </template>
            </el-table-column>
            <el-table-column
                    align="center"
            >
                <template slot="header" slot-scope="scope">
                    <el-input
                            v-model="search"
                            size="mini"
                            placeholder="输入管理员姓名搜索"
                            @change="change"
                    />
                </template>
                <template slot-scope="scope">
                    <el-button type="primary" icon="el-icon-edit" circle @click="handleEdit(scope.row.id)"></el-button>
                    <el-button type="danger" icon="el-icon-delete" circle @click="handleDelete(scope.row.id)"></el-button>
                </template>
            </el-table-column>
        </el-table>
        <div class="block">
            <el-pagination
                    :current-page="page"
                    :page-sizes="[5, 10, 20, 40]"
                    :page-size="pageSize"
                    layout="total, sizes, prev, pager, next, jumper"
                    :total="total"
                    @current-change="currentChange"
                    @prev-click="prevClick"
                    @next-click="nextClick"
                    @size-change="sizeChange"
            >
            </el-pagination>
        </div>
    </div>
</template>

<script>
    export default {
        name: "AdminShow",
        data: () => ({
            tableData:[],
            search: '',
            page: 1,      //当前页数
            pageSize: 5,   //每一页显示的条数
            total: 0,
            state:"",
            url:"/api/admin/admin"
        }),
        methods:{
            fetchData: function () {
                //1.在服务器中设置头信息，取消跨域限制
                //2.通过jsonp请求数据
                //3. 设置代理 配置代理
                this.$http.get(this.url, {
                    params: {
                        page: this.page,
                        pageSize:this.pageSize,
                        search:this.search,
                        name:JSON.parse(sessionStorage.login).name
                    }
                }).then(r => {
                    if (r.data.code === 200) {
                        this.$message({
                            message: r.data.msg,
                            type: "success"
                        });
                        this.tableData = r.data.data;
                        this.total = r.data.total;
                    }
                });
            },
            currentChange: function (p) {
                this.page = p;
            },
            prevClick: function (p) {
                this.page=p;
            },
            nextClick:function (p) {
                this.page=p;
            },
            sizeChange:function (size) {
                this.pageSize=size;
                this.fetchData();
            },
            change:function () {
                this.page=1;
                this.fetchData();
            },
            handleDelete:function (id) {
                this.$confirm('确定要删除当前管理员吗, 是否继续?', '提示', {
                    confirmButtonText: '确定',
                    cancelButtonText: '取消',
                    type: 'warning'
                }).then(() => {
                    this.$http.delete(this.url,{
                        params:{
                            id
                        }
                    }).then(res=>{
                        if (res.data.code===200){
                            this.$message({
                                message:res.data.msg,
                                type:"success"
                            });
                            this.page=1;
                            this.fetchData();
                        }else {
                            this.$message({
                                message:res.data.msg,
                                type:"error"
                            });
                        }
                    }).catch(()=>{
                        this.$message({
                            message:"未知错误",
                            type:"error"
                        })
                    });
                }).catch(() => {
                    this.$message({
                        type: 'info',
                        message: '已取消删除'
                    });
                });
            },
            handleEdit:function (id) {
                this.$router.push({
                    name:"adminedit",
                    params:{
                        id
                    }
                })
            },
            changeState:function (id,state) {
                this.$http.put(this.url,{id,state}).then(r=>{
                    if (r.data.code===200){
                        this.$message.success(r.data.msg);
                        this.fetchData();
                    }else{
                        this.$message.error(r.data.msg);
                    }
                }).catch(()=>{
                    this.$message.error("未知错误");
                })
            },
        },
        mounted: function () {
            this.fetchData();
            this.$store.commit("changeActive","/adminShow");
        }
    }
</script>

<style lang="scss" scoped>
    .block {
        width: 100%;
        height: 100px;
        display: flex;
        justify-content: center;
        align-items: center;
    }
</style>