<template>
    <div>
        <el-col :span="12">
            <el-form label-width="80px" :model="form" :rules="rules" ref="form">
                <el-form-item label="用户名">
                    <span>{{form.username}}</span>
                </el-form-item>
                <el-form-item label="用户头型">
                    <img :src="form.avatar" alt="" class="avatar">
                </el-form-item>
                <el-form-item label="商品图片">
                    <img :src="form.thumb" alt="" class="avatar">
                </el-form-item>
                <el-form-item label="评论内容">
                  <span>{{form.content}}</span>
                </el-form-item>
                <el-form-item label="评论时间">
                    <span>{{form.content}}</span>
                </el-form-item>
                <el-form-item label="回复评论">
                    <el-input type="text" v-model="form.reply"></el-input>
                </el-form-item>
                <el-form-item>
                    <el-button type="primary" @click="onSubmit">回复留言</el-button>
                    <el-button  @click="cancel">取消</el-button>
                </el-form-item>
            </el-form>
        </el-col>
    </div>
</template>

<script>
    export default {
        name: "CommentEdit",
        data: () => ({
            form:{
            },
            rules:{
                reply:[{
                    required:true,
                    message:"请输入回复",
                    trigger:"blur"
                }]
            },
            url:"/api/comment/comment"
        }),
        methods:{
            fetchData:function () {
                this.$http.get(this.url,{
                    params:{
                        id:this.$route.params.id
                    }
                }).then(r=>{
                    if (r.data.code===200){
                        this.$message.success(r.data.msg);
                        this.form=r.data.data;
                    }
                }).catch(()=>{
                    this.$message.error("请求信息失败")
                })
            },
            onSubmit:function () {
                this.$http.put(this.url,this.form).then(r=>{
                    if (r.data.code===200){
                        this.$alert("回复成功", {
                            confirmButtonText: '' +
                                '确定',
                            callback: () => {
                                this.$router.push({name: "commentshow"})
                            }
                        })
                    }else{
                        this.$message.error(r.data.msg);
                    }
                }).catch(()=>{
                    this.$message.error("回复评论失败");
                })
            },
            cancel:function () {
                this.$router.go(-1);
            }

        },
        mounted: function () {
            this.$store.commit("changeActive", "/commentShow");
            this.fetchData();
        }
    }
</script>

<style lang="scss" scoped>

    .avatar-uploader .el-upload {
        border: 1px dashed #d9d9d9;
        border-radius: 6px;
        cursor: pointer;
        position: relative;
        overflow: hidden;
    }

    .avatar-uploader .el-upload:hover {
        border-color: #409EFF;
    }

    .avatar-uploader-icon {
        font-size: 28px;
        color: #8c939d;
        width: 178px;
        height: 178px;
        line-height: 178px;
        text-align: center;
        border: 1px dashed #d9d9d9;
        border-radius: 4px;
    }

    .thumb {
        width: 178px;
        height: 178px;
        display: block;
    }
    .avatar {
        width: 178px;
        height: 178px;
        display: block;
    }
</style>