<template>
    <div>
        <el-col :span="12">
            <el-form label-width="80px" :model="form" :rules="rules" ref="form">

                <el-form-item label="姓名"
                              prop="name"
                >
                    <el-input placeholder="请输入姓名" v-model="form.name"></el-input>
                </el-form-item>
                <el-form-item label="密码"
                              prop="password"
                >
                    <el-input type="password" placeholder="请输入密码" v-model="form.password"></el-input>
                </el-form-item>
                <el-form-item label="权限"
                              prop="role"
                >
                    <el-radio-group v-model="form.role">
                        <el-radio v-model="form.role" :label="1">超级管理员</el-radio>
                        <el-radio v-model="form.role" :label="0">普通管理员</el-radio>
                    </el-radio-group>

                </el-form-item>
                <el-form-item>
                    <el-button type="primary" @click="onSubmit">提交</el-button>
                </el-form-item>
            </el-form>
        </el-col>
    </div>
</template>

<script>
    export default {
        name: "AdminAdd",
        data: () => {
            let passwordReg = (rules, value, callback) => {
                let reg = /^[0-9a-zA-Z]{6,}$/;
                if (reg.test(value)) {
                    callback();
                } else {
                    callback(new Error("密码必须由六位以上的的字母或数字组成"))
                }
            };
            return {
                form: {
                    name: '',
                    password: "",
                    role: "",
                },
                rules: {
                    name:[
                        {
                            required: true,
                            message: "请输入姓名",
                            trigger: "blur"
                        }
                    ],
                    password: [
                        {
                            required: true,
                            message: "请输入密码",
                            trigger: "blur"
                        },
                        {
                            validator: passwordReg,
                            trigger: "blur"
                        }
                    ],
                    role:[{
                        required: true,
                        message: "请选择管理员权限",
                        trigger: "change"
                    }]
                }
            }
        },
        methods: {
            onSubmit: function () {
                this.$refs.form.validate(v=>{
                    if (v){
                        this.$http.post("/api/admin/admin",this.form).then(r=>{
                            if (r.data.code===200){
                                this.$alert("添加成功","",{
                                    confirmButtonText:'确定',
                                    callback:()=>{
                                        this.$router.push({
                                            name:"adminshow"
                                        });
                                    }
                                });
                            }else {
                                this.$message.error("提交失败");
                                this.form.colors=this.form.colors.split(",");
                            }
                        }).catch(()=>{
                            this.$message.error("提交失败");
                            this.form.colors=this.form.colors.split(",");
                        })
                    }else {
                        return false;
                    }
                })
            }
        },
        mounted: function () {
            this.$store.commit("changeActive", "/adminAdd")
        }
    }
</script>

<style lang="scss" scoped>

</style>