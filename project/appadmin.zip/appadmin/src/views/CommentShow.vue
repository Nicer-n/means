<template>
    <div>
        <el-form :inline="true" class="demo-form-inline" label-width="80px">
            <el-form-item label="商品名称">
                <el-input placeholder="请输入商品名称" v-model="name"></el-input>
            </el-form-item>
            <el-form-item label="商品分类">
                <el-select v-model="value" placeholder="请选择" :clearable="true">
                    <el-option
                            v-for="item in options"
                            :key="item.value"
                            :label="item.label"
                            :value="item.value">
                    </el-option>
                </el-select>
            </el-form-item>
            <el-form-item>
                <el-button type="primary" @click="search">搜索</el-button>
            </el-form-item>
        </el-form>
        <el-table
                :data="tableData"
                style="width: 100%">
            <el-table-column
                    label="用户"
                    prop="username">
            </el-table-column>
            <el-table-column
                    label="评价商品"
                    prop="name_ch">
            </el-table-column>
            <el-table-column
                    label="评论内容"
                    prop="content">
            </el-table-column>
            <el-table-column
                    label="评论时间"
                    prop="time">
            </el-table-column>
            <el-table-column
                    label="回复内容"
                    prop="reply">
            </el-table-column>
            <el-table-column
                    align="center"
                    label="操作"

            >
                <!--<template slot="header" slot-scope="scope">-->
                    <!--<el-input-->
                            <!--v-model="search"-->
                            <!--size="mini"-->
                            <!--placeholder="输入用户名搜索"-->
                            <!--@change="change"-->
                    <!--/>-->
                <!--</template>-->
                <template slot-scope="scope">
                    <el-button
                            size="mini"
                            @click="handleEdit(scope.row.id)">回复
                    </el-button>
                    <el-button
                            size="mini"
                            type="danger"
                            @click="handleDelete(scope.row.id)">删除
                    </el-button>
                </template>
            </el-table-column>
        </el-table>
        <div class="block">
            <el-pagination
                    :current-page="page"
                    :page-sizes="[5, 10, 20, 40]"
                    :page-size="pageSize"
                    layout="total, sizes, prev, pager, next, jumper"
                    :total="total"
                    @current-change="currentChange"
                    @prev-click="prevClick"
                    @next-click="nextClick"
                    @size-change="sizeChange"
            >
            </el-pagination>
        </div>
    </div>
</template>

<script>
    export default {
        name: "CommentShow",
        data: () => ({
            tableData: [],
            options: [],
            value:"",
            name:"",
            page: 1,
            pageSize: 5,
            total: 0,
            url: "/api/comment/comment"
        }),
        methods: {
            fetchData: function () {
                this.$http.get(this.url, {
                    params: {
                        page: this.page,
                        pageSize: this.pageSize,
                        search: this.search
                    }
                }).then(r => {
                    if (r.data.code === 200) {
                        this.$message.success(r.data.msg);
                        this.tableData = r.data.data;
                        this.total = r.data.total;
                    }
                }).catch(() => {
                    this.$message.error("未知错误")
                })
            },
            currentChange: function (p) {
                this.page = p;
            },
            prevClick: function (p) {
                this.page=p;
            },
            nextClick:function (p) {
                this.page=p;
            },
            sizeChange:function (size) {
                this.pageSize=size;
                this.fetchData();
            },
            change:function () {
                this.page=1;
                this.fetchData();
            },
            handleDelete:function (id) {
                this.$confirm('确定要删除当前评论吗, 是否继续?', '提示', {
                    confirmButtonText: '确定',
                    cancelButtonText: '取消',
                    type: 'warning'
                }).then(() => {
                    this.$http.delete(this.url,{
                        params:{
                            id
                        }
                    }).then(res=>{
                        if (res.data.code===200){
                            this.$message({
                                message:res.data.msg,
                                type:"success"
                            });
                            this.page=1;
                            this.fetchData();
                        }else {
                            this.$message({
                                message:res.data.msg,
                                type:"error"
                            });
                        }
                    }).catch(()=>{
                        this.$message({
                            message:"未知错误",
                            type:"error"
                        })
                    });
                }).catch(() => {
                    this.$message({
                        type: 'info',
                        message: '已取消删除'
                    });
                });
            },
            handleEdit:function (id) {
                this.$router.push({
                    name:"commentedit",
                    params:{
                        id
                    }
                })
            },
            search:function () {
                let params={};
                if (this.name !== "") {
                    params.name=this.name;
                }
                if (this.value!==""){
                    params.type=this.value;
                }
                this.$http.get(this.url,{
                    params
                }).then(r=>{
                    if (r.data.code===200){
                        this.$message.success(r.data.msg);
                        this.tableData=r.data.data;
                        this.total=r.data.total;
                    }else{
                        this.$message.error(r.data.msg)
                    }
                }).catch(()=>{
                    this.$message.error("未知错误")
                })
            },
            fetchTypeData:function () {
                this.$http.get("/api/type/type").then(r=>{
                    if (r.data.code===200){
                        this.options=r.data.data.map(v=>({
                            value:v.id,
                            label:v.category
                        }))
                    } else {
                        this.$message.error(r.data.msg);
                    }
                }).catch(()=>{
                    this.$message.error("分类信息回去失败");
                })
            },

        },
        watch:{
            page:function () {
                this.fetchData();
            }
        },
        mounted: function () {
            this.$store.commit("changeActive", "/commentShow");
            this.fetchData();
            this.fetchTypeData();
        }
    }
</script>

<style lang="scss" scoped>
    .block {
        width: 100%;
        height: 100px;
        display: flex;
        justify-content: center;
        align-items: center;
    }
</style>