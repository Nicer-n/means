<template>
    <div>
        <el-col :span="12">
            <el-form label-width="80px" :model="form" :rules="rules" ref="form">
                <el-form-item label="选择分类"
                              prop="tid"
                >
                    <el-select v-model="form.tid" placeholder="请选择">
                        <el-option
                                v-for="item in options"
                                :key="item.value"
                                :label="item.label"
                                :value="item.value">
                        </el-option>
                    </el-select>
                </el-form-item>
                <el-form-item label="中文名称"
                              prop="name_ch"
                >
                    <el-input placeholder="请输入中文名称"  v-model="form.name_ch"></el-input>
                </el-form-item>
                <el-form-item label="英文名称"
                              prop="name_en"
                >
                    <el-input placeholder="请输入英文名称" v-model="form.name_en"></el-input>
                </el-form-item>
                <el-form-item label="商品种类"
                              prop="kinds"
                >
                    <el-input placeholder="请输入英文名称" v-model="form.kinds"></el-input>
                </el-form-item>
                <el-form-item label="商品风格"
                              prop="style"
                >
                    <el-input placeholder="请输入英文名称" v-model="form.style"></el-input>
                </el-form-item>
                <el-form-item label="商品品牌"
                              prop="brand"
                >
                    <el-input placeholder="请输入商品品牌" v-model="form.brand"></el-input>
                </el-form-item>
                <el-form-item label="商品材质"
                              prop="material"
                >
                    <el-input placeholder="请输入商品品牌" v-model="form.material"></el-input>
                </el-form-item>
                <el-form-item label="商品编号"
                              prop="number"
                >
                    <el-input placeholder="请输入商品品牌" v-model="form.number"></el-input>
                </el-form-item>
                <el-form-item label="商品产地"
                              prop="area"
                >
                    <el-input placeholder="请输入商品品牌" v-model="form.area"></el-input>
                </el-form-item>
                <el-form-item label="适宜场合"
                              prop="suit"
                >
                    <el-input placeholder="请输入商品品牌" v-model="form.suit"></el-input>
                </el-form-item>
                <el-form-item label="商品价格"
                              prop="price"
                >
                    <el-input placeholder="请输入商品价格" v-model="form.price" type="number" min="1"></el-input>
                </el-form-item>
                <el-form-item label="缩略图"
                              prop="thumb"
                >

                    <el-upload
                            class="avatar-uploader"
                            action="/api/upload/upload"
                            :show-file-list="false"
                            :on-success="handleAvatarSuccess1"
                            :before-upload="beforeAvatarUpload">
                        <img v-if="form.thumb" :src="form.thumb" class="avatar">
                        <i v-else class="el-icon-plus avatar-uploader-icon"></i>
                        <el-input type="hidden" v-model="form.thumb"></el-input>
                    </el-upload>

                </el-form-item>
                <el-form-item label="商品图片"
                              prop="pics"
                >
                    <el-upload
                            class="upload-demo"
                            action="/api/upload/upload"
                            :on-preview="handlePreview"
                            :on-remove="handleRemove"
                            :before-remove="beforeRemove"
                            :on-success="handleAvatarSuccess4"
                            :file-list="fileList"
                            :limit="5"
                            v-model="form.pics"
                            list-type="picture">
                        <el-button size="small" type="primary">点击上传</el-button>
                        <div slot="tip" class="el-upload__tip">只能上传jpg/png文件，且不超过500kb</div>
                    </el-upload>
                </el-form-item>
                <el-form-item label="商品颜色" prop="colors">
                    <el-checkbox-group v-model="form.colors">
                        <el-checkbox  label="白色"></el-checkbox>
                        <el-checkbox label="绿色"></el-checkbox>
                        <el-checkbox label="黄色"></el-checkbox>
                    </el-checkbox-group>
                </el-form-item>
                <el-form-item label="PC端内容"
                              prop="content_pc"
                >
                    <el-input type="hidden" v-model="form.content_pc"></el-input>
                    <el-upload
                            class="avatar-uploader"
                            action="/api/upload/upload"
                            :show-file-list="false"
                            :on-success="handleAvatarSuccess2"
                            :before-upload="beforeAvatarUpload">
                        <img v-if="form.content_pc" :src="form.content_pc" class="avatar">
                        <i v-else class="el-icon-plus avatar-uploader-icon"></i>
                    </el-upload>
                </el-form-item>
                <el-form-item label="移动端内容"
                              prop="content_mob"
                >
                    <el-input type="hidden" v-model="form.content_mob"></el-input>
                    <el-upload
                            class="avatar-uploader"
                            action="/api/upload/upload"
                            :show-file-list="false"
                            :on-success="handleAvatarSuccess3"
                            :before-upload="beforeAvatarUpload">
                        <img v-if="form.content_mob" :src="form.content_mob" class="avatar">
                        <i v-else class="el-icon-plus avatar-uploader-icon"></i>
                    </el-upload>
                </el-form-item>
                <el-form-item label="商品规格"
                              prop="size_des"
                >
                    <el-input placeholder="请输入尺寸描述" v-model="form.size_des"></el-input>
                </el-form-item>
                <el-form-item label="是否上架"
                              prop="state"
                >
                    <el-radio-group v-model="form.state">
                        <el-radio v-model="form.state" :label="1">上架</el-radio>
                        <el-radio v-model="form.state" :label="0">暂不上架</el-radio>
                    </el-radio-group>

                </el-form-item>
                <el-form-item label="是否推荐"
                              prop="recommend"
                >
                    <el-switch
                            v-model="form.recommend"
                            active-color="#13ce66"
                            inactive-color="#ff4949"
                            :active-value="1"
                            :inactive-value="0"
                    >
                    </el-switch>
                </el-form-item>
                <el-form-item label="是否跨境货源"
                              prop="cross_border"
                >
                    <el-switch
                            v-model="form.cross_border"
                            active-color="#13ce66"
                            inactive-color="#ff4949"
                            :active-value="1"
                            :inactive-value="0"
                    >
                    </el-switch>
                </el-form-item>
                <el-form-item>
                    <el-button type="primary" @click="onSubmit">提交</el-button>
                    <el-button @click="cancel">取消</el-button>
                </el-form-item>
            </el-form>
        </el-col>
    </div>
</template>

<script>
    export default {
        name: "GoodsAdd",
        data: () => ({
            form: {
                name_ch: "",
                name_en: "",
                tid: "",
                kinds:"",
                style:"",
                brand:"",
                material:"",
                number:"",
                area:"",
                cross_border:"",
                suit:"",
                thumb:"",
                price:"",
                content_pc:"",
                content_mob:"",
                size_des:"",
                state:"",
                tags:"",
                pics:"",
                recommend:"",
                colors:[],

            },
            rules: {
                name_ch: [{
                    required:true,
                    message:"请输入商品名称",
                    trigger:"blur"
                }],
                name_en: [{
                    required:true,
                    message:"请输入商品英文名称",
                    trigger:"blur"
                }],
                kinds: [{
                    required:true,
                    message:"请输入商品种类",
                    trigger:"blur"
                }],
                style: [{
                    required:true,
                    message:"请输入商品风格",
                    trigger:"blur"
                }],
                brand: [{
                    required:true,
                    message:"请输入商品品牌",
                    trigger:"blur"
                }],
                number: [{
                    required:true,
                    message:"请输入商品编号",
                    trigger:"blur"
                }],
                area: [{
                    required:true,
                    message:"请输入商品产地",
                    trigger:"blur"
                }],
                tid: [{
                    required:true,
                    message:"请选择商品类型",
                    trigger:"change"
                }],
                thumb:[{
                    required:true,
                    message:"请上传商品缩略图",
                }],
                price:[{
                    required:true,
                    message:"请输入商品价格",
                    trigger:"blur"
                }],
                pics:[{
                    required:true,
                    message:"请上传图片",
                }],
                suit:[{
                    required:true,
                    message:"请输入商品适用场合",
                    trigger:"blur"
                }],
                content_pc:[{
                    required:true,
                    message:"请输入pc端内容",
                }],
                content_mob:[{
                    required:true,
                    message:"请输入移动端端内容",
                }],
                colors: [{
                    type: "array",
                    required: true,
                    message: "请选择商品颜色",
                    trigger: "change"
                }],
                size_des:[{
                    required:true,
                    message:"请输入商品规格",
                    trigger:"blur"
                }],
                state:[{
                    required:true,
                    message:"请选择是否上架",
                    trigger:"change"
                }],
                cross_border:[{
                    required:true,
                    message:"请选择是否跨域资源",
                    trigger:"change"
                }],
                recommend:[{
                    required:true,
                    message:"请选择是否推荐",
                    trigger:"change"
                }],
                material:[{
                    required:true,
                    message:"请输入商品材质",
                    trigger:"blur"
                }],
            },
            options: [],
            value: "",
            fileList: [],
        }),
        methods: {
            fetchTypeData: function () {
                this.$http.get("/api/type/type").then(r => {
                    if (r.data.code === 200) {
                        this.options = r.data.data.map(v => ({
                            value: v.id,
                            label: v.category
                        }))
                    } else {
                        this.$message.error(r.data.msg);
                    }
                }).catch(() => {
                    this.$message.error("分类信息回去失败");
                })
            },
            handlePreview(file) {
                console.log(file);
            },
            handleExceed(files, fileList) {
                this.$message.warning(`当前限制选择 5 个文件，本次选择了 ${files.length} 个文件，共选择了 ${files.length + fileList.length} 个文件`);
            },
            beforeRemove(file, fileList) {
                return this.$confirm(`确定移除 ${file.name}？`);
            },
            handleAvatarSuccess1: function (r) {
                if (r !== "") {
                    this.$message({
                        message: "上传成功",
                        type: "success"
                    });
                    this.form.thumb = r;
                } else {
                    this.$message({
                        message: "上传失败",
                        type: "error"
                    });
                }
            },
            handleAvatarSuccess2: function (r) {
                if (r !== "") {
                    this.$message({
                        message: "上传成功",
                        type: "success"
                    });
                    this.form.content_pc = r;
                } else {
                    this.$message({
                        message: "上传失败",
                        type: "error"
                    });
                }
            },
            handleAvatarSuccess3: function (r) {
                if (r !== "") {
                    this.$message({
                        message: "上传成功",
                        type: "success"
                    });
                    this.form.content_mob = r;
                } else {
                    this.$message({
                        message: "上传失败",
                        type: "error"
                    });
                }
            },
            handleAvatarSuccess4: function (r,file) {
                if (r !== "") {
                    this.$message({
                        message: "上传成功",
                        type: "success"
                    });
                    this.fileList.push(file);
                } else {
                    this.$message({
                        message: "上传失败",
                        type: "error"
                    });
                }
            },
            handleRemove:function(file,fileList){
                this.fileList=fileList;
            },
            beforeAvatarUpload(file) {
                const isJPG = file.type === 'image/jpeg' || file.type === 'image/png';
                const isLt500KB = file.size / 1024 / 1024 < 0.5;

                if (!isJPG) {
                    this.$message.error('上传头像图片只能是 JPG 格式或者PNG格式!');
                }
                if (!isLt500KB) {
                    this.$message.error('上传头像图片大小不能超过 500KB!');
                }
                return isJPG && isLt500KB;
            },
            onSubmit:function () {
                this.form.pics=this.fileList.map(v=>v.response).join(";");
                this.$refs.form.validate((v)=>{
                    if (v){
                        this.form.colors=this.form.colors.join();
                        this.$http.post("/api/goods/goods",this.form).then(r=>{
                            if (r.data.code===200){
                                this.$alert("添加成功","",{
                                    confirmButtonText:'确定',
                                    callback:()=>{
                                        this.$router.push({
                                            name:"goodsshow"
                                        });
                                    }
                                });
                            }else {
                                this.$message.error("提交失败");
                                this.form.colors=this.form.colors.split(",");
                            }
                        }).catch(()=>{
                            this.$message.error("提交失败");
                            this.form.colors=this.form.colors.split(",");
                        })
                    }else {
                        return false;
                    }
                })
            },
            cancel:function () {
                this.$router.go(-1);
            }
        },
        mounted: function () {
            this.$store.commit("changeActive", "/goodsAdd");
            this.fetchTypeData();
        }
    }
</script>

<style lang="scss" scoped>
    .avatar-uploader .el-upload {
        border: 1px dashed #d9d9d9;
        border-radius: 6px;
        cursor: pointer;
        position: relative;
        overflow: hidden;
    }

    .avatar-uploader .el-upload:hover {
        border-color: #409EFF;
    }

    .avatar-uploader-icon {
        border: 1px dashed #d9d9d9;
        border-radius: 6px;
        font-size: 28px;
        color: #8c939d;
        width: 178px;
        height: 178px;
        line-height: 178px;
        text-align: center;
    }

    .avatar-uploader-icon:hover {
        border-color: #409EFF;
    }

    .avatar {
        width: 178px;
        height: 178px;
        display: block;
    }
</style>