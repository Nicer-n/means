<template>
    <div>
        <el-col :span="12">
            <el-form label-width="80px" :model="form" :rules="rules" ref="form">
                <el-form-item label="账号名称">
                    <el-input v-model="form.name" :readonly="true"></el-input>
                </el-form-item>
                <el-form-item label="原始密码" prop="password">
                    <el-input v-model="form.password"  type="password"></el-input>
                </el-form-item>
                <el-form-item label="新密码" prop="newPass">
                    <el-input v-model="form.newPass" type="password"></el-input>
                </el-form-item>
                <el-form-item label="确认密码" prop="newPass2">
                    <el-input v-model="form.newPass2" type="password"></el-input>
                </el-form-item>
                <el-form-item>
                    <el-button type="primary" @click="onSubmit">提交</el-button>
                </el-form-item>
            </el-form>
        </el-col>
    </div>
</template>

<script>
    export default {
        name: "AdminPasswordChange",
        data: function () {
            let passwordReg = (rules, value, callback) => {
                let reg = /^[0-9a-zA-Z]{6,}$/;
                if (reg.test(value)) {
                    callback();
                } else {
                    callback(new Error("密码必须由六位以上的的字母或数字组成"))
                }
            };
            let repeatReg = (rules, value, callback) => {
                if (value !== this.form.newPass) {
                    callback(new Error("两次输入必须一致"))
                } else {
                    callback();
                }
            };
            return {
                form: {
                    name: JSON.parse(sessionStorage.login).name,
                    password: "",
                    newPass:"",
                    newPass2:"",
                },
                rules: {
                    password: [{
                        required: true,
                        message: "请输入原始密码",
                        trigger: "blur"
                    }],
                    newPass: [
                        {
                            required: true,
                            message: "请输入原始密码",
                            trigger: "blur"
                        },
                        {
                            validator: passwordReg,
                            trigger: "blur"
                        }
                    ],
                    newPass2: [
                        {
                            required: true,
                            message: "请输入原始密码",
                            trigger: "blur"
                        },
                        {
                            validator: repeatReg,
                            trigger: "blur"
                        },
                        {

                            validator: passwordReg,
                            trigger: "blur"
                        }
                    ],
                }
            }
        },
        methods: {
            onSubmit: function () {
                this.$refs.form.validate(v => {
                    if (v) {
                        // this.$http.post("/api/admin/changePass",this.form).then(r=>{
                        this.$http.put("/api/admin/changePass",this.form).then(r=>{
                           if (r.data.code===200){
                               this.$message.success(r.data.msg);
                               this.$refs.form.resetFields();
                           }else{
                               this.$message.error(r.data.msg);
                           }
                        }).catch(()=>{
                            this.$message.error("未知错误");
                        })
                    } else {
                        return false;
                    }
                });
            }
        },
        mounted: function () {
            this.$store.commit("changeActive", "/adminPassword");
        }
    }
</script>

<style lang="scss" scoped>

</style>