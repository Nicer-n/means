<template>
    <div>
        <el-table
                :data="tableData"
                style="width: 100%">
            <el-table-column
                    label="收件人"
                    prop="name">
            </el-table-column>
            <el-table-column
                    label="联系方式"
                    prop="phone">
            </el-table-column>
            <el-table-column
                    label="详细地址"
                    prop="address">
            </el-table-column>
            <el-table-column
                    label="是否设为默认地址"
            >
                <template slot-scope="scope">
                    <el-switch
                            v-model="scope.row.is_default"
                            active-color="#13ce66"
                            inactive-color="#ff4949"
                            :active-value="1"
                            :inactive-value="0"
                            @change="changeState(scope.row.id,scope.row.is_default)"
                    >
                    </el-switch>
                </template>
            </el-table-column>
            <el-table-column
                    align="right">
                <template slot="header" slot-scope="scope">
                    <el-input
                            v-model="search"
                            size="mini"
                            placeholder="输入收件人姓名搜索"
                            @change="change"
                    />
                </template>
                <template slot-scope="scope">
                    <el-button
                            size="mini"
                            @click="handleEdit(scope.row.id)">编辑
                    </el-button>
                    <el-button
                            size="mini"
                            type="danger"
                            @click="handleDelete(scope.row.id)">删除
                    </el-button>
                </template>
            </el-table-column>
        </el-table>
        <div class="block">
            <el-pagination
                    :current-page="page"
                    :page-sizes="[5, 10, 20, 40]"
                    :page-size="pageSize"
                    layout="total, sizes, prev, pager, next, jumper"
                    :total="total"
                    @current-change="currentChange"
                    @prev-click="prevClick"
                    @next-click="nextClick"
                    @size-change="sizeChange"
            >
            </el-pagination>
        </div>
    </div>
</template>

<script>
    export default {
        name: "AddressShow",
        data: () => ({
            tableData: [],
            search: '',
            page: 1,      //当前页数
            pageSize: 5,   //每一页显示的条数
            total: 0,
            url:"/api/address/address"
        }),
        methods:{
            fetchData:function () {
                this.$http.get(this.url,{
                    params:{
                        page: this.page,
                        pageSize:this.pageSize,
                        search:this.search,
                    }
                }).then(r=>{
                    if (r.data.code===200){
                        this.$message.success(r.data.msg);
                        this.tableData=r.data.data;
                        this.total=r.data.total;
                    }else{
                        this.$message.error(r.data.msg);
                    }
                }).catch(()=>{
                    this.$message.error("未知错误")
                })
            },
            currentChange: function (p) {
                this.page = p;
            },
            prevClick: function (p) {
                this.page=p;
            },
            nextClick:function (p) {
                this.page=p;
            },
            sizeChange:function (size) {
                this.pageSize=size;
                this.fetchData();
            },
            change:function () {
                this.page=1;
                this.fetchData();
            },
            handleDelete:function (id) {
                this.$confirm('确定要删除当前收货地址吗, 是否继续?', '提示', {
                    confirmButtonText: '确定',
                    cancelButtonText: '取消',
                    type: 'warning'
                }).then(() => {
                    this.$http.delete(this.url,{
                        params:{
                            id,
                        }
                    }).then(res=>{
                        if (res.data.code===200){
                            this.$message({
                                message:res.data.msg,
                                type:"success"
                            });
                            this.page=1;
                            this.fetchData();
                        }else {
                            this.$message({
                                message:res.data.msg,
                                type:"error"
                            });
                        }
                    }).catch(()=>{
                        this.$message({
                            message:"未知错误",
                            type:"error"
                        })
                    });
                }).catch(() => {
                    this.$message({
                        type: 'info',
                        message: '已取消删除'
                    });
                });
            },
            changeState:function (id,is_default) {
                this.$http.put(this.url,{id,is_default}).then(r=>{
                    if (r.data.code===200){
                        this.$message.success(r.data.msg);
                        this.fetchData();
                    }else{
                        this.$message.error(r.data.msg);
                    }
                }).catch(()=>{
                    this.$message.error("未知错误");
                })
            }
        },
        watch: {
            page: function () {
                this.fetchData();
            }
        },
        mounted:function () {
            this.fetchData();
            this.$store.commit("changeActive","/addressShow");

        }
    }
</script>

<style lang="scss" scoped>
    .block {
        width: 100%;
        height: 100px;
        display: flex;
        justify-content: center;
        align-items: center;
    }
</style>