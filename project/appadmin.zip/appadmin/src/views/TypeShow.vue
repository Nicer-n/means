<template>
   <div>
       <el-table
               :data="tableData"
               style="width: 100%">
           <el-table-column
                   label="分类名称"
                   prop="category">
           </el-table-column>
           <el-table-column
                   label="分类图片"
                   prop="thumb">
               <template slot-scope="scope">
                   <img :src="scope.row.thumb" alt="" style="width: 50px;height: 50px;border-radius: 50%;vertical-align: middle">
               </template>
           </el-table-column>
           <el-table-column
                   label="分类排序"
                   prop="sort">
           </el-table-column>
           <el-table-column
                   align="right">
               <template slot="header" slot-scope="scope">
                   <el-input
                           v-model="search"
                           size="mini"
                           placeholder="输入分类名称搜索"
                           @change="change"
                   />
               </template>
               <template slot-scope="scope">
                   <el-button
                           size="mini"
                           @click="handleEdit(scope.row.id)">编辑
                   </el-button>
                   <el-button
                           size="mini"
                           type="danger"
                           @click="handleDelete(scope.row.id)">删除
                   </el-button>
               </template>
           </el-table-column>
       </el-table>
       <div class="block">
           <el-pagination
                   @size-change="sizeChange"
                   @current-change="currentChange"
                   :current-page="page"
                   :page-sizes="[5, 10, 20, 40]"
                   :page-size="pageSize"
                   layout="total, sizes, prev, pager, next, jumper"
                   :total="total"
                   @prev-click="prevClick"
                   @next-click="nextClick"
           >
           </el-pagination>
       </div>
   </div>
</template>

<script>
    export default {
        name: "TypeShow",
        data: () => ({
            tableData:[],
            url:"/api/type/type",
            page:1,
            pageSize:5,
            search:"",
            total:0
        }),
        methods:{
            fetchData:function () {
                this.$http.get(this.url,{
                    params:{
                        page:this.page,
                        pageSize:this.pageSize,
                        search:this.search,
                    }
                }).then(res=>{
                   if (res.data.code===200){
                        this.$message.success(res.data.msg);
                        this.tableData=res.data.data;
                        this.total=res.data.total
                   }else {
                       this.$message.error(res.data.msg);
                   }
                }).catch(()=>{
                    this.$message.error("未知错误");
                })
            },
            currentChange:function (p) {
                this.page=p
            },
            prevClick:function (p) {
                this.page=p;
            },
            nextClick:function (p) {
                this.page=p;
            },
            sizeChange:function (size) {
                this.pageSize=size;
                this.fetchData();
            },
            handleDelete:function (id) {
                this.$confirm('确定要删除当前用户吗, 是否继续?', '提示', {
                    confirmButtonText: '确定',
                    cancelButtonText: '取消',
                    type: 'warning'
                }).then(()=>{
                    this.$http.delete(this.url,{
                        params:{
                            id
                        }
                    }).then(res=>{
                       if (res.data.code===200){
                           this.$message.success(res.data.msg);
                           this.fetchData();
                       }else {
                           this.$message.error(res.data.msg);
                       }
                    }).catch(()=>{
                        this.$message.error("未知错误")
                    })
                }).catch(()=>{
                    this.$message({
                        type: 'info',
                        message: '已取消删除'
                    });
                })
            },
            change:function () {
              this.fetchData();
            },
            handleEdit:function (id) {
                this.$router.push({
                    name:"typeedit",
                    params:{
                        id
                    }
                })
            }

        },
        watch:{
            page:function () {
                this.fetchData();
            }
        },
        mounted:function () {
            this.$store.commit("changeActive","/typeShow");
            this.fetchData();
        }
    }
</script>

<style lang="scss" scoped>
    .block{
        width: 100%;
        height: 100px;
        display: flex;
        justify-content: center;
        align-items: center;
    }
</style>