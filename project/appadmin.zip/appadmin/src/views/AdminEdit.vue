<template>
    <div>
        <el-col :span="12">
            <el-form label-width="80px" :model="form" :rules="rules" ref="form">

                <el-form-item label="姓名"
                              prop="name"
                >
                    <el-input placeholder="请输入姓名" v-model="form.name"></el-input>
                </el-form-item>
                <el-form-item label="密码"
                              prop="password"
                >
                    <el-input placeholder="请输入密码" v-model="form.password" type="password"></el-input>
                </el-form-item>
                <el-form-item label="权限"
                              prop="role"
                >
                    <el-radio-group v-model="form.role">
                        <el-radio v-model="form.role" :label="1">超级管理员</el-radio>
                        <el-radio v-model="form.role" :label="0">普通管理员</el-radio>
                    </el-radio-group>

                </el-form-item>
                <el-form-item>
                    <el-button type="primary" @click="onSubmit">提交</el-button>
                </el-form-item>
            </el-form>
        </el-col>
    </div>
</template>

<script>
    export default {
        name: "AdminAdd",
        data: () => {
            let passwordReg = (rules, value, callback) => {
                let reg = /^[0-9a-zA-Z]{6,}$/;
                if (reg.test(value)) {
                    callback();
                } else {
                    callback(new Error("密码必须由六位以上的的字母或数字组成"))
                }
            };
            return {
                form: {
                    name: '',
                    password: "",
                    role: "",
                },
                rules: {
                    name:[
                        {
                            required: true,
                            message: "请输入姓名",
                            trigger: "blur"
                        }
                    ],
                    password: [
                        {
                            required: true,
                            message: "请输入密码",
                            trigger: "blur"
                        },
                        {
                            validator: passwordReg,
                            trigger: "blur"
                        }
                    ],
                    role:[{
                        required: true,
                        message: "请选择管理员权限",
                        trigger: "change"
                    }]
                },
                url:"/api/admin/admin"
            }
        },
        methods: {
            fetchData:function () {
                this.$http.get(this.url,{
                    params:{
                        id:this.$route.params.id
                    }
                }).then(res=>{
                    if(res.data.code===200){
                        this.$message.success(res.data.msg);
                        this.form=res.data.data;
                    }else{
                        this.$message.error(res.data.msg)
                    }
                }).catch(()=>{
                    this.$message.error("未知错误")
                })
            },
            onSubmit: function () {
                this.$refs.form.validate((v) => {
                    if (v){
                        this.$http.put(this.url,this.form).then(r=>{
                            if (r.data.code===200){
                                this.$alert('修改成功', "",{
                                    confirmButtonText: '确定',
                                    callback: () => {
                                        this.$router.push({
                                            name:"adminshow"
                                        });
                                    }
                                });
                            }else{
                                this.$message.error(r.data.msg);
                            }
                        }).catch(()=>{
                            this.$message.error("未知错误");
                        })
                    }

                })
            }
        },
        mounted: function () {
            this.$store.commit("changeActive", "/adminShow");
            this.fetchData();
        }
    }
</script>

<style lang="scss" scoped>

</style>