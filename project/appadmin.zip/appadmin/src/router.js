import Vue from 'vue'
import Router from 'vue-router'

// import UserShow from  '@/views/UserShow'
// import UserAdd from  '@/views/UserAdd'
// import UserEdit from  '@/views/UserEdit'
const UserShow = () => import(/* webpackChunkName: "users" */ '@/views/UserShow');
const UserAdd = () => import(/* webpackChunkName: "users" */ '@/views/UserAdd');
const UserEdit = () => import(/* webpackChunkName: "users" */ '@/views/UserEdit');
// import TypeShow from  '@/views/TypeShow'
// import TypeAdd from "@/views/TypeAdd";
// import TypeEdit from "@/views/TypeEdit";
const TypeShow = () => import(/* webpackChunkName: "type" */ '@/views/TypeShow');
const TypeAdd = () => import(/* webpackChunkName: "type" */ '@/views/TypeAdd');
const TypeEdit = () => import(/* webpackChunkName: "type" */ '@/views/TypeEdit');
// import GoodsShow from "@/views/GoodsShow";
// import GoodsAdd from "@/views/GoodsAdd";
// import GoodsEdit from "@/views/GoodsEdit";
const GoodsShow = () => import(/* webpackChunkName: "goods" */ '@/views/GoodsShow');
const GoodsAdd = () => import(/* webpackChunkName: "goods" */ '@/views/GoodsAdd');
const GoodsEdit = () => import(/* webpackChunkName: "goods" */ '@/views/GoodsEdit');
import AddressShow from "@/views/AddressShow";
import CommentShow from "@/views/CommentShow";
import CommentEdit from "@/views/CommentEdit";
// import AdminPassword from "@/views/AdminPasswordChange";
// // import AdminShow from "@/views/AdminShow";
// // import AdminAdd from "@/views/AdminAdd";
// // import AdminEdit from "@/views/AdminEdit";
const AdminPassword = () => import(/* webpackChunkName: "admin" */ '@/views/AdminPasswordChange');
const AdminShow = () => import(/* webpackChunkName: "admin" */ '@/views/AdminShow');
const AdminAdd = () => import(/* webpackChunkName: "admin" */ '@/views/AdminAdd');
const AdminEdit = () => import(/* webpackChunkName: "admin" */ '@/views/AdminEdit');



Vue.use(Router);

export default new Router({
  routes: [
    {
      path:"/userShow",
      name:"usershow",
      component:UserShow,
    },
    {
      path:"/userAdd",
      name:"useradd",
      component:UserAdd,
    },
    {
      path:"/userEdit/:id",
      name:"useredit",
      component:UserEdit,
    },
    {
      path:"/typeShow",
      name:"typeshow",
      component:TypeShow,
    },
    {
      path:"/typeAdd",
      name:"typeadd",
      component:TypeAdd,
    },
    {
      path:"/typeEdit/:id",
      name:"typeedit",
      component:TypeEdit,
    },
    {
      path:"/goodsShow",
      name:"goodsshow",
      component:GoodsShow,
    },
    {
      path:"/goodsAdd",
      name:"goodsadd",
      component:GoodsAdd,
    },
    {
      path:"/addressShow",
      name:"addressshow",
      component:AddressShow,
    },
    {
      path:"/commentShow",
      name:"commentshow",
      component:CommentShow,
    },
    {
      path:"/commentEdit/:id",
      name:"commentedit",
      component:CommentEdit,
    },
    {
      path:"/goodsEdit/:id",
      name:"goodsedit",
      component:GoodsEdit,
    },
    {
      path:"/adminPassword",
      name:"adminpass",
      component:AdminPassword,
    },
    {
      path:"/adminShow",
      name:"adminshow",
      component:AdminShow
    },
    {
      path:"/adminAdd",
      name:"adminadd",
      component:AdminAdd
    },
    {
      path:"/adminEdit/:id",
      name:"adminedit",
      component:AdminEdit
    }


  ]
})
