# appadmin

## Project setup
```
npm install
```

### Compiles and hot-reloads for development
```
npm run serve
```

### Compiles and minifies for production
```
npm run build
```

### Run your tests
```
npm run test
```

### Lints and fixes files
```
npm run lint
```

### Customize configuration
See [Configuration Reference](https://cli.vuejs.org/config/).




# 前后端分离 
## 前端
* 语言 HTML5 CSS3 JavaScript
* 开发框架 vue.js 组件化开发模式 把每个页面变成一个组件  响应式的数据绑定
* webpack 打包工具 vue.js  .vue .scss ES6  => html css js
* 构建工具 脚手架 @vue/cli 只是把我们要使用的webpack需要配置的东西进行更高级的封装，让我们直接专注于开发，省去配置的麻烦
* 前端路由  可以根据地址（这里说的地址的改变只是一个假的改变，这种改变只会生成历史记录，并不会引起网页的跳转）的不同 渲染对应的组件 这个功能是靠 vue-router插件 实现  具体在项目里是靠 router.js实现的
* 前端布局框架  组件库 Element-ui
* 数据交互  ajax axios将ajax封装后的一个插件 
* vue ui 界面化的项目管理软件
## 后端
* 语言 php
* 框架 ThinkPHP
* 数据库 MySQL
* 数据库管理软件 phpMyAdmin/navicat for MySQL